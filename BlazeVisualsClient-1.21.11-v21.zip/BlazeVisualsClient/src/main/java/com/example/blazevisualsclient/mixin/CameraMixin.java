package com.example.blazevisualsclient.mixin;

import com.example.blazevisualsclient.FreeLook;
import net.minecraft.client.Camera;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Camera.class)
public class CameraMixin {
    /** Free Look: добавляем сдвиг камеры к углам игрока. */
    @ModifyVariable(method = "setRotation(FF)V", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private static float blaze$freeLookYaw(float yaw) {
        return FreeLook.active ? yaw + FreeLook.yawOff : yaw;
    }

    @ModifyVariable(method = "setRotation(FF)V", at = @At("HEAD"), argsOnly = true, ordinal = 1)
    private static float blaze$freeLookPitch(float pitch) {
        return FreeLook.active ? Mth.clamp(pitch + FreeLook.pitchOff, -90f, 90f) : pitch;
    }
}
