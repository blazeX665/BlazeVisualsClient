package com.example.blazevisualsclient;

import java.util.HashMap;
import java.util.Map;

/** Позиции и размер HUD-элементов, настроенные в редакторе. */
public final class HudLayout {
    private HudLayout() {}

    public static final String[] IDS = {"watermark", "fps", "coords", "near", "keys", "list", "target", "dura", "ping", "inv"};
    private static final Map<String, int[]> POS = new HashMap<>();
    private static final Map<String, Integer> SCALE = new HashMap<>();

    public static int[] get(String id) { return POS.get(id); }
    public static void set(String id, int x, int y) { POS.put(id, new int[]{x, y}); }

    /** Размер элемента в процентах (50..250), по умолчанию 100. */
    public static int scale(String id) { return SCALE.getOrDefault(id, 100); }
    public static void setScale(String id, int pct) { SCALE.put(id, Math.max(50, Math.min(250, pct))); }

    public static void reset() {
        POS.clear();
        SCALE.clear();
    }
}
