package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Логика Fullbright и Zoom. Вызывается каждый тик. */
public class VisualEffects {
    private static boolean zooming = false;
    private static int savedFov = 70;
    private static boolean nightVisionAddedByUs = false;
    private static boolean fovFxSaved = false;
    private static double savedFovFx = 1.0;

    public static void tick(Minecraft mc) {
        // --- Zoom ---
        var fov = mc.options.fov();
        if (ModuleManager.ZOOM.enabled) {
            if (!zooming) {
                savedFov = fov.get();
                zooming = true;
            }
            fov.set(ModuleManager.ZOOM_FOV.value);
        } else if (zooming) {
            fov.set(savedFov);
            zooming = false;
        }

        // --- No FOV Change: отключаем изменение FOV от бега и эффектов ---
        var fovFx = mc.options.fovEffectScale();
        if (ModuleManager.NO_FOV.enabled) {
            if (!fovFxSaved) {
                savedFovFx = fovFx.get();
                fovFxSaved = true;
            }
            fovFx.set(0.0);
        } else if (fovFxSaved) {
            fovFx.set(savedFovFx);
            fovFxSaved = false;
        }

        // --- Fullbright (клиентский эффект, зелья не нужны) ---
        var player = mc.player;
        if (player == null) {
            nightVisionAddedByUs = false;
            return;
        }
        boolean has = player.hasEffect(MobEffects.NIGHT_VISION);
        if (ModuleManager.FULLBRIGHT.enabled) {
            if (!has) {
                player.addEffect(new MobEffectInstance(
                        MobEffects.NIGHT_VISION, MobEffectInstance.INFINITE_DURATION,
                        0, false, false, false));
                nightVisionAddedByUs = true;
            }
        } else if (nightVisionAddedByUs) {
            player.removeEffect(MobEffects.NIGHT_VISION);
            nightVisionAddedByUs = false;
        }
    }

    public static void shutdown(Minecraft mc) {
        if (fovFxSaved) {
            mc.options.fovEffectScale().set(savedFovFx);
            fovFxSaved = false;
        }
        if (zooming) {
            mc.options.fov().set(savedFov);
            zooming = false;
        }
    }
}
