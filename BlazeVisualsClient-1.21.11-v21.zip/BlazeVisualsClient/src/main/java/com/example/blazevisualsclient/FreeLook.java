package com.example.blazevisualsclient;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;

/** Free Look: пока зажата клавиша, камера крутится вокруг тебя, а персонаж не поворачивается. */
public final class FreeLook {
    private FreeLook() {}

    public static boolean active = false;
    public static float yawOff = 0f;
    public static float pitchOff = 0f;
    private static CameraType saved = null;

    public static void tick(Minecraft mc, boolean keyDown) {
        boolean want = ModuleManager.FREE_LOOK.enabled && keyDown && mc.player != null && mc.screen == null;
        if (want && !active) {
            active = true;
            yawOff = 0f;
            pitchOff = 0f;
            if (ModuleManager.FL_THIRD.on) {
                saved = mc.options.getCameraType();
                mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
            }
        } else if (!want && active) {
            active = false;
            yawOff = 0f;
            pitchOff = 0f;
            if (saved != null) {
                mc.options.setCameraType(saved);
                saved = null;
            }
        }
    }
}
