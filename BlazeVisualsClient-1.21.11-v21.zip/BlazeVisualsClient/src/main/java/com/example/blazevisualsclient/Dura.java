package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** HUD прочности: броня и предметы в правой и левой руке. */
public final class Dura {
    private Dura() {}

    private static final int W = 150;
    private static final int BG = 0xB0101018;
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final String[] PIECES = {"Шлем", "Нагрудник", "Штаны", "Ботинки"};

    private record Row(String label, String name, int pct) {}

    private static Row row(String label, ItemStack st) {
        if (st.isEmpty()) return null;
        int pct = -1;
        if (st.isDamageableItem() && st.getMaxDamage() > 0) {
            pct = (int) ((st.getMaxDamage() - st.getDamageValue()) * 100L / st.getMaxDamage());
        }
        String name = st.getHoverName().getString();
        if (name.length() > 12) name = name.substring(0, 11) + "…";
        if (st.getCount() > 1) name += " x" + st.getCount();
        return new Row(label, name, pct);
    }

    private static List<Row> rows(Minecraft mc) {
        List<Row> out = new ArrayList<>();
        if (mc.player == null) return out;
        for (int i = 0; i < SLOTS.length; i++) {
            Row r = row(PIECES[i], mc.player.getItemBySlot(SLOTS[i]));
            if (r != null) out.add(r);
        }
        boolean mainIsRight = mc.player.getMainArm() == HumanoidArm.RIGHT;
        Row main = row(mainIsRight ? "Прав. рука" : "Лев. рука", mc.player.getMainHandItem());
        Row off = row(mainIsRight ? "Лев. рука" : "Прав. рука", mc.player.getOffhandItem());
        if (mainIsRight) {
            if (main != null) out.add(main);
            if (off != null) out.add(off);
        } else {
            if (off != null) out.add(off);
            if (main != null) out.add(main);
        }
        return out;
    }

    private static List<Row> sample() {
        List<Row> r = new ArrayList<>();
        r.add(new Row("Шлем", "Алмазный шлем", 87));
        r.add(new Row("Нагрудник", "Незерит. нагр.", 64));
        r.add(new Row("Прав. рука", "Алмазный меч", 42));
        r.add(new Row("Лев. рука", "Щит", 15));
        return r;
    }

    private static int pctColor(int pct) {
        if (pct < 0) return 0xFFAAAAAA;
        return pct > 50 ? 0xFF7FE08A : (pct > 25 ? 0xFFFFD166 : 0xFFFF6B6B);
    }

    private static int heightFor(int n) { return 8 + Math.max(1, n) * 11; }

    public static int[] size(Minecraft mc) {
        int n = rows(mc).size();
        return new int[]{W, heightFor(n == 0 ? 4 : n)};
    }

    public static void draw(GuiGraphics g, Font font, Minecraft mc, int x, int y, boolean preview) {
        List<Row> rows = rows(mc);
        if (rows.isEmpty()) {
            if (!preview) return;
            rows = sample();
        }
        int h = heightFor(rows.size());
        Gfx.rr(g, x, y, W, h, 5, BG);
        Gfx.rr(g, x, y + 4, 2, h - 8, 1, HudRenderer.color(0.5f));

        int ry = y + 5;
        for (Row r : rows) {
            g.drawString(font, r.label(), x + 7, ry, 0xFF9A9AA3);
            g.drawString(font, r.name(), x + 7 + 58, ry, 0xFFFFFFFF);
            String pct = r.pct() < 0 ? "—" : r.pct() + "%";
            g.drawString(font, pct, x + W - 6 - font.width(pct), ry, pctColor(r.pct()));
            ry += 11;
        }
    }
}
