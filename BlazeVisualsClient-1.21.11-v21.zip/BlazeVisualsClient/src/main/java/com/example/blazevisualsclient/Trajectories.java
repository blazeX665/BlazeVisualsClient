package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Линия полёта стрел, жемчуга и бросаемых предметов. Рисуется на экране (проекция 3D → 2D). */
public final class Trajectories {
    private Trajectories() {}

    /** {скорость, гравитация} или null, если ничего не прицелено/не зажато. */
    private static double[] spec(Minecraft mc) {
        var p = mc.player;
        ItemStack main = p.getMainHandItem();
        ItemStack off = p.getOffhandItem();

        if (ModuleManager.TR_BOW.on) {
            if (p.isUsingItem()) {
                ItemStack use = p.getUseItem();
                if (use.is(Items.BOW)) {
                    float power = BowItem.getPowerForTime(p.getTicksUsingItem());
                    if (power >= 0.1f) return new double[]{power * 3.0, 0.05};
                }
                if (use.is(Items.TRIDENT) && p.getTicksUsingItem() >= 10) return new double[]{2.5, 0.05};
            }
            if ((main.is(Items.CROSSBOW) && CrossbowItem.isCharged(main))
                    || (off.is(Items.CROSSBOW) && CrossbowItem.isCharged(off))) {
                return new double[]{3.15, 0.05};
            }
        }
        if (ModuleManager.TR_THROW.on) {
            for (ItemStack s : new ItemStack[]{main, off}) {
                if (s.is(Items.ENDER_PEARL) || s.is(Items.SNOWBALL) || s.is(Items.EGG)) {
                    return new double[]{1.5, 0.03};
                }
                if (s.is(Items.EXPERIENCE_BOTTLE)) return new double[]{0.7, 0.07};
                if (s.is(Items.SPLASH_POTION) || s.is(Items.LINGERING_POTION)) return new double[]{0.5, 0.05};
            }
        }
        return null;
    }

    public static void render(GuiGraphics g, Minecraft mc, float partial) {
        if (!ModuleManager.TRAJECTORIES.enabled || mc.player == null || mc.level == null) return;
        double[] spec = spec(mc);
        if (spec == null) return;

        Vec3 pos = mc.player.getEyePosition(partial).subtract(0.0, 0.1, 0.0);
        Vec3 vel = mc.player.getViewVector(partial).scale(spec[0]);

        // 1) путь до первого блока: отрезки [начало → конец]
        List<Vec3> starts = new ArrayList<>();
        List<Vec3> ends = new ArrayList<>();
        for (int i = 0; i < 160; i++) {
            Vec3 next = pos.add(vel);
            var res = mc.level.clip(new ClipContext(pos, next,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
            starts.add(pos);
            if (res.getType() != HitResult.Type.MISS) {
                ends.add(res.getLocation());
                break;
            }
            ends.add(next);
            pos = next;
            vel = vel.scale(0.99).subtract(0.0, spec[1], 0.0);
            if (pos.y < -128.0) break;
        }

        // 2) попадает ли снаряд в моба или игрока раньше, чем в блок
        boolean hitMob = false;
        int check = Math.min(80, ends.size());
        if (check > 0) {
            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, minZ = Double.MAX_VALUE;
            double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
            for (int i = 0; i < check; i++) {
                Vec3 a = starts.get(i), b = ends.get(i);
                minX = Math.min(minX, Math.min(a.x, b.x));
                minY = Math.min(minY, Math.min(a.y, b.y));
                minZ = Math.min(minZ, Math.min(a.z, b.z));
                maxX = Math.max(maxX, Math.max(a.x, b.x));
                maxY = Math.max(maxY, Math.max(a.y, b.y));
                maxZ = Math.max(maxZ, Math.max(a.z, b.z));
            }
            var area = new net.minecraft.world.phys.AABB(minX, minY, minZ, maxX, maxY, maxZ).inflate(1.5);
            List<LivingEntity> cands = new ArrayList<>();
            for (LivingEntity le : mc.level.getEntitiesOfClass(LivingEntity.class, area)) {
                if (le != mc.player && le.isAlive() && !le.isSpectator()) cands.add(le);
            }
            outer:
            for (int i = 0; i < check; i++) {
                for (LivingEntity le : cands) {
                    var r = le.getBoundingBox().inflate(0.3).clip(starts.get(i), ends.get(i));
                    if (r.isPresent()) {
                        ends.set(i, r.get());
                        while (ends.size() > i + 1) ends.remove(ends.size() - 1);
                        hitMob = true;
                        break outer;
                    }
                }
            }
        }

        // 3) рисуем точки: красные при попадании в моба, иначе цвет темы
        Projection pr = new Projection(mc, partial);
        int base = hitMob ? 0xFF4444 : (HudRenderer.color(0f) & 0x00FFFFFF);
        int n = ends.size();
        for (int i = 0; i < n; i++) {
            double[] s = pr.project(ends.get(i));
            if (s == null) continue;
            int alpha = hitMob ? 255 : 255 - (int) (150.0 * i / Math.max(1, n));
            int x = (int) s[0], y = (int) s[1];
            g.fill(x - 1, y - 1, x + 1, y + 1, (alpha << 24) | base);
        }
    }
}
