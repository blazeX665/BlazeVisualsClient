package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;

/** HUD инвентаря: 27 слотов (и по желанию хотбар) прямо на экране. */
public final class Inv {
    private Inv() {}

    private static final int S = 18;
    private static final int BG = 0xB0101018;

    public static int[] size() {
        boolean hot = ModuleManager.INV_HOTBAR.on;
        return new int[]{9 * S + 8, (hot ? 4 : 3) * S + 8 + (hot ? 4 : 0)};
    }

    public static void draw(GuiGraphics g, Font font, Minecraft mc, int x, int y) {
        int[] sz = size();
        Gfx.rr(g, x, y, sz[0], sz[1], 5, BG);
        Gfx.rr(g, x, y + 4, 2, sz[1] - 8, 1, HudRenderer.color(0.7f));

        boolean hot = ModuleManager.INV_HOTBAR.on;
        for (int row = 0; row < (hot ? 4 : 3); row++) {
            boolean hotRow = row == 3;
            int extra = hotRow ? 4 : 0;
            for (int col = 0; col < 9; col++) {
                int sx = x + 4 + col * S;
                int sy = y + 4 + row * S + extra;
                Gfx.rr(g, sx, sy, S - 2, S - 2, 3, 0x30FFFFFF);
                if (mc.player == null) continue;
                int idx = hotRow ? col : 9 + row * 9 + col;
                ItemStack st = mc.player.getInventory().getItem(idx);
                if (!st.isEmpty()) {
                    g.renderItem(st, sx, sy);
                    g.renderItemDecorations(font, st, sx, sy);
                }
            }
        }
    }
}
