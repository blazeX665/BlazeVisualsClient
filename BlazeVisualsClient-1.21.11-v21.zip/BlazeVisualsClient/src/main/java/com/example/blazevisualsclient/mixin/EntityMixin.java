package com.example.blazevisualsclient.mixin;

import com.example.blazevisualsclient.FreeLook;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class EntityMixin {
    /** Free Look: движение мыши крутит камеру, а не игрока. */
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true)
    private void blaze$freeLookTurn(double yRot, double xRot, CallbackInfo ci) {
        if (!FreeLook.active) return;
        if ((Object) this != Minecraft.getInstance().player) return;
        FreeLook.yawOff += (float) (yRot * 0.15);
        FreeLook.pitchOff += (float) (xRot * 0.15);
        ci.cancel();
    }
}
