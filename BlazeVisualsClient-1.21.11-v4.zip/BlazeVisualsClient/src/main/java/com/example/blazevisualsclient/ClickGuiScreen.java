package com.example.blazevisualsclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int BG = 0xF2131316, BORDER = 0xFF2A2A31, TAB_BG = 0xFF16161A, TAB_BORDER = 0xFF34343C;
    private static final int CARD = 0xFF202026, CARD_HOVER = 0xFF27272E, SUB = 0xFF1A1A1F;
    private static final int OFF = 0xFF3A3A44, GREY = 0xFF9A9AA3, WHITE = 0xFFF2F2F5, KNOB = 0xFFF2F2F5;

    private static final int PAD = 10, HEAD = 26, TAB_H = 18, CARD_H = 26, GAP = 3, SET_H = 16, FOOT = 16;
    private static final int CONTENT_H = 5 * (CARD_H + GAP);
    private static final String VERSION = "v1.2 · RSHIFT";
    private static final String[] TABS = {"Visuals", "Utilities", "Client"};

    private static int tab = 0;
    private static Module open = null; // раскрытый модуль (аккордеон)

    private record Hit(int x, int y, int w, int h, Runnable action) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final List<Hit> hits = new ArrayList<>();

    public ClickGuiScreen() { super(Component.literal("BlazeVisualsClient")); }

    private int pw() { return Math.min(width - 12, 330); }
    private int ph() { return HEAD + TAB_H + 6 + CONTENT_H + FOOT + 6; }
    private int px() { return (width - pw()) / 2; }
    private int py() { return Math.max(4, (height - ph()) / 2); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        hits.clear();

        int x = px(), y = py(), w = pw(), h = ph();

        for (Module m : ModuleManager.ALL) {
            m.anim += ((m.enabled ? 1f : 0f) - m.anim) * 0.3f;
        }

        // панель
        Gfx.round(g, x - 1, y - 1, w + 2, h + 2, BORDER);
        Gfx.round(g, x, y, w, h, BG);

        // заголовок
        g.drawString(font, "Blaze", x + PAD + 2, y + 9, Gfx.ORANGE);
        g.drawString(font, "VisualsClient", x + PAD + 2 + font.width("Blaze"), y + 9, WHITE);
        g.drawString(font, VERSION, x + w - PAD - 2 - font.width(VERSION), y + 9, GREY);

        // вкладки
        int tabW = (w - 2 * PAD - 2 * 4) / 3;
        int tabY = y + HEAD;
        for (int i = 0; i < TABS.length; i++) {
            int tx = x + PAD + i * (tabW + 4);
            boolean sel = i == tab;
            boolean hov = mx >= tx && mx < tx + tabW && my >= tabY && my < tabY + TAB_H;
            Gfx.bordered(g, tx, tabY, tabW, TAB_H, hov && !sel ? CARD : TAB_BG,
                    sel ? Gfx.ORANGE : TAB_BORDER);
            g.drawString(font, TABS[i], tx + tabW / 2 - font.width(TABS[i]) / 2, tabY + 5,
                    sel ? Gfx.ORANGE : WHITE);
            final int idx = i;
            hits.add(new Hit(tx, tabY, tabW, TAB_H, () -> tab = idx));
        }

        // карточки модулей
        List<Module> list = ModuleManager.inCategory(TABS[tab]);
        int cx = x + PAD, cw = w - 2 * PAD;
        int cy = tabY + TAB_H + 6;

        for (Module m : list) {
            boolean hasSettings = !m.settings.isEmpty();
            boolean expanded = hasSettings && open == m;
            boolean hover = mx >= cx && mx < cx + cw && my >= cy && my < cy + CARD_H;

            Gfx.round(g, cx, cy, cw, CARD_H, hover ? CARD_HOVER : CARD);
            g.drawString(font, m.name, cx + 8, cy + 5, m.enabled ? Gfx.ORANGE : WHITE);
            g.drawString(font, m.description, cx + 8, cy + 15, GREY);

            int rightEdge = cx + cw - 8 - (hasSettings ? 18 : 0);
            int sx = rightEdge - 28, sy = cy + (CARD_H - 14) / 2;
            Gfx.round(g, sx, sy, 28, 14, Gfx.lerp(OFF, Gfx.ORANGE, m.anim));
            Gfx.round(g, sx + 2 + (int) (m.anim * 14), sy + 2, 10, 10, KNOB);

            // клик по всей карточке — переключить модуль
            final Module mod = m;
            hits.add(new Hit(cx, cy, cw, CARD_H, mod::toggle));

            if (hasSettings) {
                Gfx.chevron(g, cx + cw - 14, cy + CARD_H / 2 - 2, expanded, GREY);
                hits.add(new Hit(cx + cw - 26, cy, 26, CARD_H, () -> open = (open == mod) ? null : mod));
            }
            cy += CARD_H + GAP;

            // настройки раскрытого модуля
            if (expanded) {
                int blockH = m.settings.size() * SET_H + 6;
                Gfx.round(g, cx + 4, cy - 1, cw - 8, blockH, SUB);
                int ry = cy + 2;
                for (Setting s : m.settings) {
                    drawSetting(g, s, cx + 4, ry, cw - 8, mx, my);
                    ry += SET_H;
                }
                cy += blockH + GAP;
            }
        }

        g.drawString(font, "Клик по карточке — вкл/выкл, стрелка — настройки",
                x + PAD + 2, y + h - FOOT, 0xFF6C6C75);
    }

    private void drawSetting(GuiGraphics g, Setting s, int x, int y, int w, int mx, int my) {
        g.drawString(font, s.name, x + 8, y + 4, WHITE);
        int right = x + w - 8;

        if (s.isToggle) {
            int sx = right - 22, sy = y + 3;
            Gfx.round(g, sx, sy, 22, 10, s.on ? Gfx.ORANGE : OFF);
            Gfx.round(g, sx + (s.on ? 12 : 2), sy + 2, 8, 6, KNOB);
            hits.add(new Hit(x, y, w, SET_H, () -> s.on = !s.on));
        } else {
            String val = s.value + s.suffix;
            int plusX = right - 12;
            int valW = 36;
            int valX = plusX - 3 - valW;
            int minusX = valX - 3 - 12;
            Gfx.round(g, minusX, y + 2, 12, 12, 0xFF2C2C34);
            g.drawString(font, "-", minusX + 4, y + 4, WHITE);
            Gfx.round(g, plusX, y + 2, 12, 12, 0xFF2C2C34);
            g.drawString(font, "+", plusX + 3, y + 4, WHITE);
            g.drawString(font, val, valX + valW / 2 - font.width(val) / 2, y + 4, Gfx.ORANGE);
            hits.add(new Hit(minusX - 2, y, 16, SET_H, s::dec));
            hits.add(new Hit(plusX - 2, y, 16, SET_H, s::inc));
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            double mx = event.x(), my = event.y();
            // последние добавленные регионы лежат «сверху»
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit hit = hits.get(i);
                if (hit.contains(mx, my)) {
                    hit.action().run();
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
