package com.example.blazevisualsclient;

import java.util.ArrayList;
import java.util.List;

public class Module {
    public final String name;
    public final String description;
    public final String category;
    public final List<Setting> settings = new ArrayList<>();
    public boolean enabled;
    public float anim; // 0..1 для плавного переключателя

    public Module(String name, String description, String category, boolean enabled) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = enabled;
        this.anim = enabled ? 1f : 0f;
    }

    public Module add(Setting s) {
        settings.add(s);
        return this;
    }

    public void toggle() { enabled = !enabled; }
}
