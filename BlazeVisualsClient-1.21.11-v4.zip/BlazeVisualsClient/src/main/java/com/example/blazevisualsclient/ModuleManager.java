package com.example.blazevisualsclient;

import java.util.List;

public class ModuleManager {
    // --- настройки ---
    public static final Setting ZOOM_FOV   = Setting.step("Zoom FOV", 30, 30, 60, 5, "");
    public static final Setting OPT_EFFECTS = Setting.toggle("Меньше эффектов", true);
    public static final Setting OPT_UNLOCK  = Setting.toggle("Разблокировать FPS", true);
    public static final Setting OPT_RENDER  = Setting.step("Прорисовка (чанки)", 8, 2, 32, 2, "");
    public static final Setting OPT_SIM     = Setting.step("Симуляция (чанки)", 5, 5, 16, 1, "");
    public static final Setting OPT_ENTITY  = Setting.step("Сущности (%)", 50, 50, 150, 25, "%");

    // --- Visuals ---
    public static final Module FULLBRIGHT = new Module("Fullbright", "Максимальная яркость (клавиша B)", "Visuals", false);
    public static final Module RAINBOW    = new Module("Rainbow", "Радужные цвета HUD", "Visuals", false);

    // --- Utilities ---
    public static final Module ZOOM = new Module("Zoom", "Приближение (клавиша C)", "Utilities", false)
            .add(ZOOM_FOV);
    public static final Module OPTIMIZATION = new Module("Optimization", "Повышение FPS", "Utilities", false)
            .add(OPT_EFFECTS).add(OPT_UNLOCK).add(OPT_RENDER).add(OPT_SIM).add(OPT_ENTITY);

    // --- Client (HUD) ---
    public static final Module WATERMARK  = new Module("Watermark", "Название мода сверху слева", "Client", true);
    public static final Module FPS        = new Module("FPS", "Счётчик кадров", "Client", true);
    public static final Module COORDS     = new Module("Coordinates", "Координаты и направление", "Client", true);
    public static final Module KEYSTROKES = new Module("Keystrokes", "WASD на экране", "Client", true);
    public static final Module ARRAYLIST  = new Module("ArrayList", "Список включённых модулей", "Client", true);

    public static final List<Module> ALL = List.of(
            FULLBRIGHT, RAINBOW,
            ZOOM, OPTIMIZATION,
            WATERMARK, FPS, COORDS, KEYSTROKES, ARRAYLIST
    );

    public static List<Module> inCategory(String category) {
        return ALL.stream().filter(m -> m.category.equals(category)).toList();
    }
}
