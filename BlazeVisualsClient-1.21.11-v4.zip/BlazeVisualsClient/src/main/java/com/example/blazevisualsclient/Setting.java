package com.example.blazevisualsclient;

/** Настройка модуля: переключатель или число с кнопками -/+. */
public class Setting {
    public final String name;
    public final boolean isToggle;
    public boolean on;
    public int value;
    public final int min, max, step;
    public final String suffix;

    private Setting(String name, boolean isToggle, boolean on, int value, int min, int max, int step, String suffix) {
        this.name = name;
        this.isToggle = isToggle;
        this.on = on;
        this.value = value;
        this.min = min;
        this.max = max;
        this.step = step;
        this.suffix = suffix;
    }

    public static Setting toggle(String name, boolean def) {
        return new Setting(name, true, def, 0, 0, 0, 0, "");
    }

    public static Setting step(String name, int def, int min, int max, int step, String suffix) {
        return new Setting(name, false, false, def, min, max, step, suffix);
    }

    public void inc() { value = Math.min(max, value + step); }
    public void dec() { value = Math.max(min, value - step); }
}
