package com.example.blazevisualsclient;

import java.util.List;

public class ModuleManager {
    public static final Module WATERMARK  = new Module("Watermark", "Название мода сверху слева", "HUD", true);
    public static final Module FPS        = new Module("FPS", "Счётчик кадров", "HUD", true);
    public static final Module COORDS     = new Module("Coordinates", "Координаты и направление", "HUD", true);
    public static final Module KEYSTROKES = new Module("Keystrokes", "WASD на экране", "HUD", true);
    public static final Module ARRAYLIST  = new Module("ArrayList", "Список включённых модулей", "HUD", true);

    public static final Module RAINBOW    = new Module("Rainbow", "Радужные цвета HUD", "Visuals", true);
    public static final Module FULLBRIGHT = new Module("Fullbright", "Максимальная яркость (клавиша B)", "Visuals", false);
    public static final Module ZOOM       = new Module("Zoom", "Приближение (клавиша C)", "Visuals", false);

    public static final List<Module> ALL = List.of(
            WATERMARK, FPS, COORDS, KEYSTROKES, ARRAYLIST,
            RAINBOW, FULLBRIGHT, ZOOM
    );

    public static List<Module> inCategory(String category) {
        return ALL.stream().filter(m -> m.category.equals(category)).toList();
    }
}
