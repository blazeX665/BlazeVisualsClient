package com.example.blazevisualsclient;

public class Module {
    public final String name;
    public final String description;
    public final String category;
    public boolean enabled;
    public float anim; // 0..1 для плавного переключателя

    public Module(String name, String description, String category, boolean enabled) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = enabled;
        this.anim = enabled ? 1f : 0f;
    }

    public void toggle() { enabled = !enabled; }
}
