package com.example.blazevisualsclient;

import net.minecraft.client.gui.GuiGraphics;

public final class Gfx {
    private Gfx() {}

    /** Прямоугольник со скруглёнными углами (без наложения полупрозрачных слоёв). */
    public static void round(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x + 1, y, x + w - 1, y + 1, c);
        g.fill(x, y + 1, x + w, y + h - 1, c);
        g.fill(x + 1, y + h - 1, x + w - 1, y + h, c);
    }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (int) (((a >>> 24) & 255) * (1 - t) + ((b >>> 24) & 255) * t);
        int rr = (int) (((a >>> 16) & 255) * (1 - t) + ((b >>> 16) & 255) * t);
        int gg = (int) (((a >>> 8) & 255) * (1 - t) + ((b >>> 8) & 255) * t);
        int bb = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (aa << 24) | (rr << 16) | (gg << 8) | bb;
    }
}
