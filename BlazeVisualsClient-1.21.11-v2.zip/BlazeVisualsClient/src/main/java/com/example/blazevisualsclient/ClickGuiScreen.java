package com.example.blazevisualsclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int W = 200, PAD = 10, HEAD = 28, TAB_H = 18, ROW = 22, FOOT = 20, ROWS = 5;
    private static final String[] TABS = {"HUD", "Visuals"};
    private static int tab = 0;

    public ClickGuiScreen() { super(Component.literal("BlazeVisualsClient")); }

    private int panelH() { return HEAD + TAB_H + 6 + ROW * ROWS + FOOT; }
    private int px() { return width / 2 - W / 2; }
    private int py() { return height / 2 - panelH() / 2; }
    private int tabW() { return (W - 2 * PAD - 4) / 2; }
    private int tabX(int i) { return px() + PAD + i * (tabW() + 4); }
    private int rowsTop() { return py() + HEAD + TAB_H + 6; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        int x = px(), y = py(), h = panelH();
        int accent = HudRenderer.color(0f);

        // плавная анимация переключателей
        for (Module m : ModuleManager.ALL) {
            m.anim += ((m.enabled ? 1f : 0f) - m.anim) * 0.3f;
        }

        // рамка и фон
        Gfx.round(g, x - 1, y - 1, W + 2, h + 2, (accent & 0x00FFFFFF) | 0x90000000);
        Gfx.round(g, x, y, W, h, 0xF0101018);

        // заголовок
        String title = "BlazeVisualsClient";
        g.drawString(font, title, x + PAD, y + 9, accent);
        g.fill(x + PAD, y + HEAD - 4, x + PAD + font.width(title), y + HEAD - 3, accent);

        // вкладки
        for (int i = 0; i < TABS.length; i++) {
            int tx = tabX(i), ty = y + HEAD;
            boolean sel = i == tab;
            boolean hov = mx >= tx && mx < tx + tabW() && my >= ty && my < ty + TAB_H;
            int bg = sel ? ((accent & 0x00FFFFFF) | 0xFF000000)
                    : (hov ? 0xFF2A2A3A : 0xFF1C1C2A);
            Gfx.round(g, tx, ty, tabW(), TAB_H, bg);
            g.drawString(font, TABS[i], tx + tabW() / 2 - font.width(TABS[i]) / 2, ty + 5,
                    sel ? 0xFF101018 : 0xFFCCCCCC);
        }

        // список модулей
        List<Module> list = ModuleManager.inCategory(TABS[tab]);
        String hint = "RShift — закрыть меню";
        for (int i = 0; i < list.size(); i++) {
            Module m = list.get(i);
            int ry = rowsTop() + i * ROW;
            boolean hover = mx >= x + 4 && mx < x + W - 4 && my >= ry && my < ry + ROW;
            if (hover) {
                Gfx.round(g, x + 4, ry, W - 8, ROW - 2, 0x30FFFFFF);
                hint = m.description;
            }
            g.drawString(font, m.name, x + PAD + 2, ry + 7, m.enabled ? 0xFFFFFFFF : 0xFF888888);

            int sx = x + W - PAD - 28, sy = ry + 5;
            Gfx.round(g, sx, sy, 26, 12, Gfx.lerp(0xFF3A3A48, accent, m.anim));
            int kx = sx + 2 + (int) (m.anim * 14);
            Gfx.round(g, kx, sy + 2, 8, 8, 0xFFFFFFFF);
        }

        g.drawString(font, hint, x + PAD, y + h - FOOT + 6, 0xFF999999);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        if (event.button() == 0) {
            int x = px(), y = py();
            // вкладки
            for (int i = 0; i < TABS.length; i++) {
                int tx = tabX(i), ty = y + HEAD;
                if (mx >= tx && mx < tx + tabW() && my >= ty && my < ty + TAB_H) {
                    tab = i;
                    return true;
                }
            }
            // модули
            List<Module> list = ModuleManager.inCategory(TABS[tab]);
            for (int i = 0; i < list.size(); i++) {
                int ry = rowsTop() + i * ROW;
                if (mx >= x + 4 && mx < x + W - 4 && my >= ry && my < ry + ROW) {
                    list.get(i).toggle();
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
