package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Логика Fullbright и Zoom. Вызывается каждый тик. */
public class VisualEffects {
    private static final int ZOOM_FOV = 30;

    private static boolean zooming = false;
    private static int savedFov = 70;
    private static boolean nightVisionAddedByUs = false;

    public static void tick(Minecraft mc) {
        // --- Zoom ---
        var fov = mc.options.fov();
        if (ModuleManager.ZOOM.enabled && !zooming) {
            savedFov = fov.get();
            fov.set(ZOOM_FOV);
            zooming = true;
        } else if (!ModuleManager.ZOOM.enabled && zooming) {
            fov.set(savedFov);
            zooming = false;
        }

        // --- Fullbright (клиентский эффект, зелья не нужны) ---
        var player = mc.player;
        if (player == null) {
            nightVisionAddedByUs = false;
            return;
        }
        boolean has = player.hasEffect(MobEffects.NIGHT_VISION);
        if (ModuleManager.FULLBRIGHT.enabled) {
            if (!has) {
                player.addEffect(new MobEffectInstance(
                        MobEffects.NIGHT_VISION, MobEffectInstance.INFINITE_DURATION,
                        0, false, false, false));
                nightVisionAddedByUs = true;
            }
        } else if (nightVisionAddedByUs) {
            player.removeEffect(MobEffects.NIGHT_VISION);
            nightVisionAddedByUs = false;
        }
    }

    /** Возвращаем FOV при выходе, чтобы он не сохранился в настройках зумированным. */
    public static void shutdown(Minecraft mc) {
        if (zooming) {
            mc.options.fov().set(savedFov);
            zooming = false;
        }
    }
}
