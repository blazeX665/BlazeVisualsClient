package com.example.blazevisualsclient;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class BlazeVisualsClient implements ClientModInitializer {
    public static final String MOD_ID = "blazevisualsclient";

    private static KeyMapping openMenu;
    private static KeyMapping zoomKey;
    private static KeyMapping fullbrightKey;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "main"));

        openMenu = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.blazevisualsclient.menu", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.blazevisualsclient.zoom", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_C, category));
        fullbrightKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.blazevisualsclient.fullbright", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_B, category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openMenu.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new ClickGuiScreen());
            }
            while (zoomKey.consumeClick()) ModuleManager.ZOOM.toggle();
            while (fullbrightKey.consumeClick()) ModuleManager.FULLBRIGHT.toggle();
            VisualEffects.tick(mc);
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> VisualEffects.shutdown(mc));

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "hud"),
                (graphics, deltaTracker) -> HudRenderer.render(graphics));
    }
}
