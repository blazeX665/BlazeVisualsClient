package com.example.blazevisualsclient.mixin;

import com.example.blazevisualsclient.ModuleManager;
import com.example.blazevisualsclient.ShiftDrag;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Shift + протягивание мышью по слотам сундука или инвентаря — быстрый перенос предметов. */
@Mixin(AbstractContainerScreen.class)
public abstract class ContainerScreenMixin {
    @Shadow protected Slot hoveredSlot;

    @Shadow protected abstract void slotClicked(Slot slot, int slotId, int button, ClickType type);

    @Inject(method = "mouseDragged(Lnet/minecraft/client/input/MouseButtonEvent;DD)Z", at = @At("HEAD"))
    private void blaze$shiftDrag(MouseButtonEvent event, double dx, double dy,
                                 CallbackInfoReturnable<Boolean> cir) {
        if (!ModuleManager.SHIFT_DRAG.enabled || !Screen.hasShiftDown()) return;
        Slot s = this.hoveredSlot;
        if (s == null || !s.hasItem()) return;
        if (ShiftDrag.add(s)) {
            this.slotClicked(s, s.index, 0, ClickType.QUICK_MOVE);
        }
    }

    @Inject(method = "mouseReleased(Lnet/minecraft/client/input/MouseButtonEvent;)Z", at = @At("HEAD"))
    private void blaze$shiftDragEnd(MouseButtonEvent event, CallbackInfoReturnable<Boolean> cir) {
        ShiftDrag.reset();
    }
}
