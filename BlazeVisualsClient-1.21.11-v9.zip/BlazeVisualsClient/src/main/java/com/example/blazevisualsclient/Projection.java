package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

/** Проекция точки мира на экран (для ESP-рамок). */
public final class Projection {
    private final Vec3 eye, look, right, up;
    private final double tanHalf, aspect;
    private final int sw, sh;

    public Projection(Minecraft mc, float partial) {
        sw = mc.getWindow().getGuiScaledWidth();
        sh = mc.getWindow().getGuiScaledHeight();
        eye = mc.player.getEyePosition(partial);
        look = mc.player.getViewVector(partial);
        Vec3 r = look.cross(new Vec3(0, 1, 0));
        right = r.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : r.normalize();
        up = right.cross(look);
        tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        aspect = (double) sw / (double) sh;
    }

    /** Возвращает {x, y} на экране или null, если точка позади камеры. */
    public double[] project(Vec3 p) {
        Vec3 d = p.subtract(eye);
        double dz = d.dot(look);
        if (dz <= 0.1) return null;
        double dx = d.dot(right), dy = d.dot(up);
        return new double[]{
                sw / 2.0 * (1.0 + dx / (dz * tanHalf * aspect)),
                sh / 2.0 * (1.0 - dy / (dz * tanHalf))
        };
    }
}
