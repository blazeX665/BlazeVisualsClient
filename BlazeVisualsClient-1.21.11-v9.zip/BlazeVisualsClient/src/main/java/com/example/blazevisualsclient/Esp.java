package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** ESP: рамки вокруг игроков и свечение (Glow). */
public final class Esp {
    private Esp() {}

    private static final Set<UUID> glowing = new HashSet<>();

    public static void tick(Minecraft mc) {
        if (mc.level == null || mc.player == null) {
            glowing.clear();
            return;
        }
        boolean want = ModuleManager.ESP.enabled && ModuleManager.ESP_GLOW.on;
        double r = ModuleManager.ESP_RADIUS.value;
        for (var p : mc.level.players()) {
            if (p == mc.player) continue;
            if (want && mc.player.distanceTo(p) <= r) {
                p.setGlowingTag(true);
                glowing.add(p.getUUID());
            } else if (glowing.remove(p.getUUID())) {
                p.setGlowingTag(false);
            }
        }
    }

    public static void render(GuiGraphics g, Font font, Minecraft mc, float partial) {
        if (!ModuleManager.ESP.enabled || !ModuleManager.ESP_BOX.on
                || mc.level == null || mc.player == null) return;
        Projection pr = new Projection(mc, partial);
        double range = ModuleManager.ESP_RADIUS.value;
        int col = HudRenderer.color(0f);

        for (var p : mc.level.players()) {
            if (p == mc.player) continue;
            float dist = mc.player.distanceTo(p);
            if (dist > range) continue;

            Vec3 pos = p.getPosition(partial);
            double h = p.getBbHeight(), w = p.getBbWidth() / 2.0;
            double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
            boolean ok = true;
            for (int i = 0; i < 8; i++) {
                double cx = pos.x + ((i & 1) == 0 ? -w : w);
                double cy = pos.y + ((i & 2) == 0 ? 0 : h);
                double cz = pos.z + ((i & 4) == 0 ? -w : w);
                double[] s = pr.project(new Vec3(cx, cy, cz));
                if (s == null) { ok = false; break; }
                minX = Math.min(minX, s[0]);
                maxX = Math.max(maxX, s[0]);
                minY = Math.min(minY, s[1]);
                maxY = Math.max(maxY, s[1]);
            }
            if (!ok) continue;

            int x1 = (int) minX, y1 = (int) minY, x2 = (int) maxX, y2 = (int) maxY;
            if (x2 - x1 < 3 || y2 - y1 < 3) continue;
            g.fill(x1, y1, x2, y1 + 1, col);
            g.fill(x1, y2 - 1, x2, y2, col);
            g.fill(x1, y1, x1 + 1, y2, col);
            g.fill(x2 - 1, y1, x2, y2, col);

            if (ModuleManager.ESP_NAME.on) {
                String label = p.getName().getString() + "  " + (int) dist + "м";
                int tw = font.width(label);
                int tx = (x1 + x2) / 2 - tw / 2 - 3;
                Gfx.round(g, tx, y1 - 13, tw + 6, 12, 0xA0101018);
                g.drawString(font, label, tx + 3, y1 - 11, 0xFFFFFFFF);
            }
        }
    }
}
