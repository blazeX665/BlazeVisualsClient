package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Редактор HUD: перетаскивай элементы мышью (пальцем). */
public class HudEditorScreen extends Screen {
    private String dragging = null;
    private int offX, offY;

    public HudEditorScreen() { super(Component.literal("HUD Editor")); }

    @Override
    protected void init() {
        addRenderableWidget(Button.builder(Component.literal("Сбросить"), b -> {
                    HudLayout.reset();
                    Config.save();
                })
                .bounds(width / 2 - 94, height - 28, 90, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Готово"),
                        b -> Minecraft.getInstance().setScreen(new ClickGuiScreen()))
                .bounds(width / 2 + 4, height - 28, 90, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        Font f = font;
        int accent = HudRenderer.color(0f);

        for (String id : HudLayout.IDS) {
            if (!HudRenderer.enabled(id)) continue;
            int[] p = HudRenderer.pos(id, mc, f);
            int[] s = HudRenderer.size(id, mc, f);
            HudRenderer.draw(id, g, f, mc, p[0], p[1], true);

            int col = id.equals(dragging) ? 0xFFFFFFFF : accent;
            g.fill(p[0] - 2, p[1] - 2, p[0] + s[0] + 2, p[1] - 1, col);
            g.fill(p[0] - 2, p[1] + s[1] + 1, p[0] + s[0] + 2, p[1] + s[1] + 2, col);
            g.fill(p[0] - 2, p[1] - 2, p[0] - 1, p[1] + s[1] + 2, col);
            g.fill(p[0] + s[0] + 1, p[1] - 2, p[0] + s[0] + 2, p[1] + s[1] + 2, col);
        }
        String hint = "Тяни элементы, чтобы расставить HUD под себя";
        g.drawString(f, hint, (width - f.width(hint)) / 2, 8, 0xFFDDDDDD);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true;
        if (event.button() != 0) return false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return false;
        double mx = event.x(), my = event.y();
        for (int i = HudLayout.IDS.length - 1; i >= 0; i--) {
            String id = HudLayout.IDS[i];
            if (!HudRenderer.enabled(id)) continue;
            int[] p = HudRenderer.pos(id, mc, font);
            int[] s = HudRenderer.size(id, mc, font);
            if (mx >= p[0] - 2 && mx < p[0] + s[0] + 2 && my >= p[1] - 2 && my < p[1] + s[1] + 2) {
                dragging = id;
                offX = (int) mx - p[0];
                offY = (int) my - p[1];
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (dragging != null) {
            Minecraft mc = Minecraft.getInstance();
            int[] s = HudRenderer.size(dragging, mc, font);
            int nx = (int) event.x() - offX;
            int ny = (int) event.y() - offY;
            nx = Math.max(0, Math.min(width - s[0], nx));
            ny = Math.max(0, Math.min(height - s[1], ny));
            HudLayout.set(dragging, nx, ny);
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging != null) {
            dragging = null;
            Config.save();
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }
}
