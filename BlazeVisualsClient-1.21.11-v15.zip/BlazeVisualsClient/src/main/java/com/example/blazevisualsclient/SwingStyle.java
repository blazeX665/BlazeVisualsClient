package com.example.blazevisualsclient;

/** Стиль анимации удара/ломания блока (меняет кривую прогресса взмаха). */
public final class SwingStyle {
    private SwingStyle() {}

    public static float apply(float p) {
        if (!ModuleManager.SWING.enabled) return p;
        p = Math.max(0f, Math.min(1f, p));
        return switch (ModuleManager.SW_STYLE.value) {
            case 1 -> p * p * (3f - 2f * p);            // плавный
            case 2 -> p * p;                            // разгон
            case 3 -> 1f - (1f - p) * (1f - p);         // резкий старт
            default -> p;
        };
    }
}
