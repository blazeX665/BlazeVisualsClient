package com.example.blazevisualsclient.mixin;

import com.example.blazevisualsclient.SwingStyle;
import com.example.blazevisualsclient.ViewModel;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemInHandRenderer.class)
public class ItemInHandRendererMixin {
    /** View Model: двигаем/вращаем/масштабируем руку и предмет. */
    @Inject(method = "renderArmWithItem", at = @At("HEAD"))
    private static void blaze$viewModel(AbstractClientPlayer player, float partialTick, float pitch,
                                        InteractionHand hand, float swingProgress, ItemStack stack,
                                        float equipProgress, PoseStack poseStack,
                                        SubmitNodeCollector collector, int light, CallbackInfo ci) {
        ViewModel.apply(player, hand, poseStack);
    }

    /** Swing Animation: стиль взмаха (кривая прогресса). */
    @ModifyVariable(method = "applyItemArmAttackTransform", at = @At("HEAD"), argsOnly = true)
    private static float blaze$swingStyle(float progress) {
        return SwingStyle.apply(progress);
    }
}
