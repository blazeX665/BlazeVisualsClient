package com.example.blazevisualsclient;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;

/** Положение рук и предметов от первого лица. */
public final class ViewModel {
    private ViewModel() {}

    public static void apply(AbstractClientPlayer player, InteractionHand hand, PoseStack ps) {
        if (!ModuleManager.VIEW_MODEL.enabled) return;
        boolean right = (hand == InteractionHand.MAIN_HAND) == (player.getMainArm() == HumanoidArm.RIGHT);
        float s = right ? 1f : -1f;

        // точка руки в пространстве камеры — вокруг неё вращаем и масштабируем
        double hx = 0.56 * s, hy = -0.52, hz = -0.72;
        ps.translate(hx + s * ModuleManager.VM_X.value * 0.01,
                hy + ModuleManager.VM_Y.value * 0.01,
                hz + ModuleManager.VM_Z.value * 0.01);
        ps.mulPose(Axis.XP.rotationDegrees((float) ModuleManager.VM_RX.value));
        ps.mulPose(Axis.YP.rotationDegrees(s * ModuleManager.VM_RY.value));
        ps.mulPose(Axis.ZP.rotationDegrees(s * ModuleManager.VM_RZ.value));
        float sc = ModuleManager.VM_SCALE.value / 100f;
        ps.scale(sc, sc, sc);
        ps.translate(-hx, -hy, -hz);
    }
}
