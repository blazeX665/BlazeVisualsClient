package com.example.blazevisualsclient;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;

import java.awt.Color;
import java.util.Comparator;
import java.util.List;

public class HudRenderer {
    private static final int BG = 0xA0101018;
    private static final int GREY = 0xFFAAAAAA;

    /** Цвет акцента: цвет темы или радуга. */
    public static int color(float offset) {
        if (!ModuleManager.RAINBOW.enabled) return Theme.accent();
        float h = ((System.currentTimeMillis() % 4000L) / 4000f + offset) % 1f;
        return Color.HSBtoRGB(h, 0.55f, 1f) | 0xFF000000;
    }

    // ---------- общий рендер ----------
    public static void render(GuiGraphics g, float partial) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        Font font = mc.font;

        for (String id : HudLayout.IDS) {
            if (!enabled(id)) continue;
            if (id.equals("target") && !Esp.has()) continue;
            int[] p = pos(id, mc, font);
            draw(id, g, font, mc, p[0], p[1], false);
        }
        Waypoints.render(g, font, mc, partial);
        Pinger.render(g, font, mc);
    }

    // ---------- элементы (используются и редактором HUD) ----------
    public static boolean enabled(String id) {
        return switch (id) {
            case "watermark" -> ModuleManager.WATERMARK.enabled;
            case "fps" -> ModuleManager.FPS.enabled;
            case "coords" -> ModuleManager.COORDS.enabled;
            case "near" -> ModuleManager.SCANNER.enabled;
            case "keys" -> ModuleManager.KEYSTROKES.enabled;
            case "list" -> ModuleManager.ARRAYLIST.enabled;
            case "target" -> ModuleManager.ESP.enabled;
            default -> false;
        };
    }

    public static int[] pos(String id, Minecraft mc, Font font) {
        int[] p = HudLayout.get(id);
        if (p != null) return p;
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        return switch (id) {
            case "watermark" -> new int[]{6, 6};
            case "fps" -> new int[]{6, 26};
            case "coords" -> new int[]{6, 43};
            case "near" -> new int[]{6, 62};
            case "keys" -> new int[]{6, sh - 70};
            case "target" -> new int[]{sw / 2 + 24, sh / 2 + 8};
            default -> new int[]{sw - size(id, mc, font)[0] - 8, 6};
        };
    }

    public static int[] size(String id, Minecraft mc, Font font) {
        switch (id) {
            case "watermark":
                return new int[]{font.width("Blaze") + font.width("VisualsClient") + 14, 16};
            case "fps":
                return new int[]{statW(font, "FPS", fpsValue(mc), ""), 14};
            case "coords":
                return new int[]{statW(font, "XYZ", coordsValue(mc), dirValue(mc)), 14};
            case "near": {
                List<AbstractClientPlayer> l = nearList(mc);
                if (l.isEmpty()) return new int[]{110, 14};
                int w = font.width("Сканер: " + l.size()) + 12;
                for (AbstractClientPlayer p : l) {
                    String dist = (int) mc.player.distanceTo(p) + "м";
                    w = Math.max(w, rowW(font, p.getName().getString(), dist));
                }
                return new int[]{w, 16 + 15 * l.size()};
            }
            case "keys":
                return new int[]{64, 42};
            case "target":
                return Esp.size();
            default: {
                int n = 0, w = 40;
                for (Module m : ModuleManager.ALL) {
                    if (m.enabled && !m.alwaysOn) {
                        n++;
                        w = Math.max(w, font.width(m.name) + 10);
                    }
                }
                return new int[]{w, Math.max(13, 15 * n)};
            }
        }
    }

    public static void draw(String id, GuiGraphics g, Font font, Minecraft mc, int x, int y, boolean preview) {
        switch (id) {
            case "watermark" -> {
                String t1 = "Blaze", t2 = "VisualsClient";
                int w = font.width(t1) + font.width(t2) + 14;
                Gfx.round(g, x, y, w, 16, BG);
                Gfx.rr(g, x, y + 3, 2, 10, 1, color(0f));
                g.drawString(font, t1, x + 7, y + 4, color(0f));
                g.drawString(font, t2, x + 7 + font.width(t1), y + 4, 0xFFFFFFFF);
            }
            case "fps" -> stat(g, font, "FPS", fpsValue(mc), "", x, y);
            case "coords" -> stat(g, font, "XYZ", coordsValue(mc), dirValue(mc), x, y);
            case "near" -> scanner(g, font, mc, x, y, preview);
            case "keys" -> {
                key(g, font, "W", mc.options.keyUp,    x + 22, y);
                key(g, font, "A", mc.options.keyLeft,  x,      y + 22);
                key(g, font, "S", mc.options.keyDown,  x + 22, y + 22);
                key(g, font, "D", mc.options.keyRight, x + 44, y + 22);
            }
            case "target" -> Esp.draw(g, font, x, y, preview);
            default -> arrayList(g, font, x, y, size("list", mc, font)[0]);
        }
    }

    private static String fpsValue(Minecraft mc) { return String.valueOf(mc.getFps()); }

    private static String coordsValue(Minecraft mc) {
        var p = mc.player.blockPosition();
        return p.getX() + " " + p.getY() + " " + p.getZ();
    }

    private static String dirValue(Minecraft mc) { return mc.player.getDirection().getName(); }

    private static int statW(Font font, String label, String value, String extra) {
        return 8 + font.width(label) + 4 + font.width(value)
                + (extra.isEmpty() ? 0 : 4 + font.width(extra)) + 6;
    }

    private static void stat(GuiGraphics g, Font font, String label, String value, String extra, int x, int y) {
        int w = statW(font, label, value, extra);
        Gfx.round(g, x, y, w, 14, BG);
        Gfx.rr(g, x, y + 3, 2, 8, 1, color(0.1f));
        int tx = x + 7;
        g.drawString(font, label, tx, y + 3, color(0.1f));
        tx += font.width(label) + 4;
        g.drawString(font, value, tx, y + 3, 0xFFFFFFFF);
        if (!extra.isEmpty()) {
            tx += font.width(value) + 4;
            g.drawString(font, extra, tx, y + 3, GREY);
        }
    }

    // ---------- Scanner: стрелки к игрокам + расстояние (до 150 м) ----------
    private static List<AbstractClientPlayer> nearList(Minecraft mc) {
        if (mc.level == null || mc.player == null) return List.of();
        double range = ModuleManager.SC_RADIUS.value;
        int max = ModuleManager.SC_MAX.value;
        return mc.level.players().stream()
                .filter(p -> p != mc.player && mc.player.distanceTo(p) <= range)
                .sorted(Comparator.comparingDouble(p -> mc.player.distanceTo(p)))
                .limit(max)
                .toList();
    }

    private static int rowW(Font font, String name, String dist) {
        return 22 + font.width(name) + 6 + font.width(dist) + 6;
    }

    private static void scanner(GuiGraphics g, Font font, Minecraft mc, int x, int y, boolean preview) {
        List<AbstractClientPlayer> list = nearList(mc);
        if (list.isEmpty() && !preview) return;

        String head = "Сканер: " + list.size();
        int hw = font.width(head) + 12;
        Gfx.round(g, x, y, hw, 14, BG);
        Gfx.rr(g, x, y + 3, 2, 8, 1, color(0.4f));
        g.drawString(font, head, x + 7, y + 3, color(0.4f));
        y += 16;

        float myYaw = mc.player.getYRot();
        for (AbstractClientPlayer p : list) {
            int d = (int) mc.player.distanceTo(p);
            String name = p.getName().getString();
            String dist = d + "м";

            // направление на игрока относительно твоего взгляда
            double dx = p.getX() - mc.player.getX();
            double dz = p.getZ() - mc.player.getZ();
            float yawTo = (float) (Mth.atan2(-dx, dz) * 180.0 / Math.PI);
            float rel = Mth.wrapDegrees(yawTo - myYaw);

            int dc = d < 30 ? 0xFFFF6B6B : (d < 80 ? 0xFFFFD166 : 0xFF9AE6A0);
            int w = rowW(font, name, dist);
            Gfx.round(g, x, y, w, 13, BG);
            Gfx.arrow(g, x + 10, y + 6, rel, dc);
            g.drawString(font, name, x + 22, y + 3, 0xFFFFFFFF);
            g.drawString(font, dist, x + 22 + font.width(name) + 6, y + 3, dc);
            y += 15;
        }
    }

    private static void arrayList(GuiGraphics g, Font font, int x, int y, int blockW) {
        List<Module> on = ModuleManager.ALL.stream()
                .filter(m -> m.enabled && !m.alwaysOn)
                .sorted(Comparator.comparingInt((Module m) -> font.width(m.name)).reversed())
                .toList();
        int i = 0;
        for (Module m : on) {
            int w = font.width(m.name) + 10;
            int rx = x + blockW - w;
            Gfx.round(g, rx, y, w, 13, BG);
            Gfx.rr(g, x + blockW - 2, y + 2, 2, 9, 1, color(i * 0.08f));
            g.drawString(font, m.name, rx + 4, y + 3, color(i * 0.08f));
            y += 15;
            i++;
        }
    }

    private static void key(GuiGraphics g, Font font, String label, KeyMapping k, int x, int y) {
        boolean down = k.isDown();
        int bg = down ? ((color(0.3f) & 0x00FFFFFF) | 0xC0000000) : BG;
        Gfx.rr(g, x, y, 20, 20, 4, bg);
        g.drawString(font, label, x + 10 - font.width(label) / 2, y + 6,
                down ? 0xFF101018 : 0xFFFFFFFF);
    }
}
