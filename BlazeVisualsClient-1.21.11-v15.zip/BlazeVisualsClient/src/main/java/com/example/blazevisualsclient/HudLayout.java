package com.example.blazevisualsclient;

import java.util.HashMap;
import java.util.Map;

/** Позиции HUD-элементов, которые игрок передвинул в редакторе. */
public final class HudLayout {
    private HudLayout() {}

    public static final String[] IDS = {"watermark", "fps", "coords", "near", "keys", "list", "target"};
    private static final Map<String, int[]> POS = new HashMap<>();

    public static int[] get(String id) { return POS.get(id); }
    public static void set(String id, int x, int y) { POS.put(id, new int[]{x, y}); }
    public static void reset() { POS.clear(); }
}
