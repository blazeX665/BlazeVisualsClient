package com.example.blazevisualsclient;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Сохранение модулей, настроек, команд и меток в config/blazevisualsclient.properties */
public class Config {
    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("blazevisualsclient.properties");
    }

    private static boolean storable(Setting s) {
        return s.kind != Setting.Kind.PRESETS && s.kind != Setting.Kind.BUTTON;
    }

    public static void load() {
        Properties p = new Properties();
        try (var in = Files.newInputStream(file());
             var reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
            p.load(reader);
        } catch (IOException e) {
            return; // файла ещё нет — значения по умолчанию
        }
        for (Module m : ModuleManager.ALL) {
            if (m != ModuleManager.ZOOM && !m.alwaysOn) {
                String v = p.getProperty("module." + m.name);
                if (v != null) {
                    m.enabled = Boolean.parseBoolean(v);
                    m.anim = m.enabled ? 1f : 0f;
                }
            }
            for (int i = 0; i < m.settings.size(); i++) {
                Setting s = m.settings.get(i);
                if (!storable(s)) continue;
                String v = p.getProperty("setting." + m.name + "." + i);
                if (v == null) continue;
                try {
                    if (s.kind == Setting.Kind.TOGGLE) s.on = Boolean.parseBoolean(v);
                    else s.value = Math.max(s.min, Math.min(s.max, Integer.parseInt(v.trim())));
                } catch (NumberFormatException ignored) { }
            }
        }
        for (int i = 0; i < KeyCommands.SLOTS; i++) {
            String v = p.getProperty("kc." + i);
            if (v != null) KeyCommands.COMMANDS[i] = v;
        }
        Waypoints.LIST.clear();
        try {
            int n = Integer.parseInt(p.getProperty("wp.count", "0"));
            for (int i = 0; i < n; i++) {
                String name = p.getProperty("wp." + i + ".name", "Метка");
                double x = Double.parseDouble(p.getProperty("wp." + i + ".x", "0"));
                double y = Double.parseDouble(p.getProperty("wp." + i + ".y", "64"));
                double z = Double.parseDouble(p.getProperty("wp." + i + ".z", "0"));
                Waypoints.add(name, x, y, z);
            }
        } catch (NumberFormatException ignored) { }
    }

    public static void save() {
        Properties p = new Properties();
        for (Module m : ModuleManager.ALL) {
            p.setProperty("module." + m.name, String.valueOf(m.enabled));
            for (int i = 0; i < m.settings.size(); i++) {
                Setting s = m.settings.get(i);
                if (!storable(s)) continue;
                p.setProperty("setting." + m.name + "." + i,
                        s.kind == Setting.Kind.TOGGLE ? String.valueOf(s.on) : String.valueOf(s.value));
            }
        }
        for (int i = 0; i < KeyCommands.SLOTS; i++) {
            p.setProperty("kc." + i, KeyCommands.COMMANDS[i] == null ? "" : KeyCommands.COMMANDS[i]);
        }
        p.setProperty("wp.count", String.valueOf(Waypoints.LIST.size()));
        for (int i = 0; i < Waypoints.LIST.size(); i++) {
            Waypoints.Waypoint w = Waypoints.LIST.get(i);
            p.setProperty("wp." + i + ".name", w.name);
            p.setProperty("wp." + i + ".x", String.valueOf(w.x));
            p.setProperty("wp." + i + ".y", String.valueOf(w.y));
            p.setProperty("wp." + i + ".z", String.valueOf(w.z));
        }
        try (var out = Files.newBufferedWriter(file(), StandardCharsets.UTF_8)) {
            p.store(out, "BlazeVisualsClient");
        } catch (IOException ignored) { }
    }
}
