package com.example.blazevisualsclient;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

/** Команды, привязанные к клавишам. Клавиши назначаются в Настройки → Управление. */
public final class KeyCommands {
    private KeyCommands() {}

    public static final int SLOTS = 6;
    public static final String[] COMMANDS = new String[SLOTS];
    public static final KeyMapping[] KEYS = new KeyMapping[SLOTS];

    static {
        for (int i = 0; i < SLOTS; i++) COMMANDS[i] = "";
    }

    public static void register(KeyMapping.Category category) {
        for (int i = 0; i < SLOTS; i++) {
            KEYS[i] = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                    "key.blazevisualsclient.cmd" + (i + 1), InputConstants.Type.KEYSYM,
                    GLFW.GLFW_KEY_UNKNOWN, category));
        }
    }

    public static void tick(Minecraft mc) {
        for (int i = 0; i < SLOTS; i++) {
            if (KEYS[i] == null) continue;
            while (KEYS[i].consumeClick()) {
                if (ModuleManager.KEY_COMMAND.enabled) run(mc, COMMANDS[i]);
            }
        }
    }

    private static void run(Minecraft mc, String cmd) {
        if (mc.player == null || cmd == null) return;
        cmd = cmd.trim();
        if (cmd.isEmpty()) return;
        if (cmd.startsWith("/")) mc.player.connection.sendCommand(cmd.substring(1));
        else mc.player.connection.sendChat(cmd);
    }
}
