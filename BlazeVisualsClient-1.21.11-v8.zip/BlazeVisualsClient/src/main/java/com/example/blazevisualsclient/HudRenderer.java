package com.example.blazevisualsclient;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.awt.Color;
import java.util.Comparator;
import java.util.List;

public class HudRenderer {
    private static final int BG = 0xA0101018;
    private static final int GREY = 0xFFAAAAAA;

    /** Цвет акцента: цвет темы или радуга. */
    public static int color(float offset) {
        if (!ModuleManager.RAINBOW.enabled) return Theme.accent();
        float h = ((System.currentTimeMillis() % 4000L) / 4000f + offset) % 1f;
        return Color.HSBtoRGB(h, 0.55f, 1f) | 0xFF000000;
    }

    public static void render(GuiGraphics g, float partial) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        Font font = mc.font;

        int y = 6;
        if (ModuleManager.WATERMARK.enabled) {
            String t1 = "Blaze", t2 = "VisualsClient";
            int w = font.width(t1) + font.width(t2) + 14;
            Gfx.round(g, 6, y, w, 16, BG);
            Gfx.rr(g, 6, y + 3, 2, 10, 1, color(0f));
            g.drawString(font, t1, 13, y + 4, color(0f));
            g.drawString(font, t2, 13 + font.width(t1), y + 4, 0xFFFFFFFF);
            y += 20;
        }
        if (ModuleManager.FPS.enabled) {
            y = stat(g, font, "FPS", String.valueOf(mc.getFps()), "", 6, y);
        }
        if (ModuleManager.COORDS.enabled) {
            var p = mc.player.blockPosition();
            y = stat(g, font, "XYZ", p.getX() + " " + p.getY() + " " + p.getZ(),
                    mc.player.getDirection().getName(), 6, y);
        }
        if (ModuleManager.BETTER_NEAR.enabled) {
            y = nearby(g, font, mc, 6, y + 2);
        }
        if (ModuleManager.KEYSTROKES.enabled) {
            keystrokes(g, font, mc, 6, mc.getWindow().getGuiScaledHeight() - 70);
        }
        if (ModuleManager.ARRAYLIST.enabled) {
            arrayList(g, font, mc);
        }
        Waypoints.render(g, font, mc, partial);
    }

    /** Better Near: игроки поблизости (до выбранного радиуса, максимум 100 блоков). */
    private static int nearby(GuiGraphics g, Font font, Minecraft mc, int x, int y) {
        if (mc.level == null) return y;
        double range = ModuleManager.BN_RANGE.value;
        int max = ModuleManager.BN_MAX.value;
        var list = mc.level.players().stream()
                .filter(p -> p != mc.player && mc.player.distanceTo(p) <= range)
                .sorted(Comparator.comparingDouble(p -> mc.player.distanceTo(p)))
                .limit(max)
                .toList();
        if (list.isEmpty()) return y;

        String head = "Рядом: " + list.size();
        int hw = font.width(head) + 12;
        Gfx.round(g, x, y, hw, 14, BG);
        Gfx.rr(g, x, y + 3, 2, 8, 1, color(0.4f));
        g.drawString(font, head, x + 7, y + 3, color(0.4f));
        y += 16;

        for (var p : list) {
            int d = (int) mc.player.distanceTo(p);
            String name = p.getName().getString();
            String dist = d + "м";
            int w = 8 + font.width(name) + 6 + font.width(dist) + 6;
            Gfx.round(g, x, y, w, 13, BG);
            int dc = d < 20 ? 0xFFFF6B6B : (d < 50 ? 0xFFFFD166 : 0xFF9AE6A0);
            g.drawString(font, name, x + 7, y + 3, 0xFFFFFFFF);
            g.drawString(font, dist, x + 7 + font.width(name) + 6, y + 3, dc);
            y += 15;
        }
        return y;
    }

    private static int stat(GuiGraphics g, Font font, String label, String value, String extra, int x, int y) {
        int w = 8 + font.width(label) + 4 + font.width(value)
                + (extra.isEmpty() ? 0 : 4 + font.width(extra)) + 6;
        Gfx.round(g, x, y, w, 14, BG);
        Gfx.rr(g, x, y + 3, 2, 8, 1, color(0.1f));
        int tx = x + 7;
        g.drawString(font, label, tx, y + 3, color(0.1f));
        tx += font.width(label) + 4;
        g.drawString(font, value, tx, y + 3, 0xFFFFFFFF);
        if (!extra.isEmpty()) {
            tx += font.width(value) + 4;
            g.drawString(font, extra, tx, y + 3, GREY);
        }
        return y + 17;
    }

    private static void arrayList(GuiGraphics g, Font font, Minecraft mc) {
        List<Module> on = ModuleManager.ALL.stream()
                .filter(m -> m.enabled && !m.alwaysOn)
                .sorted(Comparator.comparingInt((Module m) -> font.width(m.name)).reversed())
                .toList();
        int sw = mc.getWindow().getGuiScaledWidth();
        int y = 6, i = 0;
        for (Module m : on) {
            int w = font.width(m.name) + 10;
            int x = sw - w - 8;
            Gfx.round(g, x, y, w, 13, BG);
            Gfx.rr(g, sw - 8, y + 2, 2, 9, 1, color(i * 0.08f));
            g.drawString(font, m.name, x + 4, y + 3, color(i * 0.08f));
            y += 15;
            i++;
        }
    }

    private static void keystrokes(GuiGraphics g, Font font, Minecraft mc, int x, int y) {
        key(g, font, "W", mc.options.keyUp,    x + 22, y);
        key(g, font, "A", mc.options.keyLeft,  x,      y + 22);
        key(g, font, "S", mc.options.keyDown,  x + 22, y + 22);
        key(g, font, "D", mc.options.keyRight, x + 44, y + 22);
    }

    private static void key(GuiGraphics g, Font font, String label, KeyMapping k, int x, int y) {
        boolean down = k.isDown();
        int bg = down ? ((color(0.3f) & 0x00FFFFFF) | 0xC0000000) : BG;
        Gfx.rr(g, x, y, 20, 20, 4, bg);
        g.drawString(font, label, x + 10 - font.width(label) / 2, y + 6,
                down ? 0xFF101018 : 0xFFFFFFFF);
    }
}
