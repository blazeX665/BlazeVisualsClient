package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Своё главное меню BlazeVisualsClient (заменяет ванильное, пока включён модуль Custom Menu). */
public class BlazeTitleScreen extends Screen {
    /** true — игрок сам открыл «Классическое меню», подмену не делаем. */
    public static boolean vanilla = false;

    private static final String[] LABELS = {"Одиночная игра", "Сетевая игра", "Настройки", "Выйти из игры"};
    private static final int BTN_H = 24, STEP = 30;

    // пиксельные буквы 5x7 для логотипа BLAZE
    private static final String[][] GLYPHS = {
            {"####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."},   // B
            {"#....", "#....", "#....", "#....", "#....", "#....", "#####"},   // L
            {".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"},   // A
            {"#####", "....#", "...#.", "..#..", ".#...", "#....", "#####"},   // Z
            {"#####", "#....", "#....", "####.", "#....", "#....", "#####"}    // E
    };

    private final float[] hover = new float[5];
    private final long start = System.currentTimeMillis();

    public BlazeTitleScreen() { super(Component.literal("BlazeVisualsClient")); }

    private int px() { return height < 300 ? 3 : 5; }
    private int bw() { return Math.min(220, width - 40); }
    private int bx() { return (width - bw()) / 2; }
    private int top() {
        int total = 7 * px() + 6 + 12 + 14 + 4 * STEP + 22;
        return Math.max(6, (height - total) / 2);
    }
    private int firstBtnY() { return top() + 7 * px() + 6 + 12 + 14; }
    private int btnY(int i) { return firstBtnY() + i * STEP; }
    private int altY() { return firstBtnY() + 4 * STEP + 2; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        double t = (System.currentTimeMillis() - start) / 1000.0;
        int accent = HudRenderer.color(0f);
        int rgb = accent & 0x00FFFFFF;

        // фон: тёмный вертикальный градиент полосами
        int bands = Math.max(1, height / 3);
        for (int i = 0; i < bands; i++) {
            float f = i / (float) bands;
            int c = Gfx.lerp(0xFF0B0B10, 0xFF15101A, f);
            g.fill(0, i * 3, width, i * 3 + 3, c);
        }

        // мягкие светящиеся пятна цвета темы
        for (int k = 0; k < 3; k++) {
            double ax = 0.5 + 0.38 * Math.sin(t * 0.25 + k * 2.1);
            double ay = 0.5 + 0.35 * Math.cos(t * 0.21 + k * 1.7);
            int cx = (int) (width * ax), cy = (int) (height * ay);
            for (int j = 0; j < 4; j++) {
                int r = 56 - j * 12;
                Gfx.rr(g, cx - r, cy - r, r * 2, r * 2, r, (rgb) | 0x0B000000);
            }
        }

        // логотип BLAZE пиксельными буквами
        int s = px();
        int letterW = 5 * s, gap = s;
        int totalW = GLYPHS.length * letterW + (GLYPHS.length - 1) * gap;
        int lx = (width - totalW) / 2, ly = top();
        for (int li = 0; li < GLYPHS.length; li++) {
            int col = HudRenderer.color(li * 0.12f);
            drawGlyph(g, GLYPHS[li], lx + li * (letterW + gap) + 2, ly + 2, s, 0xAA000000); // тень
            drawGlyph(g, GLYPHS[li], lx + li * (letterW + gap), ly, s, col);
        }
        String sub = "VisualsClient";
        g.drawString(font, sub, (width - font.width(sub)) / 2, ly + 7 * s + 6, 0xFFF2F2F5);

        // кнопки
        for (int i = 0; i < 5; i++) {
            boolean alt = i == 4;
            int by = alt ? altY() : btnY(i);
            int h = alt ? 16 : BTN_H;
            boolean hov = mx >= bx() && mx < bx() + bw() && my >= by && my < by + h;
            hover[i] += ((hov ? 1f : 0f) - hover[i]) * 0.3f;

            int fill = Gfx.lerp(alt ? 0xFF16161C : 0xFF1F1F25, alt ? 0xFF22222A : 0xFF2A2A33, hover[i]);
            int edge = Gfx.lerp(0xFF2E2E38, accent, hover[i]);
            Gfx.rr(g, bx(), by, bw(), h, alt ? 6 : 8, edge);
            Gfx.rr(g, bx() + 1, by + 1, bw() - 2, h - 2, alt ? 5 : 7, fill);
            if (!alt) Gfx.rr(g, bx() + 8, by + 6, 2, h - 12, 1, Gfx.lerp(0xFF3A3A44, accent, hover[i]));

            String label = alt ? "Классическое меню (моды)" : LABELS[i];
            int tc = alt ? 0xFF9A9AA3 : Gfx.lerp(0xFFF2F2F5, accent, hover[i]);
            g.drawString(font, label, (width - font.width(label)) / 2, by + (h - 8) / 2, tc);
        }

        // подписи
        g.drawString(font, "Minecraft 1.21.11 · Fabric", 6, height - 12, 0xFF6C6C75);
        String right = "BlazeVisualsClient v1.5 · меню в игре: Right Shift";
        g.drawString(font, right, width - font.width(right) - 6, height - 12, 0xFF6C6C75);
    }

    private static void drawGlyph(GuiGraphics g, String[] rows, int x, int y, int s, int color) {
        for (int r = 0; r < rows.length; r++) {
            for (int c = 0; c < rows[r].length(); c++) {
                if (rows[r].charAt(c) == '#') {
                    g.fill(x + c * s, y + r * s, x + c * s + s, y + r * s + s, color);
                }
            }
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        double mx = event.x(), my = event.y();
        Minecraft mc = Minecraft.getInstance();

        for (int i = 0; i < 5; i++) {
            boolean alt = i == 4;
            int by = alt ? altY() : btnY(i);
            int h = alt ? 16 : BTN_H;
            if (mx >= bx() && mx < bx() + bw() && my >= by && my < by + h) {
                switch (i) {
                    case 0 -> mc.setScreen(new SelectWorldScreen(this));
                    case 1 -> mc.setScreen(new JoinMultiplayerScreen(this));
                    case 2 -> mc.setScreen(new OptionsScreen(this, mc.options));
                    case 3 -> mc.stop();
                    default -> {
                        vanilla = true;
                        mc.setScreen(new TitleScreen());
                    }
                }
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    public boolean isPauseScreen() { return false; }
}
