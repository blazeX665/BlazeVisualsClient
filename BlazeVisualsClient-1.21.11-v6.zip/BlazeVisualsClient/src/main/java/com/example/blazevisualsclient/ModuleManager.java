package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;

import java.util.List;

public class ModuleManager {
    // --- цвет темы (HUD и меню) ---
    public static final Setting THEME_H = Setting.slider("Оттенок", 20, 0, 360, "°");
    public static final Setting THEME_S = Setting.slider("Насыщенность", 88, 0, 100, "%");
    public static final Setting THEME_B = Setting.slider("Яркость", 100, 30, 100, "%");

    // --- небо ---
    public static final Setting SKY_H = Setting.slider("Оттенок", 275, 0, 360, "°");
    public static final Setting SKY_S = Setting.slider("Насыщенность", 55, 0, 100, "%");
    public static final Setting SKY_B = Setting.slider("Яркость", 65, 0, 100, "%");

    // --- No Render ---
    public static final Setting NR_FIRE  = Setting.toggle("Огонь на экране", true);
    public static final Setting NR_WATER = Setting.toggle("Вода на экране", true);
    public static final Setting NR_WALL  = Setting.toggle("Блок в лице", true);
    public static final Setting NR_FOG   = Setting.toggle("Туман (вода/лава/снег)", true);

    // --- Block Overlay ---
    public static final Setting BO_H     = Setting.slider("Оттенок", 20, 0, 360, "°");
    public static final Setting BO_S     = Setting.slider("Насыщенность", 88, 0, 100, "%");
    public static final Setting BO_B     = Setting.slider("Яркость", 100, 30, 100, "%");
    public static final Setting BO_ALPHA = Setting.slider("Прозрачность", 100, 10, 100, "%");
    public static final Setting BO_WIDTH = Setting.slider("Толщина", 3, 1, 8, "");

    // --- Item Physics ---
    public static final Setting IP_HOVER = Setting.slider("Высота над землёй", 2, 0, 20, "");

    // --- Swing Animation ---
    public static final Setting SW_SPEED = Setting.slider("Скорость", 100, 40, 250, "%");
    public static final Setting SW_STYLE = Setting.choice("Стиль", 0, "Обычный", "Плавный", "Разгон", "Резкий");

    // --- View Model ---
    public static final Setting VM_X     = Setting.slider("Смещение X", 0, -100, 100, "");
    public static final Setting VM_Y     = Setting.slider("Смещение Y", 0, -100, 100, "");
    public static final Setting VM_Z     = Setting.slider("Смещение Z", 0, -100, 100, "");
    public static final Setting VM_SCALE = Setting.slider("Размер", 100, 30, 200, "%");
    public static final Setting VM_RX    = Setting.slider("Поворот X", 0, -180, 180, "°");
    public static final Setting VM_RY    = Setting.slider("Поворот Y", 0, -180, 180, "°");
    public static final Setting VM_RZ    = Setting.slider("Поворот Z", 0, -180, 180, "°");

    // --- Zoom / Optimization ---
    public static final Setting ZOOM_FOV    = Setting.step("Zoom FOV", 30, 30, 60, 5, "");
    public static final Setting OPT_EFFECTS = Setting.toggle("Меньше эффектов", true);
    public static final Setting OPT_UNLOCK  = Setting.toggle("Разблокировать FPS", true);
    public static final Setting OPT_RENDER  = Setting.step("Прорисовка (чанки)", 8, 2, 32, 2, "");
    public static final Setting OPT_SIM     = Setting.step("Симуляция (чанки)", 5, 5, 16, 1, "");
    public static final Setting OPT_ENTITY  = Setting.step("Сущности (%)", 50, 50, 150, 25, "%");

    // --- Better Near / Waypoints ---
    public static final Setting BN_RANGE = Setting.slider("Радиус", 100, 10, 100, "м");
    public static final Setting BN_MAX   = Setting.step("Макс. игроков", 6, 3, 12, 1, "");
    public static final Setting WP_DIST  = Setting.toggle("Показывать дистанцию", true);

    // ================= Visuals =================
    public static final Module COLOR = new Module("Color", "Цвет HUD и меню", "Visuals", true)
            .alwaysOn()
            .add(Setting.presets("Пресеты", THEME_H, THEME_S, THEME_B))
            .add(THEME_H).add(THEME_S).add(THEME_B);
    public static final Module RAINBOW    = new Module("Rainbow", "Радужный HUD", "Visuals", false);
    public static final Module FULLBRIGHT = new Module("Fullbright", "Яркость на максимум (B)", "Visuals", false);
    public static final Module SKY = new Module("Custom Sky", "Своё небо любого цвета", "Visuals", false)
            .add(Setting.presets("Пресеты", SKY_H, SKY_S, SKY_B))
            .add(SKY_H).add(SKY_S).add(SKY_B);
    public static final Module NO_RENDER = new Module("No Render", "Без огня, тумана, оверлеев", "Visuals", false)
            .add(NR_FIRE).add(NR_WATER).add(NR_WALL).add(NR_FOG);
    public static final Module BLOCK_OVERLAY = new Module("Block Overlay", "Цвет и толщина рамки блока", "Visuals", false)
            .add(Setting.presets("Пресеты", BO_H, BO_S, BO_B))
            .add(BO_H).add(BO_S).add(BO_B).add(BO_ALPHA).add(BO_WIDTH);
    public static final Module ITEM_PHYSICS = new Module("Item Physics", "Предметы лежат на земле", "Visuals", false)
            .add(IP_HOVER);
    public static final Module SWING = new Module("Swing Animation", "Скорость и стиль ударов", "Visuals", false)
            .add(SW_SPEED).add(SW_STYLE);
    public static final Module VIEW_MODEL = new Module("View Model", "Положение рук и предметов", "Visuals", false)
            .add(VM_X).add(VM_Y).add(VM_Z).add(VM_SCALE).add(VM_RX).add(VM_RY).add(VM_RZ);

    // ================= Utilities =================
    public static final Module AUTO_SPRINT = new Module("Auto Sprint", "Бег без зажатия клавиши", "Utilities", false);
    public static final Module ZOOM = new Module("Zoom", "Приближение (C)", "Utilities", false)
            .add(ZOOM_FOV);
    public static final Module OPTIMIZATION = new Module("Optimization", "Повышение FPS", "Utilities", false)
            .add(OPT_EFFECTS).add(OPT_UNLOCK).add(OPT_RENDER).add(OPT_SIM).add(OPT_ENTITY);
    public static final Module KEY_COMMAND = new Module("KeyCommand", "Команды на клавиши", "Utilities", true)
            .add(Setting.button("Настроить команды", () -> Minecraft.getInstance().setScreen(new KeyCommandScreen())));

    // ================= Client (HUD) =================
    public static final Module WATERMARK  = new Module("Watermark", "Название сверху слева", "Client", true);
    public static final Module FPS        = new Module("FPS", "Счётчик кадров", "Client", true);
    public static final Module COORDS     = new Module("Coordinates", "Координаты и сторона света", "Client", true);
    public static final Module KEYSTROKES = new Module("Keystrokes", "WASD на экране", "Client", true);
    public static final Module ARRAYLIST  = new Module("ArrayList", "Список включённых модулей", "Client", true);
    public static final Module BETTER_NEAR = new Module("Better Near", "Игроки рядом до 100 блоков", "Client", false)
            .add(BN_RANGE).add(BN_MAX);
    public static final Module WAYPOINTS = new Module("Waypoints", "Метки по координатам", "Client", true)
            .add(Setting.button("Управление метками", () -> Minecraft.getInstance().setScreen(new WaypointScreen())))
            .add(WP_DIST);

    public static final List<Module> ALL = List.of(
            COLOR, RAINBOW, FULLBRIGHT, SKY, NO_RENDER, BLOCK_OVERLAY, ITEM_PHYSICS, SWING, VIEW_MODEL,
            AUTO_SPRINT, ZOOM, OPTIMIZATION, KEY_COMMAND,
            WATERMARK, FPS, COORDS, KEYSTROKES, ARRAYLIST, BETTER_NEAR, WAYPOINTS
    );

    public static List<Module> inCategory(String category) {
        return ALL.stream().filter(m -> m.category.equals(category)).toList();
    }
}
