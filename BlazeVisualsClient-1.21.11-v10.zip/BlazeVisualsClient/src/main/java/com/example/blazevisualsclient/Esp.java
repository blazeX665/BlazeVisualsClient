package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** ESP (Target HUD): маленькая панель со здоровьем и бронёй цели, на которую ты смотришь. */
public final class Esp {
    private Esp() {}

    private static final int W = 136;
    private static final int BG = 0xB0101018;
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final String[] PIECES = {"Шлем", "Нагрудник", "Штаны", "Ботинки"};

    private static LivingEntity target = null;
    private static long lastSeen = 0L;

    private record ArmorRow(String piece, String material, int pct, int matColor) {}

    public static boolean has() { return target != null; }

    public static void tick(Minecraft mc) {
        if (!ModuleManager.ESP.enabled || mc.player == null || mc.level == null) {
            target = null;
            return;
        }
        long now = System.currentTimeMillis();
        if (mc.hitResult instanceof EntityHitResult hit
                && hit.getEntity() instanceof LivingEntity le && le != mc.player) {
            if (le instanceof Player || ModuleManager.ESP_MOBS.on) {
                target = le;
                lastSeen = now;
            }
        }
        if (target != null) {
            if (!target.isAlive() || target.isRemoved()
                    || now - lastSeen > ModuleManager.ESP_HOLD.value * 1000L) {
                target = null;
            }
        }
    }

    // ---------- данные ----------
    private static List<ArmorRow> collect(LivingEntity le) {
        List<ArmorRow> rows = new ArrayList<>();
        if (!ModuleManager.ESP_ARMOR.on) return rows;
        for (int i = 0; i < SLOTS.length; i++) {
            ItemStack st = le.getItemBySlot(SLOTS[i]);
            if (st.isEmpty()) continue;
            String id = st.getDescriptionId();
            String path = id.substring(id.lastIndexOf('.') + 1);
            String prefix = path.contains("_") ? path.substring(0, path.indexOf('_')) : path;
            int pct = -1;
            if (st.isDamageableItem() && st.getMaxDamage() > 0) {
                pct = (int) ((st.getMaxDamage() - st.getDamageValue()) * 100L / st.getMaxDamage());
            }
            rows.add(new ArmorRow(PIECES[i], materialName(prefix), pct, materialColor(prefix)));
        }
        return rows;
    }

    private static String materialName(String prefix) {
        return switch (prefix) {
            case "netherite" -> "Незерит";
            case "diamond" -> "Алмаз";
            case "iron" -> "Железо";
            case "chainmail" -> "Кольчуга";
            case "golden" -> "Золото";
            case "leather" -> "Кожа";
            case "turtle" -> "Черепаха";
            case "copper" -> "Медь";
            case "elytra" -> "Элитры";
            default -> "Другое";
        };
    }

    private static int materialColor(String prefix) {
        return switch (prefix) {
            case "netherite" -> 0xFFB58CFF;
            case "diamond" -> 0xFF5EE6E6;
            case "iron" -> 0xFFE0E0E0;
            case "chainmail" -> 0xFFA8A8B3;
            case "golden" -> 0xFFFFD166;
            case "leather" -> 0xFFC48A5A;
            case "turtle" -> 0xFF7FE08A;
            case "copper" -> 0xFFE8905A;
            default -> 0xFFCCCCCC;
        };
    }

    private static int pctColor(int pct) {
        if (pct < 0) return 0xFFAAAAAA;
        return pct > 50 ? 0xFF7FE08A : (pct > 25 ? 0xFFFFD166 : 0xFFFF6B6B);
    }

    private static String fmt(float v) {
        return String.format(Locale.ROOT, "%.1f", v);
    }

    private static List<ArmorRow> sampleRows() {
        List<ArmorRow> r = new ArrayList<>();
        r.add(new ArmorRow("Шлем", "Алмаз", 87, materialColor("diamond")));
        r.add(new ArmorRow("Нагрудник", "Незерит", 64, materialColor("netherite")));
        r.add(new ArmorRow("Штаны", "Железо", 42, materialColor("iron")));
        r.add(new ArmorRow("Ботинки", "Кольчуга", 15, materialColor("chainmail")));
        return r;
    }

    private static int heightFor(int armorRows) {
        return 35 + (armorRows > 0 ? armorRows * 10 + 3 : 0) + 4;
    }

    // ---------- размер и отрисовка ----------
    public static int[] size() {
        int n = target != null ? collect(target).size() : sampleRows().size();
        return new int[]{W, heightFor(n)};
    }

    public static void draw(GuiGraphics g, Font font, int x, int y, boolean preview) {
        String name;
        float hp, max;
        int armorValue = 0;
        List<ArmorRow> armor;
        if (target != null) {
            name = target.getName().getString();
            hp = target.getHealth();
            max = Math.max(1f, target.getMaxHealth());
            armorValue = target.getArmorValue();
            armor = collect(target);
        } else if (preview) {
            name = "Игрок";
            hp = 18f;
            max = 20f;
            armorValue = 20;
            armor = sampleRows();
        } else {
            return;
        }

        int h = heightFor(armor.size());
        int accent = HudRenderer.color(0.2f);
        Gfx.rr(g, x, y, W, h, 5, BG);
        Gfx.rr(g, x, y + 4, 2, h - 8, 1, accent);

        g.drawString(font, name, x + 7, y + 4, 0xFFFFFFFF);
        if (armorValue > 0 && ModuleManager.ESP_ARMOR.on) {
            String av = "Защ. " + armorValue;
            g.drawString(font, av, x + W - 6 - font.width(av), y + 4, 0xFF9A9AA3);
        }

        float frac = Math.max(0f, Math.min(1f, hp / max));
        int hpColor = frac > 0.6f ? 0xFF7FE08A : (frac > 0.3f ? 0xFFFFD166 : 0xFFFF6B6B);
        g.drawString(font, "HP " + fmt(hp) + " / " + fmt(max), x + 7, y + 16, hpColor);
        Gfx.rr(g, x + 7, y + 27, W - 14, 4, 2, 0xFF2C2C34);
        int fw = (int) ((W - 14) * frac);
        if (fw > 0) Gfx.rr(g, x + 7, y + 27, Math.max(3, fw), 4, 2, hpColor);

        int ry = y + 35;
        for (ArmorRow r : armor) {
            g.drawString(font, r.piece(), x + 7, ry, 0xFF9A9AA3);
            g.drawString(font, r.material(), x + 7 + 52, ry, r.matColor());
            String pct = r.pct() < 0 ? "—" : r.pct() + "%";
            g.drawString(font, pct, x + W - 6 - font.width(pct), ry, pctColor(r.pct()));
            ry += 10;
        }
    }
}
