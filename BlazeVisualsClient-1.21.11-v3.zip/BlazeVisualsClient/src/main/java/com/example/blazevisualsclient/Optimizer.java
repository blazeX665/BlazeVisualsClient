package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;

/** Оптимизация FPS: меняет настройки игры и возвращает их при выключении. */
public class Optimizer {
    private static boolean active = false;

    private static int oRender, oSim, oFps, oBlend;
    private static double oEntity;
    private static boolean oShadows, oVsync;
    private static ParticleStatus oParticles;

    public static void tick(Minecraft mc) {
        Options o = mc.options;
        boolean on = ModuleManager.OPTIMIZATION.enabled;
        if (on && !active) {
            save(o);
            active = true;
        }
        if (on) {
            apply(o);
        } else if (active) {
            restore(o);
            active = false;
        }
    }

    public static void shutdown(Minecraft mc) {
        if (active) {
            restore(mc.options);
            active = false;
        }
    }

    private static void save(Options o) {
        oRender = o.renderDistance().get();
        oSim = o.simulationDistance().get();
        oFps = o.framerateLimit().get();
        oBlend = o.biomeBlendRadius().get();
        oEntity = o.entityDistanceScaling().get();
        oShadows = o.entityShadows().get();
        oVsync = o.enableVsync().get();
        oParticles = o.particles().get();
    }

    private static void apply(Options o) {
        o.renderDistance().set(ModuleManager.OPT_RENDER.value);
        o.simulationDistance().set(ModuleManager.OPT_SIM.value);
        o.entityDistanceScaling().set(ModuleManager.OPT_ENTITY.value / 100.0);

        if (ModuleManager.OPT_EFFECTS.on) {
            o.particles().set(ParticleStatus.MINIMAL);
            o.entityShadows().set(false);
            o.biomeBlendRadius().set(0);
        } else {
            o.particles().set(oParticles);
            o.entityShadows().set(oShadows);
            o.biomeBlendRadius().set(oBlend);
        }

        if (ModuleManager.OPT_UNLOCK.on) {
            o.enableVsync().set(false);
            o.framerateLimit().set(260); // 260 = без лимита
        } else {
            o.enableVsync().set(oVsync);
            o.framerateLimit().set(oFps);
        }
    }

    private static void restore(Options o) {
        o.renderDistance().set(oRender);
        o.simulationDistance().set(oSim);
        o.entityDistanceScaling().set(oEntity);
        o.particles().set(oParticles);
        o.entityShadows().set(oShadows);
        o.biomeBlendRadius().set(oBlend);
        o.enableVsync().set(oVsync);
        o.framerateLimit().set(oFps);
    }
}
