package com.example.blazevisualsclient;

import java.util.List;

public class ModuleManager {
    // --- цвет темы (HUD и меню) ---
    public static final Setting THEME_H = Setting.slider("Оттенок", 20, 0, 360, "°");
    public static final Setting THEME_S = Setting.slider("Насыщенность", 88, 0, 100, "%");
    public static final Setting THEME_B = Setting.slider("Яркость", 100, 30, 100, "%");

    // --- цвет неба ---
    public static final Setting SKY_H = Setting.slider("Оттенок", 275, 0, 360, "°");
    public static final Setting SKY_S = Setting.slider("Насыщенность", 55, 0, 100, "%");
    public static final Setting SKY_B = Setting.slider("Яркость", 65, 0, 100, "%");

    // --- No Render ---
    public static final Setting NR_FIRE  = Setting.toggle("Огонь на экране", true);
    public static final Setting NR_WATER = Setting.toggle("Вода на экране", true);
    public static final Setting NR_WALL  = Setting.toggle("Блок в лице", true);
    public static final Setting NR_FOG   = Setting.toggle("Туман (вода/лава/снег)", true);

    // --- Zoom / Optimization ---
    public static final Setting ZOOM_FOV    = Setting.step("Zoom FOV", 30, 30, 60, 5, "");
    public static final Setting OPT_EFFECTS = Setting.toggle("Меньше эффектов", true);
    public static final Setting OPT_UNLOCK  = Setting.toggle("Разблокировать FPS", true);
    public static final Setting OPT_RENDER  = Setting.step("Прорисовка (чанки)", 8, 2, 32, 2, "");
    public static final Setting OPT_SIM     = Setting.step("Симуляция (чанки)", 5, 5, 16, 1, "");
    public static final Setting OPT_ENTITY  = Setting.step("Сущности (%)", 50, 50, 150, 25, "%");

    // --- Visuals ---
    public static final Module COLOR = new Module("Color", "Цвет HUD и меню — любой", "Visuals", true)
            .alwaysOn()
            .add(Setting.presets("Пресеты", THEME_H, THEME_S, THEME_B))
            .add(THEME_H).add(THEME_S).add(THEME_B);
    public static final Module RAINBOW    = new Module("Rainbow", "Радужные цвета HUD", "Visuals", false);
    public static final Module FULLBRIGHT = new Module("Fullbright", "Максимальная яркость (клавиша B)", "Visuals", false);
    public static final Module SKY = new Module("Custom Sky", "Своё небо любого цвета", "Visuals", false)
            .add(Setting.presets("Пресеты", SKY_H, SKY_S, SKY_B))
            .add(SKY_H).add(SKY_S).add(SKY_B);
    public static final Module NO_RENDER = new Module("No Render", "Без огня, тумана и оверлеев", "Visuals", false)
            .add(NR_FIRE).add(NR_WATER).add(NR_WALL).add(NR_FOG);

    // --- Utilities ---
    public static final Module ZOOM = new Module("Zoom", "Приближение (клавиша C)", "Utilities", false)
            .add(ZOOM_FOV);
    public static final Module OPTIMIZATION = new Module("Optimization", "Повышение FPS", "Utilities", false)
            .add(OPT_EFFECTS).add(OPT_UNLOCK).add(OPT_RENDER).add(OPT_SIM).add(OPT_ENTITY);

    // --- Client (HUD) ---
    public static final Module WATERMARK  = new Module("Watermark", "Название мода сверху слева", "Client", true);
    public static final Module FPS        = new Module("FPS", "Счётчик кадров", "Client", true);
    public static final Module COORDS     = new Module("Coordinates", "Координаты и направление", "Client", true);
    public static final Module KEYSTROKES = new Module("Keystrokes", "WASD на экране", "Client", true);
    public static final Module ARRAYLIST  = new Module("ArrayList", "Список включённых модулей", "Client", true);

    public static final List<Module> ALL = List.of(
            COLOR, RAINBOW, FULLBRIGHT, SKY, NO_RENDER,
            ZOOM, OPTIMIZATION,
            WATERMARK, FPS, COORDS, KEYSTROKES, ARRAYLIST
    );

    public static List<Module> inCategory(String category) {
        return ALL.stream().filter(m -> m.category.equals(category)).toList();
    }
}
