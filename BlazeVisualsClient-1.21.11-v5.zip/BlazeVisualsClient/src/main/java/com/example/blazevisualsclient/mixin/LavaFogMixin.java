package com.example.blazevisualsclient.mixin;

import com.example.blazevisualsclient.NoRender;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.fog.FogData;
import net.minecraft.client.renderer.fog.environment.LavaFogEnvironment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LavaFogEnvironment.class)
public class LavaFogMixin {
    @Inject(method = "setupFog", at = @At("TAIL"))
    private void blaze$noFog(FogData data, Camera camera, ClientLevel level, float renderDistance,
                             DeltaTracker deltaTracker, CallbackInfo ci) {
        NoRender.clearFog(data);
    }
}
