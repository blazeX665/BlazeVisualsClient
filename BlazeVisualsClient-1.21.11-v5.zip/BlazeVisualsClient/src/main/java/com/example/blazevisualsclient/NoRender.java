package com.example.blazevisualsclient;

import net.minecraft.client.renderer.fog.FogData;

/** Проверки и помощники для модуля No Render (используются из миксинов). */
public final class NoRender {
    private NoRender() {}

    public static boolean fire()  { return ModuleManager.NO_RENDER.enabled && ModuleManager.NR_FIRE.on; }
    public static boolean water() { return ModuleManager.NO_RENDER.enabled && ModuleManager.NR_WATER.on; }
    public static boolean wall()  { return ModuleManager.NO_RENDER.enabled && ModuleManager.NR_WALL.on; }
    public static boolean fog()   { return ModuleManager.NO_RENDER.enabled && ModuleManager.NR_FOG.on; }

    /** Делает «особый» туман (вода/лава/снег) таким же, как обычный туман дальности прорисовки. */
    public static void clearFog(FogData d) {
        if (!fog()) return;
        if (d.renderDistanceEnd > 16f) {
            d.environmentalStart = d.renderDistanceStart;
            d.environmentalEnd = d.renderDistanceEnd;
            d.skyEnd = d.renderDistanceEnd;
            d.cloudEnd = d.renderDistanceEnd;
        } else {
            d.environmentalStart = 999999f;
            d.environmentalEnd = 1000000f;
            d.skyEnd = 1000000f;
            d.cloudEnd = 1000000f;
        }
    }
}
