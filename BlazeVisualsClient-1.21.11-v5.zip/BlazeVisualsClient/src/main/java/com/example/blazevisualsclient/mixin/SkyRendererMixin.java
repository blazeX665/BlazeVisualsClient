package com.example.blazevisualsclient.mixin;

import com.example.blazevisualsclient.ModuleManager;
import com.example.blazevisualsclient.Theme;
import net.minecraft.client.renderer.SkyRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(SkyRenderer.class)
public class SkyRendererMixin {
    @ModifyVariable(method = "renderSkyDisc", at = @At("HEAD"), argsOnly = true)
    private int blaze$customSky(int color) {
        return ModuleManager.SKY.enabled ? Theme.sky() : color;
    }
}
