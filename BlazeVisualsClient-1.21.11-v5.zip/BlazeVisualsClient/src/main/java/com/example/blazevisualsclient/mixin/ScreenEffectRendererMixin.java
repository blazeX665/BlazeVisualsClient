package com.example.blazevisualsclient.mixin;

import com.example.blazevisualsclient.NoRender;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ScreenEffectRenderer.class)
public class ScreenEffectRendererMixin {
    @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true)
    private static void blaze$noFire(CallbackInfo ci) {
        if (NoRender.fire()) ci.cancel();
    }

    @Inject(method = "renderWater", at = @At("HEAD"), cancellable = true)
    private static void blaze$noWater(CallbackInfo ci) {
        if (NoRender.water()) ci.cancel();
    }

    @Inject(method = "renderTex", at = @At("HEAD"), cancellable = true)
    private static void blaze$noWall(CallbackInfo ci) {
        if (NoRender.wall()) ci.cancel();
    }
}
