package com.example.blazevisualsclient;

/** Настройка модуля: переключатель, число (-/+), ползунок или набор цветов-пресетов. */
public class Setting {
    public enum Kind { TOGGLE, STEP, SLIDER, PRESETS }

    public final String name;
    public final Kind kind;
    public boolean on;
    public int value;
    public final int min, max, step;
    public final String suffix;
    // для PRESETS: какие три настройки (H, S, B) менять
    public final Setting linkH, linkS, linkB;

    private Setting(String name, Kind kind, boolean on, int value, int min, int max, int step,
                    String suffix, Setting h, Setting s, Setting b) {
        this.name = name;
        this.kind = kind;
        this.on = on;
        this.value = value;
        this.min = min;
        this.max = max;
        this.step = step;
        this.suffix = suffix;
        this.linkH = h;
        this.linkS = s;
        this.linkB = b;
    }

    public static Setting toggle(String name, boolean def) {
        return new Setting(name, Kind.TOGGLE, def, 0, 0, 0, 0, "", null, null, null);
    }

    public static Setting step(String name, int def, int min, int max, int step, String suffix) {
        return new Setting(name, Kind.STEP, false, def, min, max, step, suffix, null, null, null);
    }

    public static Setting slider(String name, int def, int min, int max, String suffix) {
        return new Setting(name, Kind.SLIDER, false, def, min, max, 1, suffix, null, null, null);
    }

    public static Setting presets(String name, Setting h, Setting s, Setting b) {
        return new Setting(name, Kind.PRESETS, false, 0, 0, 0, 0, "", h, s, b);
    }

    public void inc() { value = Math.min(max, value + step); }
    public void dec() { value = Math.max(min, value - step); }
}
