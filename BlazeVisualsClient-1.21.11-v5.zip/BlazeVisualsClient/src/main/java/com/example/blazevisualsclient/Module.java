package com.example.blazevisualsclient;

import java.util.ArrayList;
import java.util.List;

public class Module {
    public final String name;
    public final String description;
    public final String category;
    public final List<Setting> settings = new ArrayList<>();
    public boolean enabled;
    public boolean alwaysOn;   // карточка без переключателя (только настройки)
    public float anim;         // 0..1 для плавного переключателя
    public float hover;        // 0..1 для плавной подсветки карточки

    public Module(String name, String description, String category, boolean enabled) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = enabled;
        this.anim = enabled ? 1f : 0f;
    }

    public Module add(Setting s) {
        settings.add(s);
        return this;
    }

    public Module alwaysOn() {
        this.alwaysOn = true;
        this.enabled = true;
        this.anim = 1f;
        return this;
    }

    public void toggle() { if (!alwaysOn) enabled = !enabled; }
}
