package com.example.blazevisualsclient;

import java.awt.Color;

public final class Theme {
    private Theme() {}

    /** Пресеты: {оттенок, насыщенность, яркость} */
    public static final int[][] PRESETS = {
            {20, 88, 100},   // оранжевый
            {0, 85, 100},    // красный
            {330, 70, 100},  // розовый
            {270, 65, 100},  // фиолетовый
            {215, 75, 100},  // синий
            {185, 80, 100},  // бирюзовый
            {135, 70, 90},   // зелёный
            {50, 85, 100},   // жёлтый
            {0, 0, 100}      // белый
    };

    public static int hsb(int h, int s, int b) {
        return Color.HSBtoRGB(h / 360f, s / 100f, b / 100f) | 0xFF000000;
    }

    public static int accent() {
        return hsb(ModuleManager.THEME_H.value, ModuleManager.THEME_S.value, ModuleManager.THEME_B.value);
    }

    public static int sky() {
        return hsb(ModuleManager.SKY_H.value, ModuleManager.SKY_S.value, ModuleManager.SKY_B.value);
    }
}
