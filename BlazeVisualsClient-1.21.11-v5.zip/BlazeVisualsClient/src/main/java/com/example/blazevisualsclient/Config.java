package com.example.blazevisualsclient;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Сохранение включённых модулей и настроек в config/blazevisualsclient.properties */
public class Config {
    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("blazevisualsclient.properties");
    }

    public static void load() {
        Properties p = new Properties();
        try (var in = Files.newInputStream(file());
             var reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
            p.load(reader);
        } catch (IOException e) {
            return; // файла ещё нет — значения по умолчанию
        }
        for (Module m : ModuleManager.ALL) {
            if (m != ModuleManager.ZOOM && !m.alwaysOn) {
                String v = p.getProperty("module." + m.name);
                if (v != null) {
                    m.enabled = Boolean.parseBoolean(v);
                    m.anim = m.enabled ? 1f : 0f;
                }
            }
            for (int i = 0; i < m.settings.size(); i++) {
                Setting s = m.settings.get(i);
                if (s.kind == Setting.Kind.PRESETS) continue;
                String v = p.getProperty("setting." + m.name + "." + i);
                if (v == null) continue;
                try {
                    if (s.kind == Setting.Kind.TOGGLE) s.on = Boolean.parseBoolean(v);
                    else s.value = Math.max(s.min, Math.min(s.max, Integer.parseInt(v.trim())));
                } catch (NumberFormatException ignored) { }
            }
        }
    }

    public static void save() {
        Properties p = new Properties();
        for (Module m : ModuleManager.ALL) {
            p.setProperty("module." + m.name, String.valueOf(m.enabled));
            for (int i = 0; i < m.settings.size(); i++) {
                Setting s = m.settings.get(i);
                if (s.kind == Setting.Kind.PRESETS) continue;
                p.setProperty("setting." + m.name + "." + i,
                        s.kind == Setting.Kind.TOGGLE ? String.valueOf(s.on) : String.valueOf(s.value));
            }
        }
        try (var out = Files.newBufferedWriter(file(), StandardCharsets.UTF_8)) {
            p.store(out, "BlazeVisualsClient");
        } catch (IOException ignored) { }
    }
}
