package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Линия полёта стрел, жемчуга и бросаемых предметов. Рисуется на экране (проекция 3D → 2D). */
public final class Trajectories {
    private Trajectories() {}

    /** {скорость, гравитация} или null, если ничего не прицелено/не зажато. */
    private static double[] spec(Minecraft mc) {
        var p = mc.player;
        ItemStack main = p.getMainHandItem();
        ItemStack off = p.getOffhandItem();

        if (ModuleManager.TR_BOW.on) {
            if (p.isUsingItem()) {
                ItemStack use = p.getUseItem();
                if (use.is(Items.BOW)) {
                    float power = BowItem.getPowerForTime(p.getTicksUsingItem());
                    if (power >= 0.1f) return new double[]{power * 3.0, 0.05};
                }
                if (use.is(Items.TRIDENT) && p.getTicksUsingItem() >= 10) return new double[]{2.5, 0.05};
            }
            if ((main.is(Items.CROSSBOW) && CrossbowItem.isCharged(main))
                    || (off.is(Items.CROSSBOW) && CrossbowItem.isCharged(off))) {
                return new double[]{3.15, 0.05};
            }
        }
        if (ModuleManager.TR_THROW.on) {
            for (ItemStack s : new ItemStack[]{main, off}) {
                if (s.is(Items.ENDER_PEARL) || s.is(Items.SNOWBALL) || s.is(Items.EGG)) {
                    return new double[]{1.5, 0.03};
                }
                if (s.is(Items.EXPERIENCE_BOTTLE)) return new double[]{0.7, 0.07};
                if (s.is(Items.SPLASH_POTION) || s.is(Items.LINGERING_POTION)) return new double[]{0.5, 0.05};
            }
        }
        return null;
    }

    public static void render(GuiGraphics g, Minecraft mc, float partial) {
        if (!ModuleManager.TRAJECTORIES.enabled || mc.player == null || mc.level == null) return;
        double[] spec = spec(mc);
        if (spec == null) return;

        Vec3 pos = mc.player.getEyePosition(partial).subtract(0.0, 0.1, 0.0);
        Vec3 vel = mc.player.getViewVector(partial).scale(spec[0]);

        List<Vec3> pts = new ArrayList<>();
        Vec3 landing = null;
        for (int i = 0; i < 160; i++) {
            Vec3 next = pos.add(vel);
            var res = mc.level.clip(new ClipContext(pos, next,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
            if (res.getType() != HitResult.Type.MISS) {
                landing = res.getLocation();
                pts.add(landing);
                break;
            }
            pts.add(next);
            pos = next;
            vel = vel.scale(0.99).subtract(0.0, spec[1], 0.0);
            if (pos.y < -128.0) break;
        }

        Projection pr = new Projection(mc, partial);
        int col = HudRenderer.color(0f);
        int n = pts.size();
        for (int i = 0; i < n; i++) {
            double[] s = pr.project(pts.get(i));
            if (s == null) continue;
            int alpha = 255 - (int) (150.0 * i / Math.max(1, n));
            int c = (alpha << 24) | (col & 0x00FFFFFF);
            int x = (int) s[0], y = (int) s[1];
            g.fill(x - 1, y - 1, x + 1, y + 1, c);
        }

        if (landing != null && ModuleManager.TR_MARK.on) {
            double[] s = pr.project(landing);
            if (s != null) {
                int x = (int) s[0], y = (int) s[1];
                int red = 0xFFFF5555;
                g.fill(x - 4, y - 1, x + 5, y + 1, red);
                g.fill(x - 1, y - 4, x + 1, y + 5, red);
            }
        }
    }
}
