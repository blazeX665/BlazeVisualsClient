package com.example.blazevisualsclient.mixin;

import com.example.blazevisualsclient.ModuleManager;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.ItemEntityRenderer;
import net.minecraft.client.renderer.entity.state.ItemEntityRenderState;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntityRenderer.class)
public class ItemEntityRendererMixin {
    /** Item Physics: предмет лежит плашмя, без вращения и покачивания. */
    @Inject(method = "submit", at = @At("HEAD"), cancellable = true)
    private static void blaze$itemPhysics(@Coerce Object stateObj, PoseStack poseStack,
                                          SubmitNodeCollector collector, @Coerce Object camera,
                                          CallbackInfo ci) {
        if (!ModuleManager.ITEM_PHYSICS.enabled) return;
        if (!(stateObj instanceof ItemEntityRenderState state)) return;
        if (state.item.isEmpty()) return;

        AABB bb = state.item.getModelBoundingBox();
        double lift = -bb.minZ + ModuleManager.IP_HOVER.value * 0.005;

        poseStack.pushPose();
        poseStack.translate(0.0, lift, 0.0);
        poseStack.mulPose(Axis.YP.rotation(state.bobOffset));      // у каждого предмета свой поворот
        poseStack.mulPose(Axis.XP.rotationDegrees(-90.0f));         // кладём плашмя
        ItemEntityRenderer.submitMultipleFromCount(poseStack, collector, state.lightCoords, state,
                RandomSource.create(state.seed));
        poseStack.popPose();
        ci.cancel();
    }
}
