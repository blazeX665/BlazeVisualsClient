package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.server.level.ParticleStatus;

/** Оптимизация FPS: меняет настройки игры и возвращает их при выключении. */
public class Optimizer {
    private static boolean active = false;

    private static int oRender, oSim, oFps, oBlend;
    private static double oEntity;
    private static boolean oShadows, oVsync;
    private static ParticleStatus oParticles;

    private static boolean low = false;
    private static int sample = 0;
    private static int lowTicks = 0;

    /** true, пока оптимизация включена и должен быть убран туман. */
    public static boolean fogActive() {
        return active && ModuleManager.OPT_FOG.on;
    }

    public static void tick(Minecraft mc) {
        Options o = mc.options;
        boolean enabled = ModuleManager.OPTIMIZATION.enabled;
        boolean auto = ModuleManager.OPT_AUTO.on;

        if (!enabled || !auto) {
            low = false;
            sample = 0;
            lowTicks = 0;
        } else {
            if (low) lowTicks++;
            if (++sample >= 20) {               // проверяем FPS раз в секунду
                sample = 0;
                int fps = mc.getFps();
                int thr = ModuleManager.OPT_FPS_MIN.value;
                if (!low && fps < thr) {
                    low = true;
                    lowTicks = 0;
                } else if (low && lowTicks > 600 && fps > thr + 15) {   // держим не меньше 30 с
                    low = false;
                }
            }
        }

        boolean on = enabled && (!auto || low);
        if (on && !active) {
            save(o);
            active = true;
        }
        if (on) {
            apply(o);
        } else if (active) {
            restore(o);
            active = false;
        }
    }

    public static void shutdown(Minecraft mc) {
        if (active) {
            restore(mc.options);
            active = false;
        }
    }

    private static void save(Options o) {
        oRender = o.renderDistance().get();
        oSim = o.simulationDistance().get();
        oFps = o.framerateLimit().get();
        oBlend = o.biomeBlendRadius().get();
        oEntity = o.entityDistanceScaling().get();
        oShadows = o.entityShadows().get();
        oVsync = o.enableVsync().get();
        oParticles = o.particles().get();
    }

    private static void apply(Options o) {
        if (ModuleManager.OPT_AUTO.on) {
            o.renderDistance().set(oRender);
            o.simulationDistance().set(oSim);
        } else {
            o.renderDistance().set(ModuleManager.OPT_RENDER.value);
            o.simulationDistance().set(ModuleManager.OPT_SIM.value);
        }
        o.entityDistanceScaling().set(ModuleManager.OPT_ENTITY.value / 100.0);

        if (ModuleManager.OPT_EFFECTS.on) {
            o.particles().set(ParticleStatus.MINIMAL);
            o.entityShadows().set(false);
            o.biomeBlendRadius().set(0);
        } else {
            o.particles().set(oParticles);
            o.entityShadows().set(oShadows);
            o.biomeBlendRadius().set(oBlend);
        }

        if (ModuleManager.OPT_UNLOCK.on) {
            o.enableVsync().set(false);
            o.framerateLimit().set(260); // 260 = без лимита
        } else {
            o.enableVsync().set(oVsync);
            o.framerateLimit().set(oFps);
        }
    }

    private static void restore(Options o) {
        o.renderDistance().set(oRender);
        o.simulationDistance().set(oSim);
        o.entityDistanceScaling().set(oEntity);
        o.particles().set(oParticles);
        o.entityShadows().set(oShadows);
        o.biomeBlendRadius().set(oBlend);
        o.enableVsync().set(oVsync);
        o.framerateLimit().set(oFps);
    }
}
