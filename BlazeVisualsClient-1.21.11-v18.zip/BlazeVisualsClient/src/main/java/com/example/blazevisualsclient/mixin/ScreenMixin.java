package com.example.blazevisualsclient.mixin;

import com.example.blazevisualsclient.MenuBackground;
import com.example.blazevisualsclient.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public class ScreenMixin {
    /** Свой фон на всех экранах вне мира: серверы, миры, настройки и т.д. (кроме классического меню). */
    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
    private void blaze$menuBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (!ModuleManager.CUSTOM_MENU.enabled) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) return;
        Object self = this;
        if (self instanceof TitleScreen) return;
        var window = mc.getWindow();
        MenuBackground.render(g, window.getGuiScaledWidth(), window.getGuiScaledHeight());
        ci.cancel();
    }
}
