package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;

import java.util.List;

public class ModuleManager {
    // --- цвет темы (HUD и меню) ---
    public static final Setting THEME_H = Setting.slider("Оттенок", 20, 0, 360, "°");
    public static final Setting THEME_S = Setting.slider("Насыщенность", 88, 0, 100, "%");
    public static final Setting THEME_B = Setting.slider("Яркость", 100, 30, 100, "%");

    // --- небо ---
    public static final Setting SKY_H = Setting.slider("Оттенок", 275, 0, 360, "°");
    public static final Setting SKY_S = Setting.slider("Насыщенность", 55, 0, 100, "%");
    public static final Setting SKY_B = Setting.slider("Яркость", 65, 0, 100, "%");

    // --- No Render ---
    public static final Setting NR_FIRE  = Setting.toggle("Огонь на экране", true);
    public static final Setting NR_WATER = Setting.toggle("Вода на экране", true);
    public static final Setting NR_WALL  = Setting.toggle("Блок в лице", true);
    public static final Setting NR_FOG   = Setting.toggle("Туман (вода/лава/снег)", true);

    // --- Block Overlay ---
    public static final Setting BO_H     = Setting.slider("Оттенок", 20, 0, 360, "°");
    public static final Setting BO_S     = Setting.slider("Насыщенность", 88, 0, 100, "%");
    public static final Setting BO_B     = Setting.slider("Яркость", 100, 30, 100, "%");
    public static final Setting BO_ALPHA = Setting.slider("Прозрачность", 100, 10, 100, "%");
    public static final Setting BO_WIDTH = Setting.slider("Толщина", 3, 1, 8, "");

    // --- Item Physics ---
    public static final Setting IP_HOVER = Setting.slider("Высота над землёй", 2, 0, 20, "");

    // --- Swing Animation ---
    public static final Setting SW_SPEED = Setting.slider("Скорость", 100, 40, 250, "%");
    public static final Setting SW_STYLE = Setting.choice("Стиль удара", 0,
            "Обычный", "Плавный", "Разгон", "Резкий", "Колющий", "Рубящий", "Мах");
    public static final Setting SW_MINE  = Setting.choice("Стиль ломания", 0,
            "Обычный", "Плавный", "Разгон", "Резкий", "Колющий", "Рубящий", "Мах");
    public static final Setting SW_POWER = Setting.slider("Сила эффекта", 100, 50, 200, "%");
    public static final Setting SW_EAT   = Setting.choice("Еда и питьё", 0, "Обычная", "Без подъёма");

    // --- View Model ---

    // --- View Model: отдельно правая и левая рука ---
    public static final Setting VMR_X     = Setting.slider("Правая X", 0, -100, 100, "");
    public static final Setting VMR_Y     = Setting.slider("Правая Y", 0, -100, 100, "");
    public static final Setting VMR_Z     = Setting.slider("Правая Z", 0, -100, 100, "");
    public static final Setting VMR_SCALE = Setting.slider("Правая размер", 100, 30, 200, "%");
    public static final Setting VMR_RX    = Setting.slider("Правая вращ. X", 0, -180, 180, "°");
    public static final Setting VMR_RY    = Setting.slider("Правая вращ. Y", 0, -180, 180, "°");
    public static final Setting VMR_RZ    = Setting.slider("Правая вращ. Z", 0, -180, 180, "°");
    public static final Setting VML_X     = Setting.slider("Левая X", 0, -100, 100, "");
    public static final Setting VML_Y     = Setting.slider("Левая Y", 0, -100, 100, "");
    public static final Setting VML_Z     = Setting.slider("Левая Z", 0, -100, 100, "");
    public static final Setting VML_SCALE = Setting.slider("Левая размер", 100, 30, 200, "%");
    public static final Setting VML_RX    = Setting.slider("Левая вращ. X", 0, -180, 180, "°");
    public static final Setting VML_RY    = Setting.slider("Левая вращ. Y", 0, -180, 180, "°");
    public static final Setting VML_RZ    = Setting.slider("Левая вращ. Z", 0, -180, 180, "°");

    // --- Zoom / Optimization ---
    public static final Setting ZOOM_FOV    = Setting.step("Zoom FOV", 30, 30, 60, 5, "");
    public static final Setting OPT_EFFECTS = Setting.toggle("Меньше эффектов", true);
    public static final Setting OPT_UNLOCK  = Setting.toggle("Разблокировать FPS", true);
    public static final Setting OPT_RENDER  = Setting.step("Прорисовка (чанки)", 8, 2, 32, 2, "");
    public static final Setting OPT_SIM     = Setting.step("Симуляция (чанки)", 5, 5, 16, 1, "");
    public static final Setting OPT_ENTITY  = Setting.step("Сущности (%)", 50, 50, 150, 25, "%");
    public static final Setting OPT_AUTO    = Setting.toggle("Авто при низком FPS", true);
    public static final Setting OPT_FPS_MIN = Setting.slider("Порог FPS", 45, 20, 120, "");
    public static final Setting OPT_FOG     = Setting.toggle("Без тумана", true);

    // --- Better Near / Waypoints ---
    public static final Setting WP_DIST  = Setting.toggle("Показывать дистанцию", true);

    // --- Scanner / Pinger / ESP / Chat Tools ---
    public static final Setting SC_RADIUS   = Setting.slider("Радиус", 150, 10, 150, "м");
    public static final Setting SC_MAX      = Setting.step("Макс. игроков", 6, 3, 12, 1, "");
    public static final Setting SC_INTERVAL = Setting.slider("Интервал", 2, 1, 30, "с");
    public static final Setting SC_CHAT     = Setting.toggle("Сообщение в чат", true);
    public static final Setting SC_SOUND    = Setting.toggle("Звук", true);
    public static final Setting PG_THRESH   = Setting.slider("Порог износа", 15, 5, 50, "%");
    public static final Setting PG_SOUND    = Setting.toggle("Звук", true);
    public static final Setting PG_CHAT     = Setting.toggle("Сообщение в чат", false);
    public static final Setting ESP_NEAREST = Setting.toggle("Ближайшая цель", true);
    public static final Setting ESP_ARMOR   = Setting.toggle("Броня цели", true);
    public static final Setting ESP_HOLD    = Setting.slider("Держать цель", 3, 0, 10, "с");
    public static final Setting ESP_MOBS    = Setting.toggle("Показывать мобов", true);
    public static final Setting CT_FILTER   = Setting.toggle("Фильтр слов", true);
    public static final Setting CT_MENTION  = Setting.toggle("Звук на ник", true);

    // ================= Visuals =================
    public static final Module COLOR = new Module("Color", "Цвет HUD и меню", "Visuals", true)
            .alwaysOn()
            .add(Setting.presets("Пресеты", THEME_H, THEME_S, THEME_B))
            .add(THEME_H).add(THEME_S).add(THEME_B);
    public static final Module RAINBOW    = new Module("Rainbow", "Радужный HUD", "Visuals", false);
    public static final Module FULLBRIGHT = new Module("Fullbright", "Яркость на максимум (B)", "Visuals", false);
    public static final Module SKY = new Module("Custom Sky", "Своё небо любого цвета", "Visuals", false)
            .add(Setting.presets("Пресеты", SKY_H, SKY_S, SKY_B))
            .add(SKY_H).add(SKY_S).add(SKY_B);
    public static final Module NO_RENDER = new Module("No Render", "Без огня, тумана, оверлеев", "Visuals", false)
            .add(NR_FIRE).add(NR_WATER).add(NR_WALL).add(NR_FOG);
    public static final Module ESP = new Module("ESP", "Здоровье и броня цели", "Visuals", false)
            .add(ESP_ARMOR).add(ESP_MOBS).add(ESP_HOLD);
    public static final Module BLOCK_OVERLAY = new Module("Block Overlay", "Цвет и толщина рамки блока", "Visuals", false)
            .add(Setting.presets("Пресеты", BO_H, BO_S, BO_B))
            .add(BO_H).add(BO_S).add(BO_B).add(BO_ALPHA).add(BO_WIDTH);
    public static final Module ITEM_PHYSICS = new Module("Item Physics", "Предметы лежат на земле", "Visuals", false)
            .add(IP_HOVER);
    public static final Module SWING = new Module("Swing Animation", "Удары, ломание блоков, еда", "Visuals", false)
            .add(SW_SPEED).add(SW_STYLE).add(SW_MINE).add(SW_POWER).add(SW_EAT);
    public static final Module VIEW_MODEL = new Module("View Model", "Положение рук и предметов", "Visuals", false)
            .add(Setting.button("Двигать руки мышью", () -> Minecraft.getInstance().setScreen(new ViewModelEditorScreen())))
            .add(VMR_X).add(VMR_Y).add(VMR_Z).add(VMR_SCALE).add(VMR_RX).add(VMR_RY).add(VMR_RZ)
            .add(VML_X).add(VML_Y).add(VML_Z).add(VML_SCALE).add(VML_RX).add(VML_RY).add(VML_RZ);

    // ================= Utilities =================
    public static final Module SHIFT_DRAG = new Module("Shift Drag", "Shift + мышь: быстрый сбор предметов", "Utilities", false);
    public static final Module AUTO_SPRINT = new Module("Auto Sprint", "Бег без зажатия клавиши", "Utilities", false);
    public static final Module ZOOM = new Module("Zoom", "Приближение (C)", "Utilities", false)
            .add(ZOOM_FOV);
    public static final Module OPTIMIZATION = new Module("Optimization", "Повышение FPS", "Utilities", false)
            .add(OPT_AUTO).add(OPT_FPS_MIN).add(OPT_EFFECTS).add(OPT_FOG).add(OPT_UNLOCK)
            .add(OPT_RENDER).add(OPT_SIM).add(OPT_ENTITY);
    public static final Module KEY_COMMAND = new Module("KeyCommand", "Команды на клавиши", "Utilities", true)
            .add(Setting.button("Настроить команды", () -> Minecraft.getInstance().setScreen(new KeyCommandScreen())));

    public static final Module AUTO_COMMAND = new Module("Auto Command", "Команды по таймеру", "Utilities", false)
            .add(Setting.button("Настроить команды", () -> Minecraft.getInstance().setScreen(new AutoCommandScreen())));
    public static final Module CHAT_TOOLS = new Module("Chat Tools", "Фильтр слов и звук на ник", "Utilities", false)
            .add(CT_FILTER).add(CT_MENTION)
            .add(Setting.button("Слова и ники", () -> Minecraft.getInstance().setScreen(new ChatToolsScreen())));

    // ================= Client (HUD) =================
    public static final Module WATERMARK  = new Module("Watermark", "Название сверху слева", "Client", true);
    public static final Module FPS        = new Module("FPS", "Счётчик кадров", "Client", true);
    public static final Module COORDS     = new Module("Coordinates", "Координаты и сторона света", "Client", true);
    public static final Module KEYSTROKES = new Module("Keystrokes", "WASD на экране", "Client", true);
    public static final Module ARRAYLIST  = new Module("ArrayList", "Список включённых модулей", "Client", true);
    public static final Module CUSTOM_MENU = new Module("Custom Menu", "Своё главное меню", "Client", true);
    public static final Module WAYPOINTS = new Module("Waypoints", "Метки по координатам", "Client", true)
            .add(Setting.button("Управление метками", () -> Minecraft.getInstance().setScreen(new WaypointScreen())))
            .add(WP_DIST);

    public static final Module SCANNER = new Module("Scanner", "Стрелки к игрокам до 150 м", "Client", false)
            .add(SC_RADIUS).add(SC_MAX).add(SC_INTERVAL).add(SC_CHAT).add(SC_SOUND);
    public static final Module PINGER = new Module("Pinger", "Предупреждение об износе брони", "Client", false)
            .add(PG_THRESH).add(PG_SOUND).add(PG_CHAT);
    public static final Module HUD_EDITOR = new Module("HUD Editor", "Перетаскивание элементов", "Client", true)
            .alwaysOn()
            .add(Setting.button("Открыть редактор HUD", () -> Minecraft.getInstance().setScreen(new HudEditorScreen())));
    public static final Module CONFIGS = new Module("Configs", "Наборы настроек", "Client", true)
            .alwaysOn()
            .add(Setting.button("Сохранить / загрузить", () -> Minecraft.getInstance().setScreen(new ConfigScreen())));

    public static final List<Module> ALL = List.of(
            COLOR, RAINBOW, FULLBRIGHT, ESP, SKY, NO_RENDER, BLOCK_OVERLAY, ITEM_PHYSICS, SWING, VIEW_MODEL,
            AUTO_SPRINT, SHIFT_DRAG, ZOOM, OPTIMIZATION, KEY_COMMAND, AUTO_COMMAND, CHAT_TOOLS,
            WATERMARK, FPS, COORDS, KEYSTROKES, ARRAYLIST, SCANNER, PINGER, WAYPOINTS, CUSTOM_MENU, HUD_EDITOR, CONFIGS
    );

    public static List<Module> inCategory(String category) {
        return ALL.stream().filter(m -> m.category.equals(category)).toList();
    }
}
