package com.example.blazevisualsclient;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Именованные наборы настроек (config/blazevisualsclient/<имя>.properties). */
public final class Configs {
    private Configs() {}

    private static Path file(String name) { return Config.dir().resolve(name + ".properties"); }

    public static String clean(String name) {
        String n = name == null ? "" : name.trim().replaceAll("[^\\p{L}\\p{N}_ -]", "_");
        if (n.isEmpty()) n = "config";
        return n.length() > 24 ? n.substring(0, 24) : n;
    }

    public static List<String> list() {
        try (var s = Files.list(Config.dir())) {
            return s.map(p -> p.getFileName().toString())
                    .filter(n -> n.endsWith(".properties"))
                    .map(n -> n.substring(0, n.length() - ".properties".length()))
                    .sorted()
                    .toList();
        } catch (IOException e) {
            return List.of();
        }
    }

    public static void save(String name) { Config.save(file(clean(name))); }

    public static void load(String name) {
        Config.load(file(name));
        Config.save();
    }

    public static void delete(String name) {
        try { Files.deleteIfExists(file(name)); } catch (IOException ignored) { }
    }
}
