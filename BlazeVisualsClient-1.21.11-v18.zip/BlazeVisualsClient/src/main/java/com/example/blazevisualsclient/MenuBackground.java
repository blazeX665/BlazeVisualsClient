package com.example.blazevisualsclient;

import net.minecraft.client.gui.GuiGraphics;

/** Общий фирменный фон меню: тёмный градиент + светящиеся пятна цвета темы. */
public final class MenuBackground {
    private MenuBackground() {}

    private static final long START = System.currentTimeMillis();

    public static void render(GuiGraphics g, int width, int height) {
        double t = (System.currentTimeMillis() - START) / 1000.0;
        int rgb = HudRenderer.color(0f) & 0x00FFFFFF;

        // тёмный вертикальный градиент полосами
        int bands = Math.max(1, height / 3);
        for (int i = 0; i < bands; i++) {
            float f = i / (float) bands;
            g.fill(0, i * 3, width, i * 3 + 3, Gfx.lerp(0xFF0B0B10, 0xFF15101A, f));
        }

        // мягкие светящиеся пятна
        for (int k = 0; k < 3; k++) {
            double ax = 0.5 + 0.38 * Math.sin(t * 0.25 + k * 2.1);
            double ay = 0.5 + 0.35 * Math.cos(t * 0.21 + k * 1.7);
            int cx = (int) (width * ax), cy = (int) (height * ay);
            for (int j = 0; j < 4; j++) {
                int r = 56 - j * 12;
                Gfx.rr(g, cx - r, cy - r, r * 2, r * 2, r, rgb | 0x0B000000);
            }
        }
    }
}
