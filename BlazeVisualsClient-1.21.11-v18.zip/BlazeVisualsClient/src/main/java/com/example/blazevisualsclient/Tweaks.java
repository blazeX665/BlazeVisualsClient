package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;

/** Auto Sprint и скорость взмаха (Swing Animation). */
public final class Tweaks {
    private Tweaks() {}

    private static boolean forcedSprint = false;
    private static float swingAcc = 0f;

    public static void tick(Minecraft mc) {
        var p = mc.player;
        if (p == null) {
            forcedSprint = false;
            swingAcc = 0f;
            return;
        }

        // --- Auto Sprint ---
        if (ModuleManager.AUTO_SPRINT.enabled && mc.screen == null) {
            if (mc.options.keyUp.isDown() && !p.isShiftKeyDown()) {
                mc.options.keySprint.setDown(true);
                forcedSprint = true;
            } else if (forcedSprint) {
                mc.options.keySprint.setDown(false);
                forcedSprint = false;
            }
        } else if (forcedSprint) {
            mc.options.keySprint.setDown(false);
            forcedSprint = false;
        }

        // --- Скорость взмаха (удары и ломание блоков) ---
        if (ModuleManager.SWING.enabled && p.swinging) {
            swingAcc += ModuleManager.SW_SPEED.value / 100f - 1f;
            if (swingAcc <= -1f) {
                if (p.swingTime > 0) p.swingTime--;
                swingAcc += 1f;
            } else if (swingAcc >= 1f) {
                p.swingTime++;
                swingAcc -= 1f;
            }
        } else {
            swingAcc = 0f;
        }
    }
}
