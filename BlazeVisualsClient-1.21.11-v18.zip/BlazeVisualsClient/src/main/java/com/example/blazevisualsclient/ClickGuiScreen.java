package com.example.blazevisualsclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;

public class ClickGuiScreen extends Screen {
    private static final int BG = 0xF2121216, EDGE = 0xFF2A2A32, TAB_BG = 0xFF18181D, TAB_EDGE = 0xFF34343C;
    private static final int CARD = 0xFF1F1F25, CARD_HOVER = 0xFF292931, SUB = 0xFF17171C;
    private static final int OFF = 0xFF3A3A44, BTN = 0xFF2C2C34;
    private static final int GREY = 0xFF9A9AA3, DIM = 0xFF6C6C75, WHITE = 0xFFF2F2F5, DARK = 0xFF101014;

    private static final int R = 6;
    private static final int PAD = 10, HEAD = 28, SIDE_W = 78, SIDE_GAP = 10, SIDE_H = 24;
    private static final int CARD_H = 26, GAP = 3, SET_H = 15, PRESET_H = 17, FOOT = 15;
    private static final String VERSION = "v1.4 · RSHIFT";
    private static final String[] TABS = {"Visuals", "Utilities", "Client"};

    private static int tab = 0;
    private static Module open = null;   // раскрытый модуль (только один)
    private static float scroll = 0f;
    private static int lastContentH = 0;

    private record Hit(int x, int y, int w, int h, boolean content, Runnable action, DoubleConsumer drag) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final List<Hit> hits = new ArrayList<>();
    private Hit pressed = null, activeDrag = null;
    private double pressY;
    private boolean scrolling = false, pressInView = false;
    private float openAnim = 0f;
    private int vx, vy, vw, vh;

    public ClickGuiScreen() { super(Component.literal("BlazeVisualsClient")); }

    private boolean visible(int y, int h) { return y + h > vy && y < vy + vh; }

    private void toggleOpen(Module m) { open = (open == m) ? null : m; }

    private static int rowH(Setting s) { return s.kind == Setting.Kind.PRESETS ? PRESET_H : SET_H; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        hits.clear();

        openAnim += (1f - openAnim) * 0.25f;
        int yOff = (int) ((1f - openAnim) * 14);
        int accent = HudRenderer.color(0f);

        int w = Math.min(width - 12, 400);
        int h = Math.min(height - 8, 262);
        int x = (width - w) / 2;
        int y = Math.max(4, (height - h) / 2) + yOff;

        for (Module m : ModuleManager.ALL) {
            m.anim += ((m.enabled ? 1f : 0f) - m.anim) * 0.3f;
        }

        // тень + свечение + фон
        for (int i = 4; i >= 1; i--) {
            Gfx.rr(g, x - i, y - i, w + 2 * i, h + 2 * i, R + i, 0x12000000);
        }
        Gfx.rr(g, x - 1, y - 1, w + 2, h + 2, R + 1, (accent & 0x00FFFFFF) | 0x70000000);
        Gfx.rr(g, x, y, w, h, R, BG);

        // заголовок
        Gfx.rr(g, x + PAD, y + 7, 14, 14, 4, accent);
        g.drawString(font, "B", x + PAD + 4, y + 10, DARK);
        int tx = x + PAD + 20;
        g.drawString(font, "Blaze", tx, y + 10, accent);
        g.drawString(font, "VisualsClient", tx + font.width("Blaze"), y + 10, WHITE);
        g.drawString(font, VERSION, x + w - PAD - font.width(VERSION), y + 10, GREY);
        g.fill(x + PAD, y + HEAD - 2, x + w - PAD, y + HEAD - 1, EDGE);

        // ---------- боковая панель слева ----------
        int sideX = x + PAD;
        int sideY = y + HEAD + 4;
        for (int i = 0; i < TABS.length; i++) {
            int ty = sideY + i * (SIDE_H + 4);
            boolean sel = i == tab;
            boolean hov = mx >= sideX && mx < sideX + SIDE_W && my >= ty && my < ty + SIDE_H;
            if (sel) {
                Gfx.rr(g, sideX, ty, SIDE_W, SIDE_H, 7, accent);
            } else {
                Gfx.rr(g, sideX, ty, SIDE_W, SIDE_H, 7, TAB_EDGE);
                Gfx.rr(g, sideX + 1, ty + 1, SIDE_W - 2, SIDE_H - 2, 6, hov ? CARD_HOVER : TAB_BG);
            }
            g.drawString(font, TABS[i], sideX + 8, ty + 8, sel ? DARK : WHITE);

            // счётчик включённых модулей
            int on = 0;
            for (Module m : ModuleManager.inCategory(TABS[i])) if (m.enabled && !m.alwaysOn) on++;
            if (on > 0) {
                String badge = String.valueOf(on);
                int bw = font.width(badge) + 6;
                Gfx.rr(g, sideX + SIDE_W - bw - 5, ty + 6, bw, 12, 6, sel ? DARK : accent);
                g.drawString(font, badge, sideX + SIDE_W - bw - 2, ty + 8, sel ? accent : DARK);
            }
            final int idx = i;
            hits.add(new Hit(sideX, ty, SIDE_W, SIDE_H, false, () -> { tab = idx; scroll = 0f; open = null; }, null));
        }
        // разделитель
        g.fill(sideX + SIDE_W + 4, sideY, sideX + SIDE_W + 5, y + h - FOOT - 4, EDGE);

        // ---------- область модулей ----------
        vx = sideX + SIDE_W + SIDE_GAP;
        vw = (x + w - PAD) - vx;
        vy = sideY;
        vh = (y + h) - vy - FOOT - 4;
        float maxScroll = Math.max(0, lastContentH - vh);
        scroll = Math.max(0f, Math.min(scroll, maxScroll));

        List<Module> list = ModuleManager.inCategory(TABS[tab]);
        int cx = vx, cw = vw - 6;
        int startY = vy - (int) scroll;
        int cy = startY;

        g.enableScissor(vx, vy, vx + vw, vy + vh);
        for (Module m : list) {
            boolean hasSet = !m.settings.isEmpty();
            boolean expanded = hasSet && open == m;
            boolean hover = mx >= cx && mx < cx + cw
                    && my >= Math.max(cy, vy) && my < Math.min(cy + CARD_H, vy + vh);
            m.hover += ((hover ? 1f : 0f) - m.hover) * 0.3f;

            if (visible(cy, CARD_H)) {
                boolean lit = m.enabled && !m.alwaysOn;
                Gfx.rr(g, cx, cy, cw, CARD_H, R - 1, Gfx.lerp(CARD, CARD_HOVER, m.hover));
                if (lit) Gfx.rr(g, cx, cy + 6, 2, CARD_H - 12, 1, accent);
                g.drawString(font, m.name, cx + 8, cy + 5, lit ? accent : WHITE);
                g.drawString(font, m.description, cx + 8, cy + 15, GREY);

                int rightEdge = cx + cw - 8 - (hasSet ? 18 : 0);
                int sx = rightEdge - 28, sy = cy + (CARD_H - 14) / 2;
                if (m.alwaysOn) {
                    Gfx.rr(g, sx, sy, 28, 14, 7, OFF);
                    Gfx.rr(g, sx + 1, sy + 1, 26, 12, 6, Theme.accent());
                } else {
                    Gfx.rr(g, sx, sy, 28, 14, 7, Gfx.lerp(OFF, accent, m.anim));
                    Gfx.rr(g, sx + 2 + (int) (m.anim * 14), sy + 2, 10, 10, 5, WHITE);
                }
                if (hasSet) Gfx.chevron(g, cx + cw - 13, cy + CARD_H / 2 - 2, expanded, GREY);

                final Module mod = m;
                hits.add(new Hit(cx, cy, cw, CARD_H, true,
                        m.alwaysOn ? () -> toggleOpen(mod) : mod::toggle, null));
                if (hasSet) {
                    hits.add(new Hit(cx + cw - 26, cy, 26, CARD_H, true, () -> toggleOpen(mod), null));
                }
            }
            cy += CARD_H + GAP;

            if (expanded) {
                int bh = 6;
                for (Setting s : m.settings) bh += rowH(s);
                if (visible(cy - 1, bh)) Gfx.rr(g, cx + 4, cy - 1, cw - 8, bh, R - 2, SUB);
                int ry = cy + 2;
                for (Setting s : m.settings) {
                    if (visible(ry, rowH(s))) drawSetting(g, s, cx + 4, ry, cw - 8, accent);
                    ry += rowH(s);
                }
                cy += bh + GAP;
            }
        }
        g.disableScissor();
        lastContentH = Math.max(0, cy - startY - GAP);

        // полоса прокрутки
        if (lastContentH > vh) {
            int thumb = Math.max(14, vh * vh / lastContentH);
            int ty = vy + (int) ((vh - thumb) * (scroll / Math.max(1f, maxScroll)));
            Gfx.rr(g, x + w - 6, vy, 3, vh, 1, 0xFF22222A);
            Gfx.rr(g, x + w - 6, ty, 3, thumb, 1, accent);
        }

        // подвал
        int total = 0;
        for (Module m : ModuleManager.ALL) if (m.enabled && !m.alwaysOn) total++;
        g.drawString(font, "Включено: " + total, x + PAD, y + h - FOOT + 2, DIM);
        String hint = "тяни для прокрутки";
        g.drawString(font, hint, x + w - PAD - font.width(hint), y + h - FOOT + 2, DIM);
    }

    private void drawSetting(GuiGraphics g, Setting s, int x, int y, int w, int accent) {
        switch (s.kind) {
            case TOGGLE -> {
                g.drawString(font, s.name, x + 8, y + 4, WHITE);
                int sx = x + w - 8 - 22, sy = y + 2;
                Gfx.rr(g, sx, sy, 22, 11, 5, s.on ? accent : OFF);
                Gfx.rr(g, sx + (s.on ? 12 : 2), sy + 2, 8, 7, 3, WHITE);
                hits.add(new Hit(x, y, w, SET_H, true, () -> s.on = !s.on, null));
            }
            case STEP, CHOICE -> {
                g.drawString(font, s.name, x + 8, y + 4, WHITE);
                String val = s.kind == Setting.Kind.CHOICE ? s.options[s.value] : s.value + s.suffix;
                int plusX = x + w - 8 - 13;
                int valW = 48;
                int valX = plusX - 3 - valW;
                int minusX = valX - 3 - 13;
                Gfx.rr(g, minusX, y + 1, 13, 13, 4, BTN);
                g.drawString(font, "-", minusX + 4, y + 3, WHITE);
                Gfx.rr(g, plusX, y + 1, 13, 13, 4, BTN);
                g.drawString(font, "+", plusX + 4, y + 3, WHITE);
                g.drawString(font, val, valX + valW / 2 - font.width(val) / 2, y + 3, accent);
                hits.add(new Hit(minusX - 2, y, 17, SET_H, true, s::dec, null));
                hits.add(new Hit(plusX - 2, y, 17, SET_H, true, s::inc, null));
            }
            case SLIDER -> {
                g.drawString(font, s.name, x + 8, y + 4, WHITE);
                String val = s.value + s.suffix;
                int bx = x + 8 + 92;
                int bw = w - 8 - 92 - 8 - 40;
                int by = y + SET_H / 2 - 2;
                float f = (s.value - s.min) / (float) Math.max(1, s.max - s.min);
                int fw = (int) (bw * f);
                Gfx.rr(g, bx, by, bw, 4, 2, BTN);
                if (fw > 0) Gfx.rr(g, bx, by, Math.max(4, fw), 4, 2, accent);
                Gfx.rr(g, bx + fw - 3, by - 2, 7, 8, 3, WHITE);
                g.drawString(font, val, x + w - 8 - font.width(val), y + 4, GREY);
                hits.add(new Hit(bx - 4, y, bw + 8, SET_H, true, null, mxv -> {
                    double t = Math.max(0.0, Math.min(1.0, (mxv - bx) / (double) bw));
                    s.value = s.min + (int) Math.round(t * (s.max - s.min));
                }));
            }
            case PRESETS -> {
                g.drawString(font, s.name, x + 8, y + 5, WHITE);
                int n = Theme.PRESETS.length, sw = 12, gap = 3;
                int total = n * sw + (n - 1) * gap;
                int sx0 = x + w - 8 - total;
                for (int i = 0; i < n; i++) {
                    final int[] p = Theme.PRESETS[i];
                    int px = sx0 + i * (sw + gap), py = y + 2;
                    boolean sel = s.linkH.value == p[0] && s.linkS.value == p[1] && s.linkB.value == p[2];
                    if (sel) Gfx.rr(g, px - 1, py - 1, sw + 2, sw + 2, 4, WHITE);
                    Gfx.rr(g, px, py, sw, sw, 3, Theme.hsb(p[0], p[1], p[2]));
                    hits.add(new Hit(px - 1, py - 1, sw + 2, sw + 2, true, () -> {
                        s.linkH.value = p[0];
                        s.linkS.value = p[1];
                        s.linkB.value = p[2];
                    }, null));
                }
            }
            case BUTTON -> {
                Gfx.rr(g, x + 8, y + 1, w - 16, SET_H - 2, 5, Gfx.lerp(BTN, accent, 0.45f));
                g.drawString(font, s.name, x + w / 2 - font.width(s.name) / 2, y + 4, WHITE);
                hits.add(new Hit(x + 8, y, w - 16, SET_H, true, s.action, null));
            }
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        double mx = event.x(), my = event.y();
        pressed = null;
        activeDrag = null;
        scrolling = false;
        pressY = my;
        pressInView = mx >= vx && mx < vx + vw && my >= vy && my < vy + vh;

        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit hit = hits.get(i);
            if (hit.contains(mx, my) && (!hit.content() || pressInView)) {
                if (hit.drag() != null) {
                    activeDrag = hit;
                    hit.drag().accept(mx);
                } else {
                    pressed = hit;
                }
                return true;
            }
        }
        return pressInView || super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (activeDrag != null) {
            activeDrag.drag().accept(event.x());
            return true;
        }
        if (pressInView) {
            if (Math.abs(event.y() - pressY) > 4) scrolling = true;
            if (scrolling) {
                scroll -= (float) dragY;
                return true;
            }
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (event.button() == 0) {
            boolean handled = pressed != null || activeDrag != null || scrolling;
            if (pressed != null && !scrolling && pressed.contains(event.x(), event.y())
                    && pressed.action() != null) {
                pressed.action().run();
            }
            pressed = null;
            activeDrag = null;
            scrolling = false;
            if (handled) return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scroll -= (float) (scrollY * 16);
        return true;
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
