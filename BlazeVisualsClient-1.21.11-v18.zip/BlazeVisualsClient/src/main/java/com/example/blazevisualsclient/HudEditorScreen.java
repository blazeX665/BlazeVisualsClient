package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Редактор HUD: тяни элементы, меняй размер кнопками «Размер −/+» или колёсиком. */
public class HudEditorScreen extends Screen {
    private String dragging = null;
    private String selected = null;
    private int offX, offY;

    public HudEditorScreen() { super(Component.literal("HUD Editor")); }

    @Override
    protected void init() {
        int bw = 70, gap = 6, total = 4 * bw + 3 * gap;
        int x0 = (width - total) / 2, y = height - 28;
        addRenderableWidget(Button.builder(Component.literal("Сбросить"), b -> {
                    HudLayout.reset();
                    Config.save();
                })
                .bounds(x0, y, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Размер -"), b -> changeScale(-10))
                .bounds(x0 + (bw + gap), y, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Размер +"), b -> changeScale(10))
                .bounds(x0 + 2 * (bw + gap), y, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Готово"),
                        b -> Minecraft.getInstance().setScreen(new ClickGuiScreen()))
                .bounds(x0 + 3 * (bw + gap), y, bw, 20).build());
    }

    private void changeScale(int delta) {
        if (selected == null) return;
        HudLayout.setScale(selected, HudLayout.scale(selected) + delta);
        Config.save();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        Font f = font;
        int accent = HudRenderer.color(0f);

        for (String id : HudLayout.IDS) {
            if (!HudRenderer.enabled(id)) continue;
            int[] p = HudRenderer.pos(id, mc, f);
            int[] s = HudRenderer.scaledSize(id, mc, f);
            HudRenderer.drawScaled(id, g, f, mc, p[0], p[1], true);

            int col = id.equals(selected) ? 0xFFFFFFFF : accent;
            g.fill(p[0] - 2, p[1] - 2, p[0] + s[0] + 2, p[1] - 1, col);
            g.fill(p[0] - 2, p[1] + s[1] + 1, p[0] + s[0] + 2, p[1] + s[1] + 2, col);
            g.fill(p[0] - 2, p[1] - 2, p[0] - 1, p[1] + s[1] + 2, col);
            g.fill(p[0] + s[0] + 1, p[1] - 2, p[0] + s[0] + 2, p[1] + s[1] + 2, col);
        }
        String hint = selected == null
                ? "Тяни элементы. Нажми на элемент, чтобы менять размер"
                : "Размер: " + HudLayout.scale(selected) + "%  (кнопки или колёсико)";
        g.drawString(f, hint, (width - f.width(hint)) / 2, 8, 0xFFDDDDDD);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true;
        if (event.button() != 0) return false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return false;
        double mx = event.x(), my = event.y();
        for (int i = HudLayout.IDS.length - 1; i >= 0; i--) {
            String id = HudLayout.IDS[i];
            if (!HudRenderer.enabled(id)) continue;
            int[] p = HudRenderer.pos(id, mc, font);
            int[] s = HudRenderer.scaledSize(id, mc, font);
            if (mx >= p[0] - 2 && mx < p[0] + s[0] + 2 && my >= p[1] - 2 && my < p[1] + s[1] + 2) {
                dragging = id;
                selected = id;
                offX = (int) mx - p[0];
                offY = (int) my - p[1];
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (dragging != null) {
            Minecraft mc = Minecraft.getInstance();
            int[] s = HudRenderer.scaledSize(dragging, mc, font);
            int nx = (int) event.x() - offX;
            int ny = (int) event.y() - offY;
            nx = Math.max(0, Math.min(width - s[0], nx));
            ny = Math.max(0, Math.min(height - s[1], ny));
            HudLayout.set(dragging, nx, ny);
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging != null) {
            dragging = null;
            Config.save();
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (selected != null) {
            changeScale(scrollY > 0 ? 10 : -10);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }
}
