package com.example.blazevisualsclient;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;

/** Положение рук и предметов от первого лица (отдельно правая и левая рука). */
public final class ViewModel {
    private ViewModel() {}

    public static void apply(AbstractClientPlayer player, InteractionHand hand, PoseStack ps) {
        if (!ModuleManager.VIEW_MODEL.enabled) return;
        boolean right = (hand == InteractionHand.MAIN_HAND) == (player.getMainArm() == HumanoidArm.RIGHT);

        Setting x = right ? ModuleManager.VMR_X : ModuleManager.VML_X;
        Setting y = right ? ModuleManager.VMR_Y : ModuleManager.VML_Y;
        Setting z = right ? ModuleManager.VMR_Z : ModuleManager.VML_Z;
        Setting sc = right ? ModuleManager.VMR_SCALE : ModuleManager.VML_SCALE;
        Setting rx = right ? ModuleManager.VMR_RX : ModuleManager.VML_RX;
        Setting ry = right ? ModuleManager.VMR_RY : ModuleManager.VML_RY;
        Setting rz = right ? ModuleManager.VMR_RZ : ModuleManager.VML_RZ;

        // точка руки в пространстве камеры — вокруг неё вращаем и масштабируем
        double side = right ? 1.0 : -1.0;
        double hx = 0.56 * side, hy = -0.52, hz = -0.72;
        ps.translate(hx + x.value * 0.01, hy + y.value * 0.01, hz + z.value * 0.01);
        ps.mulPose(Axis.XP.rotationDegrees((float) rx.value));
        ps.mulPose(Axis.YP.rotationDegrees((float) ry.value));
        ps.mulPose(Axis.ZP.rotationDegrees((float) rz.value));
        float s = sc.value / 100f;
        ps.scale(s, s, s);
        ps.translate(-hx, -hy, -hz);
    }
}
