package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

/** Конфигурации: сохранить текущие настройки под именем и переключаться между наборами. */
public class ConfigScreen extends Screen {
    private static final int MAX_ROWS = 6;

    private String nameVal = "";
    private String status = "";

    public ConfigScreen() { super(Component.literal("Configs")); }

    private int w() { return Math.min(width - 20, 320); }
    private int x() { return (width - w()) / 2; }

    @Override
    protected void init() {
        int x = x(), w = w(), y = 44;

        EditBox box = new EditBox(font, x, y, w - 104, 18, Component.literal("name"));
        box.setMaxLength(24);
        box.setValue(nameVal);
        box.setResponder(s -> nameVal = s);
        addRenderableWidget(box);

        addRenderableWidget(Button.builder(Component.literal("Сохранить"), b -> {
                    String n = Configs.clean(nameVal);
                    Configs.save(n);
                    status = "Сохранено: " + n;
                    nameVal = "";
                    rebuildWidgets();
                })
                .bounds(x + w - 100, y - 1, 100, 20).build());

        List<String> list = Configs.list();
        int shown = Math.min(MAX_ROWS, list.size());
        for (int i = 0; i < shown; i++) {
            final String name = list.get(i);
            int ry = y + 32 + i * 24;
            addRenderableWidget(Button.builder(Component.literal("Загрузить: " + name), b -> {
                        Configs.load(name);
                        status = "Загружено: " + name;
                        rebuildWidgets();
                    })
                    .bounds(x, ry, w - 26, 20).build());
            addRenderableWidget(Button.builder(Component.literal("X"), b -> {
                        Configs.delete(name);
                        rebuildWidgets();
                    })
                    .bounds(x + w - 22, ry, 22, 20).build());
        }

        addRenderableWidget(Button.builder(Component.literal("Назад"),
                        b -> Minecraft.getInstance().setScreen(new ClickGuiScreen()))
                .bounds(x, y + 32 + shown * 24 + 8, 90, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        int x = x(), y = 44;
        String title = "Configs — наборы настроек";
        g.drawString(font, title, (width - font.width(title)) / 2, 12, 0xFFFFFFFF);
        g.drawString(font, "Название набора", x, y - 11, 0xFFB0B0B8);
        if (!status.isEmpty()) g.drawString(font, status, x, y + 22, 0xFFFFD166);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }
}
