package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

/** Предупреждает звуком и надписью, когда броня сильно изношена. */
public final class Pinger {
    private Pinger() {}

    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final String[] NAMES = {"Шлем", "Нагрудник", "Штаны", "Ботинки"};

    private static String warning = null;
    private static int ticks = 0;
    private static int sinceAlert = 1000;

    public static void tick(Minecraft mc) {
        if (!ModuleManager.PINGER.enabled || mc.player == null) {
            warning = null;
            return;
        }
        sinceAlert++;
        ticks++;
        if (ticks < 20) return;
        ticks = 0;

        String found = null;
        for (int i = 0; i < SLOTS.length; i++) {
            ItemStack st = mc.player.getItemBySlot(SLOTS[i]);
            if (st.isEmpty() || !st.isDamageableItem()) continue;
            int max = st.getMaxDamage();
            if (max <= 0) continue;
            int pct = (int) ((max - st.getDamageValue()) * 100L / max);
            if (pct <= ModuleManager.PG_THRESH.value) {
                found = NAMES[i] + " " + pct + "%";
                break;
            }
        }
        warning = found;
        if (found != null && sinceAlert >= 10) {   // не чаще раза в 10 секунд
            sinceAlert = 0;
            if (ModuleManager.PG_SOUND.on) Sounds.ping(0.6f);
            if (ModuleManager.PG_CHAT.on) {
                mc.player.displayClientMessage(Component.literal("[Pinger] Броня изношена: " + found), false);
            }
        }
    }

    public static void render(GuiGraphics g, Font font, Minecraft mc) {
        if (warning == null || !ModuleManager.PINGER.enabled) return;
        String text = "! Броня изношена: " + warning + " !";
        float pulse = 0.5f + 0.5f * (float) Math.sin(System.currentTimeMillis() / 180.0);
        int alpha = 140 + (int) (115 * pulse);
        int color = (alpha << 24) | 0xFF5555;
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        int w = font.width(text) + 12;
        Gfx.rr(g, (sw - w) / 2, sh / 4, w, 16, 5, 0xB0101018);
        g.drawString(font, text, (sw - font.width(text)) / 2, sh / 4 + 4, color);
    }
}
