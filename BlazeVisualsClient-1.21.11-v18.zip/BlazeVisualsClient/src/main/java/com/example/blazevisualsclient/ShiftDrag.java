package com.example.blazevisualsclient;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

/** Слоты, которые уже перенесли за текущее протягивание (чтобы не дублировать). */
public final class ShiftDrag {
    private ShiftDrag() {}

    private static final Set<Object> done = Collections.newSetFromMap(new IdentityHashMap<>());

    /** true — слот ещё не трогали в этом протягивании. */
    public static boolean add(Object slot) { return done.add(slot); }

    public static void reset() { done.clear(); }
}
