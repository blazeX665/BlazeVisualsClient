package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class KeyCommandScreen extends Screen {
    private static final int ROW = 24;

    public KeyCommandScreen() { super(Component.literal("KeyCommand")); }

    private int w() { return Math.min(width - 20, 340); }
    private int x() { return (width - w()) / 2; }
    private int top() { return 40; }

    @Override
    protected void init() {
        int x = x(), y = top();
        for (int i = 0; i < KeyCommands.SLOTS; i++) {
            final int idx = i;
            EditBox box = new EditBox(font, x + 120, y + i * ROW, w() - 120, 18, Component.literal("cmd" + (i + 1)));
            box.setMaxLength(256);
            box.setValue(KeyCommands.COMMANDS[i]);
            box.setResponder(s -> KeyCommands.COMMANDS[idx] = s);
            addRenderableWidget(box);
        }
        addRenderableWidget(Button.builder(Component.literal("Назад"),
                        b -> Minecraft.getInstance().setScreen(new ClickGuiScreen()))
                .bounds(x, y + KeyCommands.SLOTS * ROW + 8, 90, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        int x = x(), y = top();
        String title = "KeyCommand — команды на клавиши";
        g.drawString(font, title, (width - font.width(title)) / 2, 14, 0xFFFFFFFF);
        for (int i = 0; i < KeyCommands.SLOTS; i++) {
            String key = KeyCommands.KEYS[i] == null ? "?" : KeyCommands.KEYS[i].getTranslatedKeyMessage().getString();
            g.drawString(font, "Слот " + (i + 1) + " [" + key + "]", x, y + i * ROW + 5, 0xFFDDDDDD);
        }
        String hint = "Клавиши: Настройки → Управление → BlazeVisualsClient. Команда: /home или текст чата.";
        g.drawString(font, hint, Math.max(4, (width - font.width(hint)) / 2), y + KeyCommands.SLOTS * ROW + 36, 0xFF8A8A93);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }
}
