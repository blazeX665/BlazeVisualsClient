package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.util.Locale;

/** Фильтр запрещённых слов при отправке и звук, когда в чате пишут твой ник. */
public final class ChatTools {
    private ChatTools() {}

    public static String banned = "";    // слова через запятую
    public static String mentions = "";  // дополнительные ники через запятую
    private static long lastSound = 0L;

    public static boolean allowSend(String message) {
        if (!ModuleManager.CHAT_TOOLS.enabled || !ModuleManager.CT_FILTER.on || message == null) return true;
        String low = message.toLowerCase(Locale.ROOT);
        for (String w : banned.split(",")) {
            String word = w.trim().toLowerCase(Locale.ROOT);
            if (word.length() >= 2 && low.contains(word)) {
                var p = Minecraft.getInstance().player;
                if (p != null) {
                    p.displayClientMessage(Component.literal(
                            "[Фильтр] Не отправлено: в сообщении слово «" + word + "»"), false);
                }
                return false;
            }
        }
        return true;
    }

    public static void onReceive(Component msg) {
        if (!ModuleManager.CHAT_TOOLS.enabled || !ModuleManager.CT_MENTION.on) return;
        var p = Minecraft.getInstance().player;
        if (p == null) return;
        String text = msg.getString().toLowerCase(Locale.ROOT);
        String own = p.getName().getString().toLowerCase(Locale.ROOT);
        if (text.startsWith("<" + own + ">")) return;   // своё сообщение

        boolean hit = text.contains(own);
        if (!hit) {
            for (String n : mentions.split(",")) {
                String name = n.trim().toLowerCase(Locale.ROOT);
                if (name.length() >= 3 && text.contains(name)) { hit = true; break; }
            }
        }
        long now = System.currentTimeMillis();
        if (hit && now - lastSound > 1000) {
            lastSound = now;
            Sounds.ping(1.8f);
        }
    }
}
