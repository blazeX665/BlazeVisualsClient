package com.example.blazevisualsclient;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Сохранение модулей, настроек, команд, меток, HUD и т.д. */
public class Config {
    public static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("blazevisualsclient");
    }

    private static Path mainFile() {
        return FabricLoader.getInstance().getConfigDir().resolve("blazevisualsclient.properties");
    }

    private static boolean storable(Setting s) {
        return s.kind != Setting.Kind.PRESETS && s.kind != Setting.Kind.BUTTON;
    }

    public static void load() { load(mainFile()); }
    public static void save() { save(mainFile()); }

    public static void load(Path path) {
        Properties p = new Properties();
        try (var in = Files.newInputStream(path);
             var reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
            p.load(reader);
        } catch (IOException e) {
            return;
        }
        for (Module m : ModuleManager.ALL) {
            if (m != ModuleManager.ZOOM && !m.alwaysOn) {
                String v = p.getProperty("module." + m.name);
                if (v != null) {
                    m.enabled = Boolean.parseBoolean(v);
                    m.anim = m.enabled ? 1f : 0f;
                }
            }
            for (int i = 0; i < m.settings.size(); i++) {
                Setting s = m.settings.get(i);
                if (!storable(s)) continue;
                String v = p.getProperty("setting." + m.name + "." + i);
                if (v == null) continue;
                try {
                    if (s.kind == Setting.Kind.TOGGLE) s.on = Boolean.parseBoolean(v);
                    else s.value = Math.max(s.min, Math.min(s.max, Integer.parseInt(v.trim())));
                } catch (NumberFormatException ignored) { }
            }
        }
        for (int i = 0; i < KeyCommands.SLOTS; i++) {
            String v = p.getProperty("kc." + i);
            if (v != null) KeyCommands.COMMANDS[i] = v;
        }
        for (int i = 0; i < AutoCommand.SLOTS; i++) {
            String c = p.getProperty("ac." + i + ".cmd");
            if (c != null) AutoCommand.CMD[i] = c;
            try {
                String sec = p.getProperty("ac." + i + ".sec");
                if (sec != null) AutoCommand.SEC[i] = Math.max(5, Integer.parseInt(sec.trim()));
            } catch (NumberFormatException ignored) { }
        }
        ChatTools.banned = p.getProperty("ct.banned", ChatTools.banned);
        ChatTools.mentions = p.getProperty("ct.mentions", ChatTools.mentions);

        HudLayout.reset();
        for (String id : HudLayout.IDS) {
            try {
                String x = p.getProperty("hud." + id + ".x"), y = p.getProperty("hud." + id + ".y");
                if (x != null && y != null) HudLayout.set(id, Integer.parseInt(x), Integer.parseInt(y));
                String sc = p.getProperty("hud." + id + ".s");
                if (sc != null) HudLayout.setScale(id, Integer.parseInt(sc.trim()));
            } catch (NumberFormatException ignored) { }
        }

        Waypoints.LIST.clear();
        try {
            int n = Integer.parseInt(p.getProperty("wp.count", "0"));
            for (int i = 0; i < n; i++) {
                Waypoints.add(p.getProperty("wp." + i + ".name", "Метка"),
                        Double.parseDouble(p.getProperty("wp." + i + ".x", "0")),
                        Double.parseDouble(p.getProperty("wp." + i + ".y", "64")),
                        Double.parseDouble(p.getProperty("wp." + i + ".z", "0")));
            }
        } catch (NumberFormatException ignored) { }

        try {
            int n = Integer.parseInt(p.getProperty("acc.count", "-1"));
            if (n >= 0) {
                Accounts.LIST.clear();
                for (int i = 0; i < n; i++) {
                    String a = p.getProperty("acc." + i);
                    if (a != null && !a.isBlank()) Accounts.LIST.add(a);
                }
            }
        } catch (NumberFormatException ignored) { }
    }

    public static void save(Path path) {
        Properties p = new Properties();
        for (Module m : ModuleManager.ALL) {
            p.setProperty("module." + m.name, String.valueOf(m.enabled));
            for (int i = 0; i < m.settings.size(); i++) {
                Setting s = m.settings.get(i);
                if (!storable(s)) continue;
                p.setProperty("setting." + m.name + "." + i,
                        s.kind == Setting.Kind.TOGGLE ? String.valueOf(s.on) : String.valueOf(s.value));
            }
        }
        for (int i = 0; i < KeyCommands.SLOTS; i++) {
            p.setProperty("kc." + i, KeyCommands.COMMANDS[i] == null ? "" : KeyCommands.COMMANDS[i]);
        }
        for (int i = 0; i < AutoCommand.SLOTS; i++) {
            p.setProperty("ac." + i + ".cmd", AutoCommand.CMD[i] == null ? "" : AutoCommand.CMD[i]);
            p.setProperty("ac." + i + ".sec", String.valueOf(AutoCommand.SEC[i]));
        }
        p.setProperty("ct.banned", ChatTools.banned);
        p.setProperty("ct.mentions", ChatTools.mentions);
        for (String id : HudLayout.IDS) {
            int[] pos = HudLayout.get(id);
            if (pos != null) {
                p.setProperty("hud." + id + ".x", String.valueOf(pos[0]));
                p.setProperty("hud." + id + ".y", String.valueOf(pos[1]));
            }
            p.setProperty("hud." + id + ".s", String.valueOf(HudLayout.scale(id)));
        }
        p.setProperty("wp.count", String.valueOf(Waypoints.LIST.size()));
        for (int i = 0; i < Waypoints.LIST.size(); i++) {
            Waypoints.Waypoint w = Waypoints.LIST.get(i);
            p.setProperty("wp." + i + ".name", w.name);
            p.setProperty("wp." + i + ".x", String.valueOf(w.x));
            p.setProperty("wp." + i + ".y", String.valueOf(w.y));
            p.setProperty("wp." + i + ".z", String.valueOf(w.z));
        }
        p.setProperty("acc.count", String.valueOf(Accounts.LIST.size()));
        for (int i = 0; i < Accounts.LIST.size(); i++) p.setProperty("acc." + i, Accounts.LIST.get(i));

        try {
            if (path.getParent() != null) Files.createDirectories(path.getParent());
            try (var out = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
                p.store(out, "BlazeVisualsClient");
            }
        } catch (IOException ignored) { }
    }
}
