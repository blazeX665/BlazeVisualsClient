package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Радар: сообщает в чат и звуком, когда рядом появляется новый игрок. */
public final class Scanner {
    private Scanner() {}

    private static int ticks = 0;
    private static Set<UUID> known = new HashSet<>();

    public static void tick(Minecraft mc) {
        if (!ModuleManager.SCANNER.enabled || mc.player == null || mc.level == null) {
            known.clear();
            ticks = 0;
            return;
        }
        ticks++;
        if (ticks < ModuleManager.SC_INTERVAL.value * 20) return;
        ticks = 0;

        double range = ModuleManager.SC_RADIUS.value;
        Set<UUID> now = new HashSet<>();
        for (var p : mc.level.players()) {
            if (p == mc.player) continue;
            float d = mc.player.distanceTo(p);
            if (d > range) continue;
            now.add(p.getUUID());
            if (!known.contains(p.getUUID())) {
                if (ModuleManager.SC_CHAT.on) {
                    mc.player.displayClientMessage(Component.literal(
                            "[Scanner] " + p.getName().getString() + " рядом: " + (int) d + "м"), false);
                }
                if (ModuleManager.SC_SOUND.on) Sounds.ping(1.4f);
            }
        }
        known = now;
    }
}
