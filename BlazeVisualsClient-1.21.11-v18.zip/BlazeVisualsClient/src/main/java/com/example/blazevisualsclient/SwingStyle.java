package com.example.blazevisualsclient;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.phys.HitResult;

/** Анимации рук: удар, ломание блоков, еда. */
public final class SwingStyle {
    private SwingStyle() {}

    /** Какой стиль сейчас: при взгляде на блок — стиль ломания, иначе — стиль удара. */
    private static int style() {
        HitResult hit = Minecraft.getInstance().hitResult;
        boolean mining = hit != null && hit.getType() == HitResult.Type.BLOCK;
        return mining ? ModuleManager.SW_MINE.value : ModuleManager.SW_STYLE.value;
    }

    /** Кривая прогресса взмаха (стили 1–3). */
    public static float apply(float p) {
        if (!ModuleManager.SWING.enabled) return p;
        p = Math.max(0f, Math.min(1f, p));
        return switch (style()) {
            case 1 -> p * p * (3f - 2f * p);            // плавный
            case 2 -> p * p;                            // разгон
            case 3 -> 1f - (1f - p) * (1f - p);         // резкий старт
            default -> p;
        };
    }

    /** Дополнительное движение руки после ванильного взмаха (стили 4–6). */
    public static void extra(PoseStack ps, HumanoidArm arm, float p) {
        if (!ModuleManager.SWING.enabled) return;
        int st = style();
        if (st < 4) return;

        float k = ModuleManager.SW_POWER.value / 100f;
        float side = arm == HumanoidArm.RIGHT ? 1f : -1f;
        float t = Math.max(0f, Math.min(1f, p));
        float wave = (float) Math.sin(Math.PI * t);

        switch (st) {
            case 4 -> ps.translate(0.0, 0.05 * k * wave, -0.45 * k * wave);              // колющий
            case 5 -> {                                                                   // рубящий
                ps.mulPose(Axis.ZP.rotationDegrees(side * -55f * k * wave));
                ps.mulPose(Axis.XP.rotationDegrees(-25f * k * wave));
            }
            case 6 -> {                                                                   // широкий мах
                ps.translate(-side * 0.25 * k * wave, -0.05 * k * wave, 0.0);
                ps.mulPose(Axis.YP.rotationDegrees(-side * 35f * k * wave));
            }
            default -> { }
        }
    }

    /** true — не поднимать руку к лицу при еде и питье. */
    public static boolean noEat() {
        return ModuleManager.SWING.enabled && ModuleManager.SW_EAT.value == 1;
    }
}
