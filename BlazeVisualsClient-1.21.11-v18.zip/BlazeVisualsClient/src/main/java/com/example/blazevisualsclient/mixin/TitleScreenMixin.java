package com.example.blazevisualsclient.mixin;

import com.example.blazevisualsclient.BlazeTitleScreen;
import com.example.blazevisualsclient.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
    protected TitleScreenMixin(Component title) { super(title); }

    /** Кнопка возврата в меню BlazeVisualsClient из классического меню. */
    @Inject(method = "init", at = @At("TAIL"))
    private void blaze$backToBlaze(CallbackInfo ci) {
        if (!ModuleManager.CUSTOM_MENU.enabled) return;
        this.addRenderableWidget(Button.builder(Component.literal("BlazeVisualsClient"), b -> {
            BlazeTitleScreen.vanilla = false;
            Minecraft.getInstance().setScreen(new BlazeTitleScreen());
        }).bounds(6, this.height - 52, 130, 20).build());
    }
}
