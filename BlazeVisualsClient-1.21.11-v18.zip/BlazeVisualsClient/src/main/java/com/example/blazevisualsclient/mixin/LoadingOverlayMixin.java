package com.example.blazevisualsclient.mixin;

import com.example.blazevisualsclient.LoadingArt;
import com.example.blazevisualsclient.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.LoadingOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LoadingOverlay.class)
public class LoadingOverlayMixin {
    /** Поверх логотипа Mojang рисуем свой загрузочный экран. */
    @Inject(method = "render", at = @At("TAIL"))
    private void blaze$loading(GuiGraphics g, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (!ModuleManager.CUSTOM_MENU.enabled) return;
        var window = Minecraft.getInstance().getWindow();
        LoadingArt.render(g, window.getGuiScaledWidth(), window.getGuiScaledHeight());
    }
}
