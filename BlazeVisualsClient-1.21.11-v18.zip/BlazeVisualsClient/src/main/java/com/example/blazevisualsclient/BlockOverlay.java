package com.example.blazevisualsclient;

/** Настройки рамки выделенного блока. */
public final class BlockOverlay {
    private BlockOverlay() {}

    public static boolean enabled() { return ModuleManager.BLOCK_OVERLAY.enabled; }

    public static int color() {
        int rgb = Theme.hsb(ModuleManager.BO_H.value, ModuleManager.BO_S.value, ModuleManager.BO_B.value) & 0x00FFFFFF;
        int a = Math.round(ModuleManager.BO_ALPHA.value * 2.55f);
        return (a << 24) | rgb;
    }

    public static float width() { return ModuleManager.BO_WIDTH.value; }
}
