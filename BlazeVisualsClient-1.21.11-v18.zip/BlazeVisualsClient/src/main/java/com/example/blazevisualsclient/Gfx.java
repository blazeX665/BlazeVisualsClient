package com.example.blazevisualsclient;

import net.minecraft.client.gui.GuiGraphics;

public final class Gfx {
    private Gfx() {}

    /** Скруглённый прямоугольник радиуса r (слои не накладываются, полупрозрачность не двоится). */
    public static void rr(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) {
            g.fill(x, y, x + w, y + h, c);
            return;
        }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * (double) r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, c);
            g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, c);
        }
        g.fill(x, y + r, x + w, y + h - r, c);
    }

    /** Небольшое скругление (для HUD). */
    public static void round(GuiGraphics g, int x, int y, int w, int h, int c) {
        rr(g, x, y, w, h, 3, c);
    }

    /** Стрелка-шеврон вниз (или вверх). */
    public static void chevron(GuiGraphics g, int cx, int cy, boolean up, int c) {
        for (int i = 0; i < 4; i++) {
            int row = up ? (3 - i) : i;
            g.fill(cx - 4 + i, cy + row, cx - 3 + i, cy + row + 1, c);
            g.fill(cx + 3 - i, cy + row, cx + 4 - i, cy + row + 1, c);
        }
    }

    /** Стрелка-треугольник. angleDeg: 0 = вверх, положительный угол — по часовой стрелке. */
    public static void arrow(GuiGraphics g, int cx, int cy, double angleDeg, int color) {
        double a = Math.toRadians(angleDeg);
        double sn = Math.sin(a), cs = Math.cos(a);
        double[][] local = {{0, -5.5}, {-4.2, 4.2}, {0, 1.6}, {4.2, 4.2}};
        double[] vx = new double[4], vy = new double[4];
        for (int i = 0; i < 4; i++) {
            vx[i] = local[i][0] * cs - local[i][1] * sn;
            vy[i] = local[i][0] * sn + local[i][1] * cs;
        }
        for (int py = -8; py <= 8; py++) {
            for (int px = -8; px <= 8; px++) {
                double x = px + 0.5, y = py + 0.5;
                // два треугольника: (кончик, левый, центр) и (кончик, центр, правый)
                if (inTri(x, y, vx[0], vy[0], vx[1], vy[1], vx[2], vy[2])
                        || inTri(x, y, vx[0], vy[0], vx[2], vy[2], vx[3], vy[3])) {
                    g.fill(cx + px, cy + py, cx + px + 1, cy + py + 1, color);
                }
            }
        }
    }

    private static boolean inTri(double px, double py, double ax, double ay,
                                 double bx, double by, double cx, double cy) {
        double d1 = (px - bx) * (ay - by) - (ax - bx) * (py - by);
        double d2 = (px - cx) * (by - cy) - (bx - cx) * (py - cy);
        double d3 = (px - ax) * (cy - ay) - (cx - ax) * (py - ay);
        boolean neg = d1 < 0 || d2 < 0 || d3 < 0;
        boolean pos = d1 > 0 || d2 > 0 || d3 > 0;
        return !(neg && pos);
    }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (int) (((a >>> 24) & 255) * (1 - t) + ((b >>> 24) & 255) * t);
        int rr = (int) (((a >>> 16) & 255) * (1 - t) + ((b >>> 16) & 255) * t);
        int gg = (int) (((a >>> 8) & 255) * (1 - t) + ((b >>> 8) & 255) * t);
        int bb = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (aa << 24) | (rr << 16) | (gg << 8) | bb;
    }
}
