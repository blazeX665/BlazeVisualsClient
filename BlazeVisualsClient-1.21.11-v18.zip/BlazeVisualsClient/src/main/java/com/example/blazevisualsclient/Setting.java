package com.example.blazevisualsclient;

/** Настройка модуля: переключатель, число (-/+), выбор, ползунок, пресеты цвета или кнопка. */
public class Setting {
    public enum Kind { TOGGLE, STEP, CHOICE, SLIDER, PRESETS, BUTTON }

    public final String name;
    public final Kind kind;
    public boolean on;
    public int value;
    public final int min, max, step;
    public final String suffix;
    public final String[] options;          // для CHOICE
    public final Runnable action;           // для BUTTON
    public final Setting linkH, linkS, linkB; // для PRESETS

    private Setting(String name, Kind kind, boolean on, int value, int min, int max, int step,
                    String suffix, String[] options, Runnable action,
                    Setting h, Setting s, Setting b) {
        this.name = name;
        this.kind = kind;
        this.on = on;
        this.value = value;
        this.min = min;
        this.max = max;
        this.step = step;
        this.suffix = suffix;
        this.options = options;
        this.action = action;
        this.linkH = h;
        this.linkS = s;
        this.linkB = b;
    }

    public static Setting toggle(String name, boolean def) {
        return new Setting(name, Kind.TOGGLE, def, 0, 0, 0, 0, "", null, null, null, null, null);
    }

    public static Setting step(String name, int def, int min, int max, int step, String suffix) {
        return new Setting(name, Kind.STEP, false, def, min, max, step, suffix, null, null, null, null, null);
    }

    public static Setting choice(String name, int def, String... options) {
        return new Setting(name, Kind.CHOICE, false, def, 0, options.length - 1, 1, "", options, null, null, null, null);
    }

    public static Setting slider(String name, int def, int min, int max, String suffix) {
        return new Setting(name, Kind.SLIDER, false, def, min, max, 1, suffix, null, null, null, null, null);
    }

    public static Setting presets(String name, Setting h, Setting s, Setting b) {
        return new Setting(name, Kind.PRESETS, false, 0, 0, 0, 0, "", null, null, h, s, b);
    }

    public static Setting button(String label, Runnable action) {
        return new Setting(label, Kind.BUTTON, false, 0, 0, 0, 0, "", null, action, null, null, null);
    }

    public void inc() {
        if (kind == Kind.CHOICE) value = (value + 1) % options.length;
        else value = Math.min(max, value + step);
    }

    public void dec() {
        if (kind == Kind.CHOICE) value = (value - 1 + options.length) % options.length;
        else value = Math.max(min, value - step);
    }
}
