package com.example.blazevisualsclient;

import net.minecraft.client.gui.GuiGraphics;

/** Свой загрузочный экран вместо логотипа Mojang. Текст не используется (шрифт ещё не готов). */
public final class LoadingArt {
    private LoadingArt() {}

    private static final String[][] GLYPHS = {
            {"####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."},   // B
            {"#....", "#....", "#....", "#....", "#....", "#....", "#####"},   // L
            {".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"},   // A
            {"#####", "....#", "...#.", "..#..", ".#...", "#....", "#####"},   // Z
            {"#####", "#....", "#....", "####.", "#....", "#....", "#####"}    // E
    };

    public static void render(GuiGraphics g, int w, int h) {
        MenuBackground.render(g, w, h);

        int s = h < 300 ? 3 : 5;
        int letterW = 5 * s, gap = s;
        int total = GLYPHS.length * letterW + (GLYPHS.length - 1) * gap;
        int lx = (w - total) / 2;
        int ly = h / 2 - (7 * s) / 2 - 12;

        for (int i = 0; i < GLYPHS.length; i++) {
            int x = lx + i * (letterW + gap);
            glyph(g, GLYPHS[i], x + 2, ly + 2, s, 0xAA000000);
            glyph(g, GLYPHS[i], x, ly, s, HudRenderer.color(i * 0.12f));
        }

        // индикатор загрузки: бегущий отрезок
        int bw = Math.min(180, w - 60);
        int bx = (w - bw) / 2;
        int by = ly + 7 * s + 18;
        Gfx.rr(g, bx, by, bw, 4, 2, 0xFF2C2C34);
        double t = (System.currentTimeMillis() % 1600L) / 1600.0;
        int seg = bw / 3;
        int pos = (int) ((bw + seg) * t) - seg;
        int x1 = Math.max(0, pos), x2 = Math.min(bw, pos + seg);
        if (x2 - x1 > 1) Gfx.rr(g, bx + x1, by, x2 - x1, 4, 2, HudRenderer.color(0f));
    }

    private static void glyph(GuiGraphics g, String[] rows, int x, int y, int s, int color) {
        for (int r = 0; r < rows.length; r++) {
            for (int c = 0; c < rows[r].length(); c++) {
                if (rows[r].charAt(c) == '#') {
                    g.fill(x + c * s, y + r * s, x + c * s + s, y + r * s + s, color);
                }
            }
        }
    }
}
