package com.example.blazevisualsclient;

import com.example.blazevisualsclient.mixin.MinecraftAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** Быстрая смена ника (offline-аккаунты). Пароли и токены не хранятся. */
public final class Accounts {
    private Accounts() {}

    public static final List<String> LIST = new ArrayList<>();

    public static String current() {
        return Minecraft.getInstance().getUser().getName();
    }

    public static boolean valid(String name) {
        return name != null && name.matches("[A-Za-z0-9_]{3,16}");
    }

    public static void switchTo(String name) {
        Minecraft mc = Minecraft.getInstance();
        UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
        ((MinecraftAccessor) mc).blaze$setUser(new User(name, uuid, "0", Optional.empty(), Optional.empty()));
    }
}
