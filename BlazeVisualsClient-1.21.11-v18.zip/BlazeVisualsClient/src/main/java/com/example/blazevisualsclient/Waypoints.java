package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Метки по координатам: рисуются на экране (HUD) с проекцией 3D → 2D. */
public final class Waypoints {
    private Waypoints() {}

    public static final class Waypoint {
        public String name;
        public double x, y, z;

        public Waypoint(String name, double x, double y, double z) {
            this.name = name;
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    public static final List<Waypoint> LIST = new ArrayList<>();

    public static void add(String name, double x, double y, double z) {
        LIST.add(new Waypoint(name, x, y, z));
    }

    public static void render(GuiGraphics g, Font font, Minecraft mc, float partial) {
        if (!ModuleManager.WAYPOINTS.enabled || mc.player == null || LIST.isEmpty()) return;

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();

        Vec3 eye = mc.player.getEyePosition(partial);
        Vec3 look = mc.player.getViewVector(partial);
        Vec3 right = look.cross(new Vec3(0, 1, 0));
        right = right.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : right.normalize();
        Vec3 up = right.cross(look);

        double tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        double aspect = (double) sw / (double) sh;
        boolean showDist = ModuleManager.WP_DIST.on;

        int idx = 0;
        for (Waypoint wp : LIST) {
            Vec3 d = new Vec3(wp.x + 0.5, wp.y + 0.5, wp.z + 0.5).subtract(eye);
            double dz = d.dot(look), dx = d.dot(right), dy = d.dot(up);
            double dist = d.length();

            double sx, sy;
            boolean onScreen = false;
            if (dz > 0.1) {
                sx = sw / 2.0 * (1.0 + dx / (dz * tanHalf * aspect));
                sy = sh / 2.0 * (1.0 - dy / (dz * tanHalf));
                onScreen = sx >= 12 && sx <= sw - 12 && sy >= 20 && sy <= sh - 12;
            } else {
                sx = sw / 2.0 + dx * 1000.0;
                sy = sh / 2.0 - dy * 1000.0;
            }
            if (!onScreen) {
                double vx = sx - sw / 2.0, vy = sy - sh / 2.0;
                if (Math.abs(vx) < 1e-6 && Math.abs(vy) < 1e-6) vy = 1;
                double hx = sw / 2.0 - 14, hy = sh / 2.0 - 20;
                double t = Math.min(hx / Math.max(1e-6, Math.abs(vx)), hy / Math.max(1e-6, Math.abs(vy)));
                sx = sw / 2.0 + vx * t;
                sy = sh / 2.0 + vy * t;
            }

            int cx = (int) Math.round(sx), cy = (int) Math.round(sy);
            int col = HudRenderer.color(idx * 0.15f);

            // ромб-маркер
            for (int r = -4; r <= 4; r++) {
                int half = 4 - Math.abs(r);
                g.fill(cx - half, cy + r, cx + half + 1, cy + r + 1, col);
            }
            g.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);

            // подпись
            String label = wp.name + (showDist ? "  " + (int) dist + "м" : "");
            int tw = font.width(label);
            int tx = Math.max(2, Math.min(sw - tw - 6, cx - tw / 2 - 2));
            int ty = Math.max(2, Math.min(sh - 14, cy - 18));
            Gfx.round(g, tx, ty, tw + 6, 12, 0xA0101018);
            g.drawString(font, label, tx + 3, ty + 2, 0xFFFFFFFF);
            idx++;
        }
    }
}
