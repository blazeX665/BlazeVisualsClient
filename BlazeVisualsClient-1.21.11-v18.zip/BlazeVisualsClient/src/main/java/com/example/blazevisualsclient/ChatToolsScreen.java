package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ChatToolsScreen extends Screen {
    public ChatToolsScreen() { super(Component.literal("Chat Tools")); }

    private int w() { return Math.min(width - 20, 340); }
    private int x() { return (width - w()) / 2; }

    @Override
    protected void init() {
        int x = x(), w = w(), y = 54;
        EditBox banned = new EditBox(font, x, y, w, 18, Component.literal("banned"));
        banned.setMaxLength(500);
        banned.setValue(ChatTools.banned);
        banned.setResponder(s -> ChatTools.banned = s);
        addRenderableWidget(banned);

        EditBox mentions = new EditBox(font, x, y + 46, w, 18, Component.literal("mentions"));
        mentions.setMaxLength(300);
        mentions.setValue(ChatTools.mentions);
        mentions.setResponder(s -> ChatTools.mentions = s);
        addRenderableWidget(mentions);

        addRenderableWidget(Button.builder(Component.literal("Назад"),
                        b -> Minecraft.getInstance().setScreen(new ClickGuiScreen()))
                .bounds(x, y + 82, 90, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        int x = x(), y = 54;
        String title = "Chat Tools — фильтр слов и звук на ник";
        g.drawString(font, title, (width - font.width(title)) / 2, 14, 0xFFFFFFFF);
        g.drawString(font, "Запрещённые слова (через запятую) — такие сообщения не отправятся", x, y - 12, 0xFFB0B0B8);
        g.drawString(font, "Доп. ники/слова для звука (через запятую). Свой ник учитывается сам", x, y + 34, 0xFFB0B0B8);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }
}
