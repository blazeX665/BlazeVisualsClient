package com.example.blazevisualsclient.mixin;

import com.example.blazevisualsclient.BlockOverlay;
import net.minecraft.client.renderer.LevelRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(LevelRenderer.class)
public class LevelRendererMixin {
    /** Block Overlay: цвет рамки выделенного блока. */
    @ModifyVariable(method = "renderHitOutline", at = @At("HEAD"), argsOnly = true)
    private static int blaze$outlineColor(int color) {
        return BlockOverlay.enabled() ? BlockOverlay.color() : color;
    }

    /** Block Overlay: толщина линий. */
    @ModifyVariable(method = "renderHitOutline", at = @At("HEAD"), argsOnly = true)
    private static float blaze$outlineWidth(float width) {
        return BlockOverlay.enabled() ? BlockOverlay.width() : width;
    }
}
