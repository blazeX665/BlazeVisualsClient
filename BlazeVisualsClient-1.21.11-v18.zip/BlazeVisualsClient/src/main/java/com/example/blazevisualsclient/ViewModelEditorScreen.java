package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Редактор View Model: тяни маркеры рук мышью, колёсико меняет размер выбранной руки. */
public class ViewModelEditorScreen extends Screen {
    private static final double K = 0.8;       // пикселей экрана на единицу настройки
    private static final int MW = 50, MH = 26;

    private int active = -1;   // какую руку тянем: 0 — правая, 1 — левая
    private int selected = 0;  // для колёсика

    public ViewModelEditorScreen() { super(Component.literal("View Model")); }

    private int baseX(int hand) { return hand == 0 ? (int) (width * 0.72) : (int) (width * 0.28); }
    private int baseY() { return (int) (height * 0.68); }

    private Setting sx(int h) { return h == 0 ? ModuleManager.VMR_X : ModuleManager.VML_X; }
    private Setting sy(int h) { return h == 0 ? ModuleManager.VMR_Y : ModuleManager.VML_Y; }
    private Setting ss(int h) { return h == 0 ? ModuleManager.VMR_SCALE : ModuleManager.VML_SCALE; }

    private int markerX(int h) { return baseX(h) + (int) (sx(h).value * K); }
    private int markerY(int h) { return baseY() - (int) (sy(h).value * K); }

    @Override
    protected void init() {
        ModuleManager.VIEW_MODEL.enabled = true;
        addRenderableWidget(Button.builder(Component.literal("Сбросить"), b -> resetAll())
                .bounds(width / 2 - 94, height - 28, 90, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Готово"),
                        b -> Minecraft.getInstance().setScreen(new ClickGuiScreen()))
                .bounds(width / 2 + 4, height - 28, 90, 20).build());
    }

    private void resetAll() {
        for (Setting s : new Setting[]{
                ModuleManager.VMR_X, ModuleManager.VMR_Y, ModuleManager.VMR_Z,
                ModuleManager.VMR_RX, ModuleManager.VMR_RY, ModuleManager.VMR_RZ,
                ModuleManager.VML_X, ModuleManager.VML_Y, ModuleManager.VML_Z,
                ModuleManager.VML_RX, ModuleManager.VML_RY, ModuleManager.VML_RZ}) {
            s.value = 0;
        }
        ModuleManager.VMR_SCALE.value = 100;
        ModuleManager.VML_SCALE.value = 100;
        Config.save();
    }

    /** Фон не рисуем, чтобы видеть настоящие руки за экраном. */
    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float delta) { }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        Font f = font;
        int accent = HudRenderer.color(0f);

        for (int h = 0; h < 2; h++) {
            int cx = markerX(h), cy = markerY(h);
            // след от исходной позиции
            Gfx.rr(g, baseX(h) - 2, baseY() - 2, 4, 4, 2, 0x60FFFFFF);

            boolean sel = h == selected || h == active;
            Gfx.rr(g, cx - MW / 2 - 1, cy - MH / 2 - 1, MW + 2, MH + 2, 7, sel ? 0xFFFFFFFF : accent);
            Gfx.rr(g, cx - MW / 2, cy - MH / 2, MW, MH, 6, 0xE0101018);
            String name = h == 0 ? "Правая" : "Левая";
            g.drawString(f, name, cx - f.width(name) / 2, cy - 9, 0xFFFFFFFF);
            String vals = sx(h).value + " " + sy(h).value + " · " + ss(h).value + "%";
            g.drawString(f, vals, cx - f.width(vals) / 2, cy + 2, 0xFF9AE6A0);
        }

        String hint = "Тяни маркер руки мышью. Колёсико — размер выбранной руки";
        g.drawString(f, hint, (width - f.width(hint)) / 2, 8, 0xFFFFFFFF);
        String hint2 = "X, Y — положение; глубину и вращение настраивай в меню View Model";
        g.drawString(f, hint2, (width - f.width(hint2)) / 2, 20, 0xFFAAAAAA);
    }

    private int hit(double mx, double my) {
        for (int h = 1; h >= 0; h--) {
            int cx = markerX(h), cy = markerY(h);
            if (mx >= cx - MW / 2 && mx < cx + MW / 2 && my >= cy - MH / 2 && my < cy + MH / 2) return h;
        }
        return -1;
    }

    private void moveTo(int h, double mx, double my) {
        int vx = (int) Math.round((mx - baseX(h)) / K);
        int vy = (int) Math.round(-(my - baseY()) / K);
        sx(h).value = Math.max(sx(h).min, Math.min(sx(h).max, vx));
        sy(h).value = Math.max(sy(h).min, Math.min(sy(h).max, vy));
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true;
        if (event.button() != 0) return false;
        int h = hit(event.x(), event.y());
        if (h < 0) return false;
        active = h;
        selected = h;
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (active >= 0) {
            moveTo(active, event.x(), event.y());
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (active >= 0) {
            active = -1;
            Config.save();
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        Setting s = ss(selected);
        s.value = Math.max(s.min, Math.min(s.max, s.value + (scrollY > 0 ? 5 : -5)));
        return true;
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
