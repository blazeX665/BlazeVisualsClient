package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;

/** Команды, которые выполняются сами по таймеру (минимум раз в 5 секунд). */
public final class AutoCommand {
    private AutoCommand() {}

    public static final int SLOTS = 3;
    public static final String[] CMD = {"", "", ""};
    public static final int[] SEC = {300, 300, 300};
    private static final int[] left = new int[SLOTS];

    public static void tick(Minecraft mc) {
        for (int i = 0; i < SLOTS; i++) {
            if (!ModuleManager.AUTO_COMMAND.enabled || mc.player == null
                    || CMD[i] == null || CMD[i].isBlank()) {
                left[i] = 0;
                continue;
            }
            if (left[i] <= 0) left[i] = Math.max(5, SEC[i]) * 20;
            left[i]--;
            if (left[i] <= 0) KeyCommands.run(mc, CMD[i]);
        }
    }
}
