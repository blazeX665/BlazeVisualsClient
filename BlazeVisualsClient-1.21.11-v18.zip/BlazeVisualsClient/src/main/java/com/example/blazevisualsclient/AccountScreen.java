package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class AccountScreen extends Screen {
    private static final int MAX_ROWS = 6;

    private final Screen parent;
    private String nickVal = "";
    private String status = "";

    public AccountScreen(Screen parent) {
        super(Component.literal("Аккаунты"));
        this.parent = parent;
    }

    private int w() { return Math.min(width - 20, 320); }
    private int x() { return (width - w()) / 2; }

    @Override
    protected void init() {
        int x = x(), w = w(), y = 44;

        EditBox box = new EditBox(font, x, y, w - 104, 18, Component.literal("nick"));
        box.setMaxLength(16);
        box.setValue(nickVal);
        box.setResponder(s -> nickVal = s);
        addRenderableWidget(box);

        addRenderableWidget(Button.builder(Component.literal("Добавить"), b -> addNick())
                .bounds(x + w - 100, y - 1, 100, 20).build());

        int shown = Math.min(MAX_ROWS, Accounts.LIST.size());
        for (int i = 0; i < shown; i++) {
            final String name = Accounts.LIST.get(i);
            int ry = y + 32 + i * 24;
            boolean cur = name.equals(Accounts.current());
            addRenderableWidget(Button.builder(Component.literal((cur ? "* " : "") + name), b -> {
                        Accounts.switchTo(name);
                        status = "Ник изменён: " + name;
                        rebuildWidgets();
                    })
                    .bounds(x, ry, w - 26, 20).build());
            addRenderableWidget(Button.builder(Component.literal("X"), b -> {
                        Accounts.LIST.remove(name);
                        Config.save();
                        rebuildWidgets();
                    })
                    .bounds(x + w - 22, ry, 22, 20).build());
        }

        addRenderableWidget(Button.builder(Component.literal("Назад"),
                        b -> Minecraft.getInstance().setScreen(parent))
                .bounds(x, y + 32 + shown * 24 + 8, 90, 20).build());
    }

    private void addNick() {
        String n = nickVal.trim();
        if (!Accounts.valid(n)) {
            status = "Ник: 3–16 символов, только A-Z, 0-9 и _";
            return;
        }
        if (!Accounts.LIST.contains(n)) Accounts.LIST.add(n);
        Config.save();
        nickVal = "";
        status = "Добавлено: " + n + " (нажми на ник, чтобы войти)";
        rebuildWidgets();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        int x = x(), y = 44;
        String title = "Быстрая смена аккаунта";
        g.drawString(font, title, (width - font.width(title)) / 2, 12, 0xFFFFFFFF);
        g.drawString(font, "Сейчас: " + Accounts.current(), (width - font.width("Сейчас: " + Accounts.current())) / 2, 24, 0xFF9AE6A0);
        g.drawString(font, "Новый ник", x, y - 11, 0xFFB0B0B8);
        if (!status.isEmpty()) g.drawString(font, status, x, y + 22, 0xFFFFD166);
        String hint = "Только offline-аккаунты. Пароли и токены не хранятся.";
        g.drawString(font, hint, (width - font.width(hint)) / 2, height - 14, 0xFF6C6C75);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }
}
