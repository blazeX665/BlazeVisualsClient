package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class AutoCommandScreen extends Screen {
    private static final int ROW = 26;

    public AutoCommandScreen() { super(Component.literal("Auto Command")); }

    private int w() { return Math.min(width - 20, 340); }
    private int x() { return (width - w()) / 2; }

    @Override
    protected void init() {
        int x = x(), w = w(), y = 44;
        for (int i = 0; i < AutoCommand.SLOTS; i++) {
            final int idx = i;
            EditBox cmd = new EditBox(font, x + 52, y + i * ROW, w - 52 - 64, 18, Component.literal("cmd"));
            cmd.setMaxLength(256);
            cmd.setValue(AutoCommand.CMD[i]);
            cmd.setResponder(s -> AutoCommand.CMD[idx] = s);
            addRenderableWidget(cmd);

            EditBox sec = new EditBox(font, x + w - 58, y + i * ROW, 58, 18, Component.literal("sec"));
            sec.setMaxLength(6);
            sec.setValue(String.valueOf(AutoCommand.SEC[i]));
            sec.setResponder(s -> {
                try { AutoCommand.SEC[idx] = Math.max(5, Integer.parseInt(s.trim())); }
                catch (NumberFormatException ignored) { }
            });
            addRenderableWidget(sec);
        }
        addRenderableWidget(Button.builder(Component.literal("Назад"),
                        b -> Minecraft.getInstance().setScreen(new ClickGuiScreen()))
                .bounds(x, y + AutoCommand.SLOTS * ROW + 8, 90, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        int x = x(), w = w(), y = 44;
        String title = "Auto Command — команды по таймеру";
        g.drawString(font, title, (width - font.width(title)) / 2, 12, 0xFFFFFFFF);
        g.drawString(font, "Команда", x + 52, y - 12, 0xFFB0B0B8);
        g.drawString(font, "Каждые, сек", x + w - 58, y - 12, 0xFFB0B0B8);
        for (int i = 0; i < AutoCommand.SLOTS; i++) {
            g.drawString(font, "Слот " + (i + 1), x, y + i * ROW + 5, 0xFFDDDDDD);
        }
        String hint = "Например: /fix all или /heal. Минимум 5 секунд. Включи модуль Auto Command.";
        g.drawString(font, hint, Math.max(4, (width - font.width(hint)) / 2),
                y + AutoCommand.SLOTS * ROW + 36, 0xFF8A8A93);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }
}
