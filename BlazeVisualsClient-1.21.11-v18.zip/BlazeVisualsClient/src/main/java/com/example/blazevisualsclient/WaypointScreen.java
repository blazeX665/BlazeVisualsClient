package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class WaypointScreen extends Screen {
    private static final int MAX_ROWS = 5;

    private String nameVal = "", xVal = "", yVal = "", zVal = "";
    private String status = "";
    private EditBox nameBox, xBox, yBox, zBox;

    public WaypointScreen() { super(Component.literal("Waypoints")); }

    private int w() { return Math.min(width - 20, 340); }
    private int x() { return (width - w()) / 2; }

    @Override
    protected void init() {
        int x = x(), w = w(), y = 30;
        nameBox = new EditBox(font, x, y + 10, w, 18, Component.literal("name"));
        nameBox.setMaxLength(32);
        nameBox.setValue(nameVal);
        nameBox.setResponder(s -> nameVal = s);
        addRenderableWidget(nameBox);

        int bw = (w - 12) / 3;
        xBox = coordBox(x, y + 46, bw, xVal, s -> xVal = s);
        yBox = coordBox(x + bw + 6, y + 46, bw, yVal, s -> yVal = s);
        zBox = coordBox(x + 2 * (bw + 6), y + 46, bw, zVal, s -> zVal = s);

        addRenderableWidget(Button.builder(Component.literal("Моя позиция"), b -> fillMyPos())
                .bounds(x, y + 72, 100, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Добавить метку"), b -> addWaypoint())
                .bounds(x + 106, y + 72, 120, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Назад"),
                        b -> Minecraft.getInstance().setScreen(new ClickGuiScreen()))
                .bounds(x + w - 70, y + 72, 70, 20).build());

        // список меток (последние MAX_ROWS) с кнопкой удаления
        List<Waypoints.Waypoint> list = Waypoints.LIST;
        int start = Math.max(0, list.size() - MAX_ROWS);
        for (int i = start; i < list.size(); i++) {
            final int idx = i;
            int ry = y + 112 + (i - start) * 22;
            addRenderableWidget(Button.builder(Component.literal("X"), b -> {
                        if (idx < Waypoints.LIST.size()) Waypoints.LIST.remove(idx);
                        Config.save();
                        rebuildWidgets();
                    })
                    .bounds(x + w - 22, ry, 22, 18).build());
        }
    }

    private EditBox coordBox(int bx, int by, int bw, String value, java.util.function.Consumer<String> resp) {
        EditBox box = new EditBox(font, bx, by, bw, 18, Component.literal("coord"));
        box.setMaxLength(12);
        box.setValue(value);
        box.setResponder(resp);
        addRenderableWidget(box);
        return box;
    }

    private void fillMyPos() {
        var p = Minecraft.getInstance().player;
        if (p == null) return;
        xVal = String.valueOf((int) Math.floor(p.getX()));
        yVal = String.valueOf((int) Math.floor(p.getY()));
        zVal = String.valueOf((int) Math.floor(p.getZ()));
        rebuildWidgets();
    }

    private void addWaypoint() {
        try {
            double wx = Double.parseDouble(xVal.trim().replace(',', '.'));
            double wz = Double.parseDouble(zVal.trim().replace(',', '.'));
            double wy;
            if (yVal.trim().isEmpty()) {
                var p = Minecraft.getInstance().player;
                wy = p == null ? 64 : p.getY();
            } else {
                wy = Double.parseDouble(yVal.trim().replace(',', '.'));
            }
            String name = nameVal.trim().isEmpty() ? "Метка " + (Waypoints.LIST.size() + 1) : nameVal.trim();
            Waypoints.add(name, wx, wy, wz);
            Config.save();
            nameVal = "";
            status = "Метка добавлена: " + name;
            rebuildWidgets();
        } catch (NumberFormatException e) {
            status = "Введи числа в поля X и Z (Y можно оставить пустым)";
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        int x = x(), w = w(), y = 30;
        String title = "Waypoints — метки по координатам";
        g.drawString(font, title, (width - font.width(title)) / 2, 10, 0xFFFFFFFF);
        g.drawString(font, "Название", x, y, 0xFFB0B0B8);
        int bw = (w - 12) / 3;
        g.drawString(font, "X", x, y + 36, 0xFFB0B0B8);
        g.drawString(font, "Y (можно пусто)", x + bw + 6, y + 36, 0xFFB0B0B8);
        g.drawString(font, "Z", x + 2 * (bw + 6), y + 36, 0xFFB0B0B8);

        if (!status.isEmpty()) g.drawString(font, status, x, y + 98, 0xFFFFD166);

        List<Waypoints.Waypoint> list = Waypoints.LIST;
        int start = Math.max(0, list.size() - MAX_ROWS);
        for (int i = start; i < list.size(); i++) {
            Waypoints.Waypoint wp = list.get(i);
            int ry = y + 112 + (i - start) * 22;
            String t = wp.name + "  (" + (int) Math.floor(wp.x) + ", " + (int) Math.floor(wp.y) + ", " + (int) Math.floor(wp.z) + ")";
            g.drawString(font, t, x, ry + 5, 0xFFFFFFFF);
        }
        if (start > 0) {
            g.drawString(font, "…ещё " + start + " (показаны последние " + MAX_ROWS + ")",
                    x, y + 112 + MAX_ROWS * 22 + 2, 0xFF8A8A93);
        }
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }
}
