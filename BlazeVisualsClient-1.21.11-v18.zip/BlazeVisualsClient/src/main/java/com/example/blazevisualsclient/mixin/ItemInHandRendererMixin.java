package com.example.blazevisualsclient.mixin;

import com.example.blazevisualsclient.SwingStyle;
import com.example.blazevisualsclient.ViewModel;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemInHandRenderer.class)
public class ItemInHandRendererMixin {
    /** View Model: двигаем/вращаем/масштабируем руку и предмет. */
    @Inject(method = "renderArmWithItem", at = @At("HEAD"))
    private static void blaze$viewModel(AbstractClientPlayer player, float partialTick, float pitch,
                                        InteractionHand hand, float swingProgress, ItemStack stack,
                                        float equipProgress, PoseStack poseStack,
                                        SubmitNodeCollector collector, int light, CallbackInfo ci) {
        ViewModel.apply(player, hand, poseStack);
    }

    /** Swing Animation: кривая прогресса взмаха. */
    @ModifyVariable(method = "applyItemArmAttackTransform", at = @At("HEAD"), argsOnly = true)
    private static float blaze$swingCurve(float progress) {
        return SwingStyle.apply(progress);
    }

    /** Swing Animation: дополнительное движение (колющий, рубящий, мах). */
    @Inject(method = "applyItemArmAttackTransform", at = @At("TAIL"))
    private static void blaze$swingExtra(PoseStack poseStack, HumanoidArm arm, float progress, CallbackInfo ci) {
        SwingStyle.extra(poseStack, arm, progress);
    }

    /** Еда и питьё без подъёма руки к лицу. Аргументы не нужны, поэтому только CallbackInfo. */
    @Inject(method = "applyEatTransform", at = @At("HEAD"), cancellable = true)
    private static void blaze$noEatLift(CallbackInfo ci) {
        if (SwingStyle.noEat()) ci.cancel();
    }
}
