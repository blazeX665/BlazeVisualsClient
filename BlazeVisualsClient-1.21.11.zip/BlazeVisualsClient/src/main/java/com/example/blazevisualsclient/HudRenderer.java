package com.example.blazevisualsclient;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.awt.Color;
import java.util.Comparator;
import java.util.List;

public class HudRenderer {
    private static final int BG = 0x90000000;
    private static final int ACCENT = 0xFF7C5CFF;

    public static int color(float offset) {
        if (!ModuleManager.RAINBOW.enabled) return ACCENT;
        float h = ((System.currentTimeMillis() % 4000L) / 4000f + offset) % 1f;
        return Color.HSBtoRGB(h, 0.55f, 1f) | 0xFF000000;
    }

    public static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        Font font = mc.font;

        int y = 4;
        if (ModuleManager.WATERMARK.enabled) {
            String t = "BlazeVisualsClient";
            int w = font.width(t) + 8;
            g.fill(4, y, 4 + w, y + 14, BG);
            g.fill(4, y, 6, y + 14, color(0f));
            g.drawString(font, t, 9, y + 3, color(0f));
            y += 18;
        }
        if (ModuleManager.FPS.enabled) {
            y = box(g, font, "FPS: " + mc.getFps(), 4, y);
        }
        if (ModuleManager.COORDS.enabled) {
            var p = mc.player.blockPosition();
            y = box(g, font, "XYZ: " + p.getX() + " " + p.getY() + " " + p.getZ()
                    + "  " + mc.player.getDirection().getName(), 4, y);
        }
        if (ModuleManager.KEYSTROKES.enabled) {
            keystrokes(g, font, mc, 6, mc.getWindow().getGuiScaledHeight() - 66);
        }
        if (ModuleManager.ARRAYLIST.enabled) {
            arrayList(g, font, mc);
        }
    }

    private static int box(GuiGraphics g, Font font, String text, int x, int y) {
        int w = font.width(text) + 8;
        g.fill(x, y, x + w, y + 12, BG);
        g.drawString(font, text, x + 4, y + 2, 0xFFFFFFFF);
        return y + 14;
    }

    private static void arrayList(GuiGraphics g, Font font, Minecraft mc) {
        List<Module> on = ModuleManager.ALL.stream()
                .filter(m -> m.enabled)
                .sorted(Comparator.comparingInt((Module m) -> font.width(m.name)).reversed())
                .toList();
        int sw = mc.getWindow().getGuiScaledWidth();
        int y = 4, i = 0;
        for (Module m : on) {
            int w = font.width(m.name) + 8;
            int x = sw - w - 4;
            g.fill(x, y, x + w, y + 12, BG);
            g.fill(sw - 6, y, sw - 4, y + 12, color(i * 0.08f));
            g.drawString(font, m.name, x + 3, y + 2, color(i * 0.08f));
            y += 13;
            i++;
        }
    }

    private static void keystrokes(GuiGraphics g, Font font, Minecraft mc, int x, int y) {
        key(g, font, "W", mc.options.keyUp,    x + 20, y);
        key(g, font, "A", mc.options.keyLeft,  x,      y + 20);
        key(g, font, "S", mc.options.keyDown,  x + 20, y + 20);
        key(g, font, "D", mc.options.keyRight, x + 40, y + 20);
    }

    private static void key(GuiGraphics g, Font font, String label, KeyMapping k, int x, int y) {
        boolean down = k.isDown();
        g.fill(x, y, x + 18, y + 18, down ? ((color(0.3f) & 0x00FFFFFF) | 0xB0000000) : BG);
        g.drawString(font, label, x + 9 - font.width(label) / 2, y + 5, 0xFFFFFFFF);
    }
}
