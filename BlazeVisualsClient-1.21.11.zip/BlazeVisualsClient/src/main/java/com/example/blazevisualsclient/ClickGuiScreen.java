package com.example.blazevisualsclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class ClickGuiScreen extends Screen {
    private static final int W = 170, HEAD = 22, ROW = 20, FOOT = 16;

    public ClickGuiScreen() { super(Component.literal("BlazeVisualsClient")); }

    private int panelHeight() { return HEAD + ROW * ModuleManager.ALL.size() + FOOT; }
    private int px() { return width / 2 - W / 2; }
    private int py() { return height / 2 - panelHeight() / 2; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        int x = px(), y = py(), h = panelHeight();

        g.fill(x, y, x + W, y + h, 0xE0101018);
        g.fill(x, y, x + W, y + HEAD, 0xFF1C1C2A);
        g.fill(x, y + HEAD - 2, x + W, y + HEAD, HudRenderer.color(0f));
        g.drawString(font, "BlazeVisualsClient", x + 8, y + 7, 0xFFFFFFFF);

        String hint = "";
        int ry = y + HEAD;
        for (Module m : ModuleManager.ALL) {
            boolean hover = mx >= x && mx <= x + W && my >= ry && my < ry + ROW;
            if (hover) {
                g.fill(x, ry, x + W, ry + ROW, 0x30FFFFFF);
                hint = m.description;
            }
            g.drawString(font, m.name, x + 8, ry + 6, m.enabled ? 0xFFFFFFFF : 0xFF888888);

            int tx = x + W - 30, ty = ry + 5;
            g.fill(tx, ty, tx + 22, ty + 10, m.enabled ? HudRenderer.color(0.2f) : 0xFF3A3A48);
            int knob = m.enabled ? tx + 12 : tx + 2;
            g.fill(knob, ty + 2, knob + 8, ty + 8, 0xFFFFFFFF);
            ry += ROW;
        }
        g.drawString(font, hint, x + 8, ry + 4, 0xFFAAAAAA);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        int x = px(), ry = py() + HEAD;
        if (event.button() == 0 && mx >= x && mx <= x + W) {
            for (Module m : ModuleManager.ALL) {
                if (my >= ry && my < ry + ROW) { m.toggle(); return true; }
                ry += ROW;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
