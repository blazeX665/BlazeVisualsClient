package com.example.blazevisualsclient;

import java.util.List;

public class ModuleManager {
    public static final Module WATERMARK  = new Module("Watermark", "Название мода сверху слева", true);
    public static final Module FPS        = new Module("FPS", "Счётчик кадров", true);
    public static final Module COORDS     = new Module("Coordinates", "Координаты и направление", true);
    public static final Module KEYSTROKES = new Module("Keystrokes", "WASD на экране", true);
    public static final Module ARRAYLIST  = new Module("ArrayList", "Список включённых модулей", true);
    public static final Module RAINBOW    = new Module("Rainbow", "Радужные цвета HUD", true);

    public static final List<Module> ALL = List.of(
            WATERMARK, FPS, COORDS, KEYSTROKES, ARRAYLIST, RAINBOW
    );
}
