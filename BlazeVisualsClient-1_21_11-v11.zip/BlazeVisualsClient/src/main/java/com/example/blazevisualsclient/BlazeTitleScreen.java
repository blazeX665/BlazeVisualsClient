package com.example.blazevisualsclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Своё главное меню BlazeVisualsClient (заменяет ванильное, пока включён модуль Custom Menu). */
public class BlazeTitleScreen extends Screen {
    /** true — игрок сам открыл «Классическое меню», подмену не делаем. */
    public static boolean vanilla = false;

    private static final String[] LABELS = {"Одиночная игра", "Сетевая игра", "Настройки", "Выйти из игры"};
    private static final int BTN_H = 24, STEP = 30;

    // пиксельные буквы 5x7 для логотипа BLAZE
    private static final String[][] GLYPHS = {
            {"####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."},   // B
            {"#....", "#....", "#....", "#....", "#....", "#....", "#####"},   // L
            {".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"},   // A
            {"#####", "....#", "...#.", "..#..", ".#...", "#....", "#####"},   // Z
            {"#####", "#....", "#....", "####.", "#....", "#....", "#####"}    // E
    };

    private final float[] hover = new float[6];

    public BlazeTitleScreen() { super(Component.literal("BlazeVisualsClient")); }

    private int px() { return height < 300 ? 3 : 5; }
    private int bw() { return Math.min(220, width - 40); }
    private int bx() { return (width - bw()) / 2; }
    private int top() {
        int total = 7 * px() + 6 + 12 + 14 + 4 * STEP + 22;
        return Math.max(6, (height - total) / 2);
    }
    private int firstBtnY() { return top() + 7 * px() + 6 + 12 + 14; }
    private int btnY(int i) { return firstBtnY() + i * STEP; }
    private int altY() { return firstBtnY() + 4 * STEP + 2; }

    private String accText() { return "Аккаунт: " + Accounts.current(); }
    private int accW() { return font.width(accText()) + 16; }
    private int accX() { return width - accW() - 8; }
    private static final int ACC_Y = 8, ACC_H = 18;

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        int accent = HudRenderer.color(0f);
        MenuBackground.render(g, width, height);

        // логотип BLAZE пиксельными буквами
        int s = px();
        int letterW = 5 * s, gap = s;
        int totalW = GLYPHS.length * letterW + (GLYPHS.length - 1) * gap;
        int lx = (width - totalW) / 2, ly = top();
        for (int li = 0; li < GLYPHS.length; li++) {
            int col = HudRenderer.color(li * 0.12f);
            drawGlyph(g, GLYPHS[li], lx + li * (letterW + gap) + 2, ly + 2, s, 0xAA000000);
            drawGlyph(g, GLYPHS[li], lx + li * (letterW + gap), ly, s, col);
        }
        String sub = "VisualsClient";
        g.drawString(font, sub, (width - font.width(sub)) / 2, ly + 7 * s + 6, 0xFFF2F2F5);

        // кнопки
        for (int i = 0; i < 5; i++) {
            boolean alt = i == 4;
            int by = alt ? altY() : btnY(i);
            int h = alt ? 16 : BTN_H;
            boolean hov = mx >= bx() && mx < bx() + bw() && my >= by && my < by + h;
            hover[i] += ((hov ? 1f : 0f) - hover[i]) * 0.3f;

            int fill = Gfx.lerp(alt ? 0xFF16161C : 0xFF1F1F25, alt ? 0xFF22222A : 0xFF2A2A33, hover[i]);
            int edge = Gfx.lerp(0xFF2E2E38, accent, hover[i]);
            Gfx.rr(g, bx(), by, bw(), h, alt ? 6 : 8, edge);
            Gfx.rr(g, bx() + 1, by + 1, bw() - 2, h - 2, alt ? 5 : 7, fill);
            if (!alt) Gfx.rr(g, bx() + 8, by + 6, 2, h - 12, 1, Gfx.lerp(0xFF3A3A44, accent, hover[i]));

            String label = alt ? "Классическое меню (моды)" : LABELS[i];
            int tc = alt ? 0xFF9A9AA3 : Gfx.lerp(0xFFF2F2F5, accent, hover[i]);
            g.drawString(font, label, (width - font.width(label)) / 2, by + (h - 8) / 2, tc);
        }

        // быстрая смена аккаунта (справа вверху)
        boolean ah = mx >= accX() && mx < accX() + accW() && my >= ACC_Y && my < ACC_Y + ACC_H;
        hover[5] += ((ah ? 1f : 0f) - hover[5]) * 0.3f;
        Gfx.rr(g, accX(), ACC_Y, accW(), ACC_H, 7, Gfx.lerp(0xFF2E2E38, accent, hover[5]));
        Gfx.rr(g, accX() + 1, ACC_Y + 1, accW() - 2, ACC_H - 2, 6, Gfx.lerp(0xFF1B1B21, 0xFF2A2A33, hover[5]));
        g.drawString(font, accText(), accX() + 8, ACC_Y + 5, Gfx.lerp(0xFFD8D8DE, accent, hover[5]));

        // подписи
        g.drawString(font, "Minecraft 1.21.11 · Fabric", 6, height - 12, 0xFF6C6C75);
        String right = "BlazeVisualsClient v1.8 · меню в игре: Right Shift";
        g.drawString(font, right, width - font.width(right) - 6, height - 12, 0xFF6C6C75);
    }

    private static void drawGlyph(GuiGraphics g, String[] rows, int x, int y, int s, int color) {
        for (int r = 0; r < rows.length; r++) {
            for (int c = 0; c < rows[r].length(); c++) {
                if (rows[r].charAt(c) == '#') {
                    g.fill(x + c * s, y + r * s, x + c * s + s, y + r * s + s, color);
                }
            }
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        double mx = event.x(), my = event.y();
        Minecraft mc = Minecraft.getInstance();

        if (mx >= accX() && mx < accX() + accW() && my >= ACC_Y && my < ACC_Y + ACC_H) {
            mc.setScreen(new AccountScreen(this));
            return true;
        }

        for (int i = 0; i < 5; i++) {
            boolean alt = i == 4;
            int by = alt ? altY() : btnY(i);
            int h = alt ? 16 : BTN_H;
            if (mx >= bx() && mx < bx() + bw() && my >= by && my < by + h) {
                switch (i) {
                    case 0 -> mc.setScreen(new SelectWorldScreen(this));
                    case 1 -> mc.setScreen(new JoinMultiplayerScreen(this));
                    case 2 -> mc.setScreen(new OptionsScreen(this, mc.options));
                    case 3 -> mc.stop();
                    default -> {
                        vanilla = true;
                        mc.setScreen(new TitleScreen());
                    }
                }
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    public boolean isPauseScreen() { return false; }
}
